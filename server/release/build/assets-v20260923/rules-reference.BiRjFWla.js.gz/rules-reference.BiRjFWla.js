import{d as e,g as t,p as n}from"./src.DEN_3V-D.js";import{Vo as r,_i as i,f as a,h as o,io as s,nr as c,p as l,tr as u,va as d}from"./http-client.context.Cik8IZ22.js";import{B as f}from"./page-title.tK1G8Q4q.js";import{i as p,l as ee}from"./card.BnPC374m.js";import{t as m}from"./chevron-left.CmHVLMnV.js";import{i as h,n as g,t as _}from"./tabs.hooks.DaEPwNDt.js";import{t as v}from"./search-input.B_31ASfh.js";import{o as y,p as te}from"./index.g0a_k0HZ.js";import{t as b}from"./plane.h0dYPzhT.js";import{c as x}from"./card-tooltip.C2rJc5PU.js";import{t as S}from"./markdown.CSt30RvV.js";import{t as C}from"./use-go-back.BC5Jao2q.js";import{i as w,n as T,r as ne,t as re}from"./tabs.uWq5ZxhP.js";var ie=o(`list`,[[`path`,{d:`M3 5h.01`,key:`18ugdj`}],[`path`,{d:`M3 12h.01`,key:`nlz23k`}],[`path`,{d:`M3 19h.01`,key:`noohij`}],[`path`,{d:`M8 5h13`,key:`1pao27`}],[`path`,{d:`M8 12h13`,key:`1za7za`}],[`path`,{d:`M8 19h13`,key:`m83p4d`}]]),E=t(n(),1),ae=`<nav class="toc" id="toc">
  <ul>
    <li>
      <a href="#Intro">Introduction</a>
      <ul>
        <li>
          <a href="#The_Thing_That_Should_Not_Be"
            >The Thing That Should Not Be...</a
          >
        </li>
        <li>
          <a href="#The_Golden_Rules">The Golden Rules</a>
        </li>
        <li><a href="#The_Grim_Rule">The Grim Rule</a></li>
        <li>
          <a href="#The_Silver_Rule">The Silver Rule</a>
        </li>
      </ul>
    </li>
    <li>
      <a href="#Glossary">Glossary</a>
      <ul>
        <li><a href="#A_An">A, An</a></li>
        <li>
          <a href="#Ability">Ability</a>
          <ul>
            <li>
              <a href="#Abilities_Constant">Constant Abilities</a>
            </li>
            <li>
              <a href="#Abilities_Forced">Forced Abilities</a>
            </li>
            <li>
              <a href="#Abilities_Revelation">Revelation Abilities</a>
            </li>
            <li>
              <a href="#Abilities_Triggered">Triggered Abilities</a>
            </li>
            <li><a href="#Abilities_Keywords">Keywords</a></li>
            <li>
              <a href="#Spawn_Instructions_and_Prey_Instructions"
                >Spawn Instructions and Prey Instructions</a
              >
            </li>
            <li>
              <a href="#Action_Designators">Action Designators</a>
            </li>
            <li>
              <a href="#Switch_And_Swap_Abilities"
                >"Switch" and "Swap" Abilities</a
              >
            </li>
          </ul>
        </li>
        <li>
          <a href="#Act_Deck_and_Agenda_Deck">Act Deck and Agenda Deck</a>
        </li>
        <li>
          <a href="#Action">Action</a>
          <ul>
            <li>
              <a href="#Only_As_Your_First_Action"
                >"...only as your first action"</a
              >
            </li>
            <li>
              <a href="#Take_An_Action_Vs_Perform_An_Action"
                >"Take an action" vs "Perform/resolve an action"</a
              >
            </li>
            <li>
              <a href="#Basic_Action_Types">Basic Action Types</a>
            </li>
            <li>
              <a href="#Gaining_Spending_And_Forfeiting_Actions"
                >Gaining, Spending, and Forfeiting Actions</a
              >
            </li>
          </ul>
        </li>
        <li><a href="#Activate_Action">Activate Action</a></li>
        <li><a href="#Active_Player">Active Player</a></li>
        <li>
          <a href="#Additional_Costs">Additional Costs</a>
        </li>
        <li><a href="#After">After</a></li>
        <li><a href="#Agenda_Deck">Agenda Deck</a></li>
        <li><a href="#Alert">Alert</a></li>
        <li><a href="#Aloof">Aloof</a></li>
        <li><a href="#As_If">"As if..."</a></li>
        <li><a href="#Asset_Cards">Asset Cards</a></li>
        <li><a href="#At">At</a></li>
        <li>
          <a href="#Attach_To">Attach To</a>
          <ul>
            <li>
              <a href="#Control_of_Attachments">Control of Attachments</a>
            </li>
            <li>
              <a href="#Moving_Attachments">Moving Attachments</a>
            </li>
            <li>
              <a href="#Controlling_and_Attaching_Permanent_Cards"
                >Controlling and Attaching Permanent Cards</a
              >
            </li>
            <li>
              <a href="#Enemy_Attachments_with_Victory_X"
                >Enemy Attachments with Victory X</a
              >
            </li>
          </ul>
        </li>
        <li>
          <a href="#Attacker_Attacked">Attacker, Attacked</a>
        </li>
        <li>
          <a href="#Attack_of_Opportunity">Attack of Opportunity</a>
        </li>
        <li>
          <a href="#Automatic_Failure_Success">Automatic Failure/Success</a>
        </li>
        <li><a href="#Base_Value">Base Value</a></li>
        <li><a href="#Bearer">Bearer</a></li>
        <li><a href="#Blank">Blank</a></li>
        <li><a href="#Bonded">Bonded</a></li>
        <li>
          <a href="#Campaign_Play">Campaign Play</a>
          <ul>
            <li><a href="#Experience">Experience</a></li>
            <li><a href="#Trauma">Trauma</a></li>
            <li>
              <a href="#Defeat_by_Card_Ability">Defeat by Card Ability</a>
            </li>
            <li>
              <a href="#Advancing_to_Next_Scenario"
                >Advancing to Next Scenario</a
              >
            </li>
            <li>
              <a href="#Joining_or_Leaving_a_Campaign"
                >Joining or Leaving a Campaign</a
              >
            </li>
            <li>
              <a href="#Transferring_Investigators_to_a_New_Campaign"
                >Transferring Investigators to a New Campaign</a
              >
            </li>
          </ul>
        </li>
        <li><a href="#Cancel">Cancel</a></li>
        <li><a href="#Cannot">Cannot</a></li>
        <li><a href="#Cardtypes">Cardtypes</a></li>
        <li><a href="#Challenge_Scenarios">Challenge Scenarios</a></li>
        <li>
          <a href="#Chaos_Tokens">Chaos Tokens</a>
          <ul>
            <li>
              <a href="#Bless_and_Curse_Tokens">Bless and Curse Tokens</a>
            </li>
            <li><a href="#Frost_Tokens">Frost Tokens</a></li>
            <li>
              <a href="#Resolving_Multiple_Revealed_Chaos_Tokens"
                >Resolving Multiple Revealed Chaos Tokens</a
              >
            </li>
          </ul>
        </li>
        <li><a href="#Checkpoints">Checkpoints</a></li>
        <li>
          <a href="#Choices_and_the_Grim_Rule">Choices, and the Grim Rule</a>
        </li>
        <li>
          <a href="#Clues">Clues</a>
          <ul>
            <li>
              <a href="#Clues_on_Player_Cards">Clues on Player Cards</a>
            </li>
          </ul>
        </li>
        <li><a href="#Collection">Collection</a></li>
        <li><a href="#Concealed_X">Concealed X</a></li>
        <li>
          <a href="#Concealed_Mini_Cards">Concealed Mini-Cards</a>
        </li>
        <li>
          <a href="#Constant_Abilities">Constant Abilities</a>
        </li>
        <li><a href="#Control">Control</a></li>
        <li><a href="#Copy">Copy</a></li>
        <li>
          <a href="#Costs">Costs</a>
          <ul>
            <li>
              <a href="#Ignoring_All_Costs">"Ignoring all costs"</a>
            </li>
            <li>
              <a href="#Costs_and_Restrictions_during_the_Initiation_Sequence"
                >Costs and Restrictions during the Initiation Sequence</a
              >
            </li>
          </ul>
        </li>
        <li><a href="#Customizable">Customizable</a></li>
        <li><a href="#Day_and_Night">Day [day] and Night [night]</a></li>
        <li>
          <a href="#Dealing_Damage_Horror">Dealing Damage/Horror</a>
        </li>
        <li><a href="#Deck">Deck</a></li>
        <li>
          <a href="#Deckbuilding">Deckbuilding</a>
          <ul>
            <li><a href="#Classes">Classes</a></li>
            <li>
              <a href="#Synergy_and_Neutral_Cards">Synergy and Neutral Cards</a>
            </li>
            <li>
              <a href="#Deckbuilding_Options">Deckbuilding Options</a>
            </li>
            <li>
              <a href="#Purchasing_Player_Cards_with_Deckbuilding_Effects"
                >Purchasing Player Cards with Deckbuilding Effects</a
              >
            </li>
          </ul>
        </li>
        <li><a href="#Defeat">Defeat</a></li>
        <li><a href="#Delayed_Effects">Delayed Effects</a></li>
        <li><a href="#Different">"Different"</a></li>
        <li>
          <a href="#Difficulty_level">Difficulty (level)</a>
        </li>
        <li>
          <a href="#Difficulty_skill_tests">Difficulty (skill tests)</a>
        </li>
        <li>
          <a href="#Direct_Damage_Direct_Horror"
            >Direct Damage, Direct Horror</a
          >
        </li>
        <li><a href="#Discard_Piles">Discard Piles</a></li>
        <li><a href="#Doom">Doom</a></li>
        <li>
          <a href="#Doubt_and_Conviction">Doubt and Conviction</a>
        </li>
        <li><a href="#Draw_Action">Draw Action</a></li>
        <li><a href="#Drawing_Cards">Drawing Cards</a></li>
        <li><a href="#Effects">Effects</a></li>
        <li><a href="#Elimination">Elimination</a></li>
        <li><a href="#Elusive">Elusive</a></li>
        <li><a href="#Empty_Location">Empty Location</a></li>
        <li>
          <a href="#Encounter_Cards_Vs_Scenario_Cards"
            >"Encounter Cards" vs "Scenario Cards"</a
          >
        </li>
        <li><a href="#Encounter_Deck">Encounter Deck</a></li>
        <li><a href="#Encounter_Set">Encounter Set</a></li>
        <li><a href="#Enemy_Cards">Enemy Cards</a></li>
        <li>
          <a href="#Enemy_Engagement">Enemy Engagement</a>
        </li>
        <li><a href="#Enemy_Phase">Enemy Phase</a></li>
        <li><a href="#Engage_Action">Engage Action</a></li>
        <li><a href="#Enters_Play">Enters Play</a></li>
        <li><a href="#Evade_Action">Evade, Evade Action</a></li>
        <li><a href="#Event_Cards">Event Cards</a></li>
        <li><a href="#Exceptional">Exceptional</a></li>
        <li><a href="#Exhaust">Exhaust, Exhausted</a></li>
        <li><a href="#Exile">Exile</a></li>
        <li><a href="#Experience">Experience</a></li>
        <li><a href="#Explore">Explore</a></li>
        <li>
          <a href="#Farthest_From_All_Investigators"
            >"Farthest from all investigators"</a
          >
        </li>
        <li><a href="#Fast">Fast</a></li>
        <li><a href="#Fight_Action">Fight Action</a></li>
        <li><a href="#Flavor_Text">Flavor Text</a></li>
        <li><a href="#Flood_Tokens">Flood Tokens</a></li>
        <li>
          <a href="#For_Each_Or_For_Every">"For each" or "for every"</a>
        </li>
        <li>
          <a href="#Forced_Abilities">Forced Abilities</a>
        </li>
        <li><a href="#Gains">Gains</a></li>
        <li><a href="#Game">Game</a></li>
        <li><a href="#Hand_Size">Hand Size</a></li>
        <li><a href="#Haunted">Haunted</a></li>
        <li><a href="#Heal">Heal</a></li>
        <li>
          <a href="#Health_and_Damage">Health and Damage</a>
        </li>
        <li>
          <a href="#Hidden">Hidden</a>
          <ul>
            <li>
              <a href="#Hidden_Cards_in_Hand_When_Eliminated"
                >Hidden Cards in Hand When Eliminated</a
              >
            </li>
          </ul>
        </li>
        <li><a href="#Hunter">Hunter</a></li>
        <li><a href="#If">If</a></li>
        <li><a href="#Immune">Immune</a></li>
        <li>
          <a href="#In_Play_and_Out_of_Play">In Play and Out of Play</a>
        </li>
        <li><a href="#In_Player_Order">In Player Order</a></li>
        <li><a href="#Instead">Instead</a></li>
        <li>
          <a href="#Investigate_Action">Investigate Action</a>
        </li>
        <li>
          <a href="#Investigation_Phase">Investigation Phase</a>
        </li>
        <li>
          <a href="#Investigator_Deck">Investigator Deck</a>
          <ul>
            <li>
              <a href="#Scenario_Effects_on_Investigator_Decks"
                >Scenario Effects on Investigator Decks</a
              >
            </li>
          </ul>
        </li>
        <li>
          <a href="#Joes_Hunch_Deck">Joe's "Hunch Deck"</a>
        </li>
        <li>
          <a href="#Keys">Keys <i>(Innsmouth)</i></a>
        </li>
        <li>
          <a href="#Keys2">Keys <i>(Scarlet Keys)</i></a>
        </li>
        <li><a href="#Keywords">Keywords</a></li>
        <li>
          <a href="#Killed_Insane_Investigators">Killed/Insane Investigators</a>
        </li>
        <li><a href="#Lasting_Effects">Lasting Effects</a></li>
        <li>
          <a href="#Lead_Investigator">Lead Investigator</a>
        </li>
        <li><a href="#Leaves_Play">Leaves Play</a></li>
        <li><a href="#Limbo">Limbo</a></li>
        <li>
          <a href="#Limits_and_Maximums">Limits and Maximums</a>
          <ul>
            <li>
              <a href="#Limits_Pertaining_to_Play_Areas"
                >Limits Pertaining to Play Areas</a
              >
            </li>
          </ul>
        </li>
        <li>
          <a href="#Location_Cards">Location Cards</a>
          <ul>
            <li>
              <a href="#Being_at_No_Location">Being at No Location</a>
            </li>
            <li>
              <a href="#Revealing_and_Flipping_Locations"
                >Revealing and Flipping Locations</a
              >
            </li>
          </ul>
        </li>
        <li><a href="#Lola_and_Roles">Lola and "Roles"</a></li>
        <li>
          <a href="#Massive">Massive</a>
          <ul>
            <li><a href="#Massive_Enemy_Attacks">Massive Enemy Attacks</a></li>
          </ul>
        </li>
        <li><a href="#May">May</a></li>
        <li><a href="#Modifiers">Modifiers</a></li>
        <li><a href="#Move">Move</a></li>
        <li><a href="#Move_Action">Move Action</a></li>
        <li><a href="#Mulligan">Mulligan</a></li>
        <li>
          <a href="#Multiclass_Cards">Multi-class Cards</a>
        </li>
        <li><a href="#Must">Must</a></li>
        <li><a href="#Myriad">Myriad</a></li>
        <li><a href="#Mythos_Phase">Mythos Phase</a></li>
        <li><a href="#Nearest">Nearest</a></li>
        <li>
          <a href="#Nested_Sequences">Nested Sequences</a>
        </li>
        <li>
          <a href="#Nested_Skill_Tests">Nested Skill Tests</a>
        </li>
        <li>
          <a href="#Ownership_and_Control">Ownership and Control</a>
        </li>
        <li><a href="#Parallel_Investigators">Parallel Investigators</a></li>
        <li><a href="#Parley">Parley</a></li>
        <li><a href="#Partner">Partner</a></li>
        <li><a href="#Patrol">Patrol</a></li>
        <li>
          <a href="#Per_Investigator">Per Investigator</a>
        </li>
        <li><a href="#Peril">Peril</a></li>
        <li><a href="#Permanent">Permanent</a></li>
        <li><a href="#Play">Play</a></li>
        <li><a href="#Play_Action">Play Action</a></li>
        <li>
          <a href="#Play_Restrictions_Permissions_and_Instructions"
            >Play Restrictions, Permissions, and Instructions</a
          >
        </li>
        <li><a href="#Prey">Prey</a></li>
        <li><a href="#Printed">Printed</a></li>
        <li>
          <a href="#Priority_of_Simultaneous_Resolution"
            >Priority of Simultaneous Resolution</a
          >
        </li>
        <li>
          <a href="#Prologue_Investigators">Prologue Investigators</a>
        </li>
        <li><a href="#Put_into_Play">Put into Play</a></li>
        <li><a href="#Qualifiers">Qualifiers</a></li>
        <li>
          <a href="#Reaction_Opportunities">Reaction Opportunities</a>
        </li>
        <li><a href="#Ready">Ready</a></li>
        <li>
          <a href="#Record_in_your_Campaign_Log"
            >"Record in your Campaign Log..."</a
          >
        </li>
        <li><a href="#Relentless">Relentless</a></li>
        <li><a href="#Remember_that">"Remember that..."</a></li>
        <li>
          <a href="#Removed_from_Game">Removed from Game</a>
        </li>
        <li>
          <a href="#Replacing_an_Opening_Hand">Replacing an Opening Hand</a>
        </li>
        <li><a href="#Replacement_Cards">Replacement Cards</a></li>
        <li><a href="#Researched">Researched</a></li>
        <li><a href="#Resign">Resign</a></li>
        <li><a href="#Resource_Action">Resource Action</a></li>
        <li><a href="#Resources">Resources</a></li>
        <li><a href="#Retaliate">Retaliate</a></li>
        <li>
          <a href="#Revelation">Revelation</a>
          <ul>
            <li>
              <a href="#Dilemmas_and_Revelation_Abilities"
                >Dilemmas and Revelation Abilities</a
              >
            </li>
            <li>
              <a href="#Revelation_Ability_Priority"
                >Revelation Ability Priority</a
              >
            </li>
          </ul>
        </li>
        <li>
          <a href="#Sanity_and_Horror">Sanity and Horror</a>
        </li>
        <li><a href="#Seal">Seal</a></li>
        <li>
          <a href="#Search">Search</a>
          <ul>
            <li>
              <a href="#Looking_At_Searching_And_Finding"
                >"Looking at," "Searching," and "Finding"</a
              >
            </li>
            <li>
              <a href="#Searching_During_Setup">Searching During Setup</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="#Self_Referential_Text">Self-Referential Text</a>
        </li>
        <li><a href="#Set_Aside">Set Aside</a></li>
        <li><a href="#Signature_Cards">Signature Cards</a></li>
        <li><a href="#Skill_Cards">Skill Cards</a></li>
        <li>
          <a href="#Skill_Test_Results_and_Advanced_Timing"
            >Skill Test Results and Advanced Timing</a
          >
        </li>
        <li>
          <a href="#Skill_Tests">Skill Tests</a>
          <ul>
            <li>
              <a href="#Skill_Test_Results_and_Advanced_Timing"
                >Skill Test Results and Advanced Timing</a
              >
            </li>
            <li>
              <a href="#Variable_Difficulty_Skill_Tests"
                >Variable Difficulty Skill Tests</a
              >
            </li>
          </ul>
        </li>
        <li>
          <a href="#Slots">Slots</a>
          <ul>
            <li>
              <a href="#Shifting_Slots">Shifting Slots</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="#Spawn">Spawn</a>
          <ul>
            <li>
              <a href="#Spawning_an_Enemy">Spawning an Enemy</a>
            </li>
          </ul>
        </li>
        <li><a href="#Specialist_Cards">Specialist Cards</a></li>
        <li>
          <a href="#Standalone_Mode">Standalone Mode</a>
          <ul>
            <li>
              <a href="#Standalone_Scenario_Setup">Standalone Scenario Setup</a>
            </li>
          </ul>
        </li>
        <li><a href="#Story_Cards">Story Cards</a></li>
        <li><a href="#Supplies">Supplies</a></li>
        <li><a href="#Surge">Surge</a></li>
        <li><a href="#Swarming_X">Swarming X</a></li>
        <li>
          <a href="#Taking_Damage_Horror">Taking Damage/Horror</a>
        </li>
        <li><a href="#Target">Target</a></li>
        <li><a href="#Tarot_Slot">Tarot Slot</a></li>
        <li><a href="#Tekelili">Tekeli-li!</a></li>
        <li><a href="#Then">Then</a></li>
        <li><a href="#Threat_Area">Threat Area</a></li>
        <li><a href="#Tokens">Tokens, Running out of</a></li>
        <li><a href="#Traits">Traits</a></li>
        <li><a href="#Trauma">Trauma</a></li>
        <li>
          <a href="#Treachery_Cards">Treachery Cards</a>
          <ul>
            <li>
              <a href="#Treachery_and_Event_Subtitles"
                >Treachery and Event Subtitles</a
              >
            </li>
          </ul>
        </li>
        <li>
          <a href="#Triggered_Abilities">Triggered Abilities</a>
        </li>
        <li>
          <a href="#Triggering_Condition">Triggering Condition</a>
        </li>
        <li><a href="#Unique">Unique</a></li>
        <li>
          <a href="#unless_all_clues_have_been_discovered"
            >"...Unless all of (location's) clues have been discovered."</a
          >
        </li>
        <li><a href="#Upkeep_Phase">Upkeep Phase</a></li>
        <li><a href="#Uses">Uses (X "type")</a></li>
        <li><a href="#Vengeance_X">Vengeance X</a></li>
        <li>
          <a href="#Victory_Display_Victory_Points"
            >Victory Display, Victory Points</a
          >
        </li>
        <li>
          <a href="#Weakness">Weakness</a>
          <ul>
            <li>
              <a href="#Weakness_Events_And_Changing_The_Game_State"
                >Weakness Events and "changing the game state"</a
              >
            </li>
            <li>
              <a href="#Weakness_with_Player_Cardtypes"
                >Weaknesses with Player Cardtypes</a
              >
            </li>
          </ul>
        </li>
        <li><a href="#When">When</a></li>
        <li>
          <a href="#Wild_Skill_Icons">Wild Skill Icons</a>
        </li>
        <li>
          <a href="#Winning_and_Losing">Winning and Losing</a>
        </li>
        <li><a href="#The_letter_X">The letter "X"</a></li>
        <li>
          <a href="#You_Your">You/Your - Expanded</a>
          <ul>
            <li>
              <a href="#Interpreting_You_When_Taking_or_Being_Dealt_Damage"
                >Interpreting "You" When Taking or Being Dealt Damage</a
              >
            </li>
          </ul>
        </li>
      </ul>
    </li>
    <li>
      <a href="#Appendix_I_Initiation_Sequence"
        >Appendix I: Initiation Sequence</a
      >
    </li>
    <li>
      <a href="#Appendix_II_Timing_and_Gameplay"
        >Appendix II: Timing and Gameplay</a
      >
      <ul>
        <li>
          <a href="#Phase_Sequence_Timing">Phase Sequence Timing</a>
        </li>
        <li>
          <a href="#Framework_Event_Details">Framework Event Details</a>
          <ul>
            <li><a href="#Mythos_Phase">I. Mythos phase</a></li>
            <li>
              <a href="#Investigation_Phase">II. Investigation phase</a>
            </li>
            <li><a href="#Enemy_Phase">III. Enemy phase</a></li>
            <li>
              <a href="#Upkeep_Phase">IV. Upkeep phase</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="#Skill_Test_Timing">Skill Test Timing</a>
        </li>
      </ul>
    </li>
    <li>
      <a href="#Appendix_III_Setting_Up_The_Game"
        >Appendix III: Setting Up The Game</a
      >
    </li>
    <li>
      <a href="#Appendix_IV_Card_Anatomy">Appendix IV: Card Anatomy</a>
      <ul>
        <li>
          <a href="#Scenario_Card_Anatomy_Key">Scenario Card Anatomy Key</a>
        </li>
        <li>
          <a href="#Player_Card_Anatomy_Key">Player Card Anatomy Key</a>
        </li>
      </ul>
    </li>
  </ul>
</nav>
<!-- BEGIN RULES -->
<div class="longform rules" id="rules">
  <h1 id="Introduction">Introduction</h1>
  <p>
    This page contains a replica of the Rules Reference found in any copy of the
    Core Set of Arkham Horror: The Card Game. It also includes updates to the
    Rules Reference: rules added in deluxe expansions
    <span style="color: var(--red)">(marked in red)</span> and rules added in
    the official FAQ for the game
    <span style="color: var(--blue)">(marked in blue)</span>.
  </p>

  <h2 id="The_Thing_That_Should_Not_Be">The Thing That Should Not Be...</h2>

  <blockquote>
    <em
      >The most merciful thing in the world, I think, is the inability of the
      human mind to correlate all its contents.</em
    ><br />
    –
    <cite>H. P. Lovecraft, <em>"The Call of Cthulhu"</em></cite>
  </blockquote>

  <p>
    <b>Halt!</b> Read the Learn to Play book first. As questions arise during
    gameplay, use this document's glossary as a reference. After playing the
    tutorial game, we recommend reading the
    <a href="#Appendix_I_Initiation_Sequence">appendices</a>
    beginning on page 22.
  </p>

  <p>
    This document is intended as the definitive source for rules information,
    but does not teach players how to play the game. Players should first read
    the Learn to Play book in its entirety and use this Rules Reference as
    needed while playing the game.
  </p>

  <p>
    The majority of this guide consists of a glossary, which provides an
    alphabetical listing of terms and situations a player might encounter during
    a game. This section should be the first destination for players who have a
    rules question.
  </p>

  <p>
    The latter part of this guide contains four appendices. The first appendix
    describes the process of playing cards or initiating triggered abilities.
    The second appendix provides timing diagrams that illustrate the structure
    of a game round, as well as a detailed explanation of how to handle each
    game step presented in those diagrams. The third appendix lists the complete
    rules for setting up a game of
    <em>Arkham Horror: The Card Game</em>. The fourth appendix provides a
    detailed anatomy of each cardtype.
  </p>

  <h2 id="The_Golden_Rules">The Golden Rules</h2>

  <p>
    If the text of this Rules Reference directly contradicts the text of the
    Learn to Play book, the text of the Rules Reference takes precedence.
  </p>

  <p>
    If the text of a card directly contradicts the text of either the Rules
    Reference or the Learn to Play book, the text of the card takes precedence.
  </p>

  <h2 id="The_Grim_Rule">The Grim Rule</h2>

  <p>
    If players are unable to find the answer to a rules or timing conflict in
    this Rules Reference, resolve the conflict in the manner that the players
    perceive as the worst possible at that moment with regards to winning the
    scenario, and continue with the game.
  </p>

  <p>
    When investigators are forced to make a choice and there are multiple valid
    options, the lead investigator decides between those options. The Grim Rule
    does not play a part in these choices.
  </p>

  <p>
    <i
      >For example: Locked Door reads “Attach to the location with the most
      clues, and without a Locked Door attached.” If there are 3 locations that
      are tied for the most clues, and none of them already have a Locked Door
      attached, the lead investigator decides between those 3 locations. Players
      are not forced to decide which of those 3 options would be the objectively
      worst option.</i
    >
  </p>

  <p>
    The Grim Rule only comes into effect if players are unable to find the
    answer to a rules or timing conflict, and are thus unable to continue
    playing the game. It is designed to keep the game moving when looking up the
    correct answer would be too time-consuming or inconvenient for the players.
    The Grim Rule is not an exhaustive answer to rules/timing conflicts.
  </p>

  <h2 id="The_Silver_Rule" style="color: var(--blue)">
    "The Silver Rule" (added in FAQ, section 'Card Ability Interpretation',
    point 2.20)
  </h2>

  <p>
    If the text of two cards directly contradict one another in a way that is
    impossible to reconcile, the encounter card takes precedence over the player
    card. If both cards are encounter cards or both are player cards, the lead
    investigator may decide which takes precedence.
  </p>

  <h1 id="Glossary">Glossary</h1>

  <p>
    The following is an alphabetical list of entries for game rules, terms, and
    situations that may occur during play.
  </p>

  <h2 id="A_An">A, An</h2>

  <p>
    When used to describe a condition, the words "a" or "an" are satisfied if
    one or more of the conditional elements are present.
    <em
      >For example, an investigator with 3 resources will satisfy the condition
      of "Each investigator with a resource."</em
    >
  </p>

  <h2 id="Ability">Ability</h2>

  <p>
    An ability is the specialized game text that indicates how a card affects
    the game.
  </p>

  <ul>
    <li>
      Card abilities only interact with the game if the card bearing the ability
      is in play, unless the ability (or rules for the cardtype) specifically
      references its use from an out-of-play area.
    </li>

    <li>
      Card abilities only interact with other cards that are in play, unless the
      ability specifically references an interaction with cards in an
      out-of-play area.
    </li>

    <li>
      If multiple instances of the same ability are in play, each instance
      interacts with (or may interact with) the game state individually.
    </li>
  </ul>

  <p>
    The various types of card abilities are: constant abilities, forced
    abilities, revelation abilities, triggered abilities, keywords, and enemy
    instructions (spawn and prey). Each type is described in detail below.
  </p>

  <p>
    See also: "<a href="#Costs">Costs</a>" on page 7, "<a href="#Effects"
      >Effects</a
    >" on page 9, "<a href="#Qualifiers">Qualifiers</a>" on page 17, "<a
      href="#Self_Referential_Text"
      >Self-Referential Text</a
    >" on page 18.
  </p>

  <h3 id="Abilities_Constant">Constant Abilities</h3>

  <p>
    Constant abilities are simply stated on a card with no special formatting.
    Constant abilities are always interacting with the game state as long as the
    card is in play. (Some constant abilities continuously seek a specific
    condition, denoted by words such as "during" or "while." The effects of such
    abilities are active any time the specified condition is met.) Constant
    abilities have no point of initiation.
  </p>

  <h3 id="Abilities_Forced">Forced Abilities</h3>

  <p>
    A forced ability is identified by a bold "<strong>Forced</strong>
    – " command. Forced abilities initiate and interact with the game state
    automatically at a specified timing point. Such a timing point is usually
    indicated by words such as: "when," "after," "if," or "at."
  </p>

  <ul>
    <li>
      If a forced ability does not have the potential to change the game state,
      the ability does not initiate.
    </li>

    <li>
      The initiation of a forced ability that has the potential to change the
      game state is mandatory each time its specified timing point is met.
    </li>

    <li>
      A forced ability with a timing point beginning with the word "when..."
      automatically initiates as soon as the specified timing point is reached,
      but before its impact upon the game state resolves.
    </li>

    <li>
      A forced ability with a timing point beginning with the word "after..."
      automatically initiates immediately after that timing point's impact upon
      the game state has resolved.
    </li>

    <li>
      For any given timing point, all forced abilities initiated in reference to
      that timing point must resolve before any [reaction] abilities (see below)
      referencing the same timing point in the same manner may be initiated.
    </li>
  </ul>

  <p>
    See "<a href="#Priority_of_Simultaneous_Resolution"
      >Priority of Simultaneous Resolution</a
    >" on page 17.
  </p>

  <h3 id="Abilities_Revelation">Revelation Abilities</h3>

  <p>
    A revelation ability, indicated by a bold "<strong>Revelation</strong> – "
    command on an encounter card or weakness, initiates as that card is drawn by
    an investigator (see "<a href="#Revelation">Revelation</a>" on page 18).
  </p>

  <h3 id="Abilities_Triggered">Triggered Abilities</h3>

  <p>
    A triggered ability is any ability prefaced by either a [free] icon, a
    [reaction] icon, or an [action] icon. If the ability has one or more
    prerequisites (costs and/or conditions), these are listed in text
    immediately following the icon. A player must always meet the prerequisites
    of a triggered ability in order to trigger that ability. There are three
    types of triggered abilities:
  </p>

  <p>
    Free triggered abilities ([free]) – A [free] triggered ability may be
    triggered as a player ability during any player window. (See "<a
      href="#Appendix_II_Timing_and_Gameplay"
      >Appendix II: Timing and Gameplay</a
    >" on page 22 for a complete list of player windows.)
  </p>

  <p>
    Reaction triggered abilities ([reaction]) – A [reaction] triggered ability
    with a specified triggering condition may be triggered any time that
    triggering condition is met.
    <em>For example: "[reaction] After you defeat an enemy:"</em>
  </p>

  <ul>
    <li>
      A [reaction] ability with a triggering condition beginning with the word
      "when..." may be used after the specified triggering condition initiates,
      but before its impact upon the game state resolves.
    </li>

    <li>
      A [reaction] ability with a triggering condition beginning with the word
      "after..." may be used immediately after that triggering condition's
      impact upon the game state has resolved.
    </li>

    <li>
      Each [reaction] ability may be triggered only once each time the specified
      condition on the ability is met.
      <em
        >For example, an ability that is triggered "After X occurs," may be used
        once each time "X" occurs.</em
      >
    </li>
  </ul>

  <p>
    Action triggered abilities ([action]) – An [action] triggered ability may be
    triggered during a player's turn in the investigation phase through the use
    of the activate action, and only if the player uses one action for each
    [action] specified in the ability's cost.
  </p>

  <p>All triggered abilities are governed by the following rules:</p>

  <ul>
    <li>
      Triggered abilities on a card a player controls are optionally triggered
      (or not) by that player at the appropriate timing moment, as indicated by
      the ability.
    </li>

    <li>
      A triggered ability can only be initiated if its effect has the potential
      to change the game state, and its cost (if any) has the potential to be
      paid in full, taking active cost modifiers into account. This potential is
      assessed without taking into account the consequences of the cost payment
      or any other ability interactions.
    </li>

    <li>
      Once an ability is initiated, players must resolve as much of the effect
      as possible, unless the effect uses the word "may" (see "<a href="#May"
        >May</a
      >" on page 15).
    </li>
  </ul>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Game Play', point 1.2)</span
    >
    An investigator is permitted to use triggered abilities ([fast], [reaction],
    and [action] abilities) from the following sources:
  </p>

  <ul>
    <li>
      A card in play and under his or her control. This includes his or her
      investigator card.
    </li>

    <li>
      A scenario card that is in play and at the same location as the
      investigator. This includes the location itself, encounter cards placed at
      that location, and all encounter cards in the threat area of any
      investigator at that location.
    </li>

    <li>The current act or current agenda card.</li>

    <li>
      Any card that explicitly allows the investigator to activate its ability.
    </li>
  </ul>

  <h3 id="Abilities_Keywords">Keywords</h3>

  <p>
    A keyword is a card ability which conveys specific rules to its card (see
    "<a href="#Keywords">Keywords</a>" on page 13).
  </p>

  <h3 id="Spawn_Instructions_and_Prey_Instructions">
    Spawn Instructions and Prey Instructions
  </h3>

  <p>
    Spawn instructions inform where an enemy spawns as it enters play (see "<a
      href="#Spawn"
      >Spawn</a
    >" on page 19).
  </p>

  <p>
    Prey instructions inform which investigator an enemy pursues and/or engages
    if it has a choice (see "<a href="#Prey">Prey</a>" on page 17).
  </p>

  <h3 id="Action_Designators">Action Designators</h3>

  <p>
    Some abilities have bold action designators (such as
    <strong>Fight</strong>, <strong>Evade</strong>,
    <strong>Investigate</strong>, or <strong>Move</strong>). Activating such an
    ability performs the designated action as described in the rules, but
    modified in the manner described by the ability.
  </p>

  <h3 id="Switch_And_Swap_Abilities" style="color: var(--blue)">
    "Switch" and "Swap" Abilities (added in FAQ, section 'Card Ability
    Interpretation', point 2.26)
  </h3>

  <p>
    Some effects instruct players to "switch" or "swap" two cards in play or a
    card in play with another card in an out-of-play area. Effects that switch
    or swap are functionally the same. When swapping cards, each card maintains
    its status (ready/exhausted) and retains any tokens (damage, horror, uses,
    etc.) on it unless otherwise indicated. If it is an attachment, it is
    detached from its target game element during the swap and then re-attached
    to the new game element.
  </p>

  <p>
    <i
      >For example, if an investigator swaps places with an enemy via Ethereal
      Slip, they are considered to have left their location and entered the
      other, but are not considered to have moved for the purposes of card
      effects such as Buried Secrets.</i
    >
  </p>

  <h2 id="Act_Deck_and_Agenda_Deck">Act Deck and Agenda Deck</h2>

  <p>
    The act deck represents the progress the investigators can make in a
    scenario. The agenda deck represents the progress and objectives of the dark
    forces arrayed against the investigators in a scenario. Generally, advancing
    the act deck is good for the investigators, and advancing the agenda deck is
    bad for the investigators.
  </p>

  <ul>
    <li>
      The act deck advances if the investigators, as a group, spend the
      requisite number of clues (as indicated by the act card). An act card may
      indicate a flat value (such as "4") or a per investigator value (as
      indicated by the [per_investigator] icon). This is normally done as a
      [free] player ability. Any or all investigators may contribute any number
      of clues towards the total number of clues required to advance the act. If
      the act has an "<strong>Objective</strong> – " instruction, that
      instruction overrides or adds additional requirements to the spending of
      those clues.
    </li>

    <li>
      The agenda deck advances if the requisite number of doom is in play (doom
      on the agenda card as well as doom on any other cards in play), as
      indicated by the agenda card. An agenda card may indicate a flat value or
      a per investigator value. If the agenda has an "<strong>Objective</strong>
      – " instruction, that instruction overrides or adds additional
      requirements to meeting this doom requirement.
    </li>

    <li>
      The act/agenda on top of the act/agenda deck is referred to as the
      "current" act/agenda.
    </li>
  </ul>

  <p>
    To advance the act deck or the agenda deck, follow these steps, in order:
  </p>

  <ol>
    <li>
      Remove all tokens from the card to be advanced. If the agenda deck is
      advancing, remove all doom from each card in play.
    </li>

    <li>
      Flip the advancing card over and follow the instructions on the reverse
      ("b") side.
      <ul>
        <li>
          If the reverse side of the act or agenda is an encounter card, follow
          the rules for drawing that encounter cardtype. Otherwise, simply
          follow the instructions on the card.
        </li>
      </ul>
    </li>

    <li>
      Sometimes, the advancing act/agenda specifies which card becomes the next
      act/agenda. If it does not, the next card in the deck becomes the current
      act/agenda. As a new card becomes the current act/agenda, the advancing
      card is simultaneously removed from the game.
      <ul>
        <li>
          Some instructions in the act and agenda decks (as well as on other
          encounter cardtypes) contain resolution points, in the format of:
          "<strong>(→R#)</strong>." If a resolution point is reached, the
          scenario ends. Read the designated resolution in the campaign guide.
        </li>
      </ul>
    </li>
  </ol>

  <p>
    See also: "<a href="#Clues">Clues</a>" on page 6, "<a href="#Doom">Doom</a>"
    on page 9.
  </p>

  <h2 id="Action">Action</h2>

  <p>
    During his or her turn, an investigator is permitted to take up to
    <strong>three</strong> actions. When performing an action, all costs of the
    action are first paid. Then, the consequences of the action resolve.
  </p>

  <ul>
    <li>
      If an investigator is instructed to lose 1 or more actions, he or she has
      that many fewer actions to take during that round.
    </li>
  </ul>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Game Play', point 1.10)</span
    >
    Some card abilities grant investigators "additional actions." If an
    investigator has one or more additional actions during his or her turn, the
    first action he or she takes that is able to qualify as that additional
    action automatically uses that additional action.
  </p>

  <p>
    <i
      >For example: Daisy Walker reads: "You may take an additional action
      during your turn, which can only be used on Tome [action] abilities." The
      first time Daisy performs a Tome [action] ability each turn, it
      automatically uses up that additional action, and not one of Daisy’s three
      standard actions.</i
    >
  </p>

  <p>
    If an action qualifies as more than one of an investigator’s additional
    actions, he or she may choose which additional action is used.
  </p>

  <p>
    If an effect causes an investigator to lose one or more actions, that
    investigator has that many fewer standard actions to take that turn (the
    investigator’s three standard actions are the ones that are "lost" first).
    If an investigator only has additional actions remaining, those are then
    lost, in an order of the investigator’s choosing.
  </p>

  <p>
    <i
      >For example: An effect causes Daisy to lose two actions. She has two
      fewer standard actions to take during her turn. She cannot choose to
      "lose" her additional action unless it is the only action she has
      remaining.</i
    >
  </p>

  <p>
    For a complete list of the available actions, see "<a
      href="#Investigation_Phase"
      >2.2.1 Investigator takes an action, if able</a
    >" on page 24.
  </p>

  <h3 id="Only_As_Your_First_Action" style="color: var(--blue)">
    "...only as your first action" (added in FAQ, section 'Card Ability
    Interpretation', point 2.18)
  </h3>

  <p>
    If a card can only be played or its ability only triggered as your "first
    action," it must spend one of your actions, and that action must be the
    first one you have taken during your turn. If it is fast, a free triggered
    ability, ignores its action cost, or takes place outside of your turn, it
    cannot be played or triggered.
  </p>

  <h3 id="Take_An_Action_Vs_Perform_An_Action" style="color: var(--blue)">
    "Take an action" vs "Perform/resolve an action" (added in FAQ, section 'Card
    Ability Interpretation', point 2.19)
  </h3>

  <p>
    Some effects allow an investigator to "take" an action, usually of a certain
    type - for example, the ability on Ursula Downs or Haste. If an effect
    allows an investigator to take an action, they effectively gain an action
    and then immediately spend it in order to take the action in question,
    meaning it follows all of the rules taking an action might normally follow:
    it may provoke attacks of opportunity, it counts as an action for the
    purposes of cards that count how many actions you have taken, etc.
  </p>

  <p>
    Some other effects, such as Quickdraw Holster, allow an investigator to
    "perform" or "resolve" an action. Such effects typically specify that they
    ignore that action’s [action] cost. In this case, no action has been gained
    or spent, and the action is resolved as specified.
  </p>

  <h3 id="Basic_Action_Types" style="color: var(--blue)">
    Basic Action Types (added in FAQ, section 'Game Play', point 1.30)
  </h3>

  <p>
    A basic action is an action a player may take and resolve in full without
    any other modifiers or abilities, including bold action designators. The
    following are basic actions:
    <b>Draw</b>, <b>Resource</b>, <b>Move</b>, <b>Investigate</b>, <b>Fight</b>,
    <b>Engage</b>, and <b>Evade</b>.
  </p>

  <p>
    <b>Activate</b>, <b>Play</b>, <b>Resign</b>, and <b>Parley</b> are not basic
    actions.
  </p>

  <p>
    <i
      >For example: an investigator may use Close the Circle’s ability to take a
      basic <b>Fight</b> action but cannot use it to <b>Play</b> an event with a
      <b>Fight</b> action designator, as playing an event is not considered a
      basic action.</i
    >
  </p>

  <h3 id="Gaining_Spending_And_Forfeiting_Actions" style="color: var(--blue)">
    Gaining, Spending, and Forfeiting Actions (added in FAQ, section 'Game
    Play', point 1.31, updated FAQ v2.5)
  </h3>

  <p>
    Investigators gain actions during step 4.2 of the upkeep phase. Any unused
    actions are forfeited at the end of an investigator's turn (during step
    2.2.2 of the investigation phase). An investigator may lose actions via card
    effects outside of their turn, but may not voluntarily spend actions outside
    of their turn unless explicitly granted via a card effect.
  </p>
  <p>
    <i>Note: Investigators <b>always</b> begin the game with 3 actions.</i>
  </p>

  <h2 id="Activate_Action">Activate Action</h2>

  <p>
    "Activate" is an action an investigator may take during his or her turn in
    the investigation phase.
  </p>

  <p>
    When this action is taken, the investigator initiates an ability that
    specifies one or more [action] icons as part of its ability cost. The number
    of [action] icons in the ability's cost determines how many actions the
    investigator is required to use for this activate action. When performing an
    activate action, all of that action's costs are simultaneously paid. Then,
    the consequences of that action resolve.
  </p>

  <p>
    An investigator is permitted to activate abilities from the following
    sources:
  </p>

  <ul>
    <li>
      A card in play and under his or her control. This includes his or her
      investigator card.
    </li>

    <li>
      A scenario card that is in play and at the same location as the
      investigator. This includes the location itself, encounter cards placed at
      that location, and all encounter cards in the threat area of any
      investigator at that location.
    </li>

    <li>The current act or current agenda card.</li>
  </ul>

  <h2 id="Active_Player">Active Player</h2>

  <p>
    The active player is the player taking his or her turn during the
    investigation phase.
  </p>

  <h2 id="After">After</h2>

  <p>
    The word "after" refers to the moment immediately after the specified timing
    point or triggering condition has fully resolved.
  </p>

  <p>
    <em
      >(For example, an ability that reads "After you draw an enemy card"
      initiates immediately after resolving all of the steps for drawing an
      enemy – resolving its revelation ability, spawning it, etc.)</em
    >
  </p>

  <p>
    See also: "<a href="#Ability">Ability</a>" on page 2, "<a
      href="#Priority_of_Simultaneous_Resolution"
      >Priority of Simultaneous Resolution</a
    >" on page 17.
  </p>

  <h2 id="Additional_Costs" style="color: var(--blue)">
    Additional Costs (added in FAQ, section 'Game Play', point 1.6, updated
    v2.5)
  </h2>

  <p>
    Some cards add additional costs that must be paid in order to perform
    certain effects or actions, in the form of "As an additional cost to
    (specified effect/action) you must (additional cost)" or "You must
    (additional cost) to (specified effect/action)."
  </p>

  <p>
    Additional costs are costs that can be paid outside the normal timing point
    of paying costs (for instance, during the resolution of an effect). If an
    effect that requires an additional cost would resolve, the additional cost
    must be paid at that time. If the additional cost cannot be paid, that
    aspect of the effect fails to resolve.
  </p>

  <p>
    Additional costs are not paid when a mandatory instruction (such as in the
    Campaign Guide, or on the back of an Act or Agenda card) requires an
    investigator to resolve an effect.
  </p>
  <p>
    <i
      >For example: “Ashcan” Pete is at the Miskatonic Quad and activates Duke’s
      second ability, which reads: "[action] Exhaust Duke: <b>Investigate</b>.
      You investigate with a base skill of 4. You may move to a connecting
      location immediately before investigating with this effect.” Pete pays the
      cost to activate this ability, which is spending one action and exhausting
      Duke. Then Pete resolves the ability, first moving to the Orne Library,
      followed by investigating. The Orne Library, however, reads: “You must
      spend 1 additional action to investigate the Orne Library.” This adds an
      additional cost that must be paid in order to investigate the Orne
      Library. This additional cost is paid when the investigate action would
      resolve, outside the normal timing point for paying costs. If Pete cannot
      spend the additional action, that aspect of Duke’s effect fails to
      resolve.</i
    >
  </p>

  <h2 id="Agenda_Deck">Agenda Deck</h2>

  <p>
    See "<a href="#Act_Deck_and_Agenda_Deck">Act Deck and Agenda Deck</a>" on
    page 3.
  </p>

  <h2 id="Alert" style="color: var(--red)">
    Alert (added in <em>The Forgotten Age</em>)
  </h2>

  <p>
    Each time an investigator fails a skill test while attempting to evade an
    enemy with the "alert" keyword, after applying all results for that skill
    test, that enemy performs an attack against the evading investigator. An
    enemy does not exhaust after performing an alert attack. This attack occurs
    whether the enemy is engaged with the evading investigator or not.
  </p>

  <h2 id="Aloof">Aloof</h2>

  <p>
    Aloof is a keyword ability. An enemy with the aloof keyword does not
    automatically engage investigators at its location.
  </p>

  <ul>
    <li>When an aloof enemy spawns, it spawns unengaged.</li>

    <li>
      An investigator may use the engage action or a card ability to engage an
      aloof enemy.
    </li>

    <li>
      An investigator cannot attack an aloof enemy while that enemy is not
      engaged with an investigator.
    </li>
  </ul>

  <h2 id="As_If" style="color: var(--blue)">
    "As if..." (added in FAQ, section 'Card Ability Interpretation', point 2.10,
    amended October 2020, updated FAQ v2.5)
  </h2>

  <p>
    Some card effects allow an investigator to resolve an ability or perform an
    action as if a certain aspect of the game state were altered, using the text
    "as if..." to indicate the difference. The indicated ability or action is
    resolved with the altered game state in mind, but the actual game state
    remains unchanged.
  </p>

  <ul>
    <li>
      The game state is considered to be altered throughout the duration of the
      indicated ability or action, from its initiation (including the paying of
      its costs, attacks of opportunity, etc) through the resolution of each
      aspect of its effect, and up until its completion.
    </li>

    <li>
      Other card abilities or game effects resolved during this duration are
      also resolved with the altered game state in mind.
    </li>

    <li>
      The game state is not physically altered in any way. (e.g. if you are
      considered to be at a location, you do not move your mini-card to that
      location, enemies at that location do not automatically move to your
      threat area, etc.)
    </li>
    <li>
      Unless otherwise stated, an investigator's threat area is not inherently
      altered during the resolution of the indicated ability or action. (For
      example, if you are engaged with an enemy prior to resolving an ability
      "as if" you are at a connecting location, that enemy remains engaged with
      you and will still make attacks of opportunity, even though it does not
      leave your shared, actual location.)
    </li>
  </ul>

  <p>
    <i
      >For example: Luke Robinson wants to play Preposterous Sketches, but is at
      a location with no clues. One of the locations next to him has a clue on
      it, so he uses his ability to play Preposterous Sketches as if he were at
      that location and engaged with each enemy at that location. The game state
      is considered to be altered in this way throughout the playing of
      Preposterous Sketches, from its initiation to its resolution. Among other
      things, this might mean: (a) if there is an enemy at that location,
      playing Preposterous Sketches would provoke an attack of opportunity, (b)
      if that location has an ability that would alter the cost of playing the
      card, it would do so, and (c) other card abilities that might trigger from
      Luke drawing 1 or more cards would do so as if he were at that connecting
      location and engaged with that enemy, and so on and so forth. Once
      Preposterous Sketches has finished resolving and is placed in the discard
      pile, Luke is no longer considered to be at that location and engaged with
      each enemy at that location.</i
    >
  </p>

  <ul>
    <li>
      <span style="color: var(--blue)"
        >(Added in FAQ, section 'Frequently Asked Questions')</span
      >
      <i
        >Q: Does an enemy exhaust when an effect causes it to attack "as if it
        were the enemy phase?" What about an effect that causes an enemy to
        attack without that text?</i
      >
      A: Yes, if an enemy attacks "as if it were the enemy phase," it will
      exhaust after attacking. However, if an effect causes an enemy to attack
      without that phrasing, the enemy does not exhaust after attacking.
    </li>
  </ul>

  <h2 id="Asset_Cards">Asset Cards</h2>

  <p>
    Asset cards represent items, allies, talents, spells, and other reserves
    that may assist or be used by an investigator during a scenario.
  </p>

  <ul>
    <li>
      When you play an asset, it is placed in your play area. Generally, assets
      remain in play unless discarded by a card ability or game step.
    </li>

    <li>
      Some assets have health and/or sanity. When an investigator is dealt
      damage or horror, that investigator may assign some or all of that damage
      or horror to eligible asset cards he or she controls (see "<a
        href="#Dealing_Damage_Horror"
        >Dealing Damage/Horror</a
      >" on page 7).
    </li>

    <li>
      Most assets take up one or more slots while in play (see "<a href="#Slots"
        >Slots</a
      >" on page 19).
    </li>

    <li>
      Some assets have an encounter set icon and no level indicator. Such assets
      are known as Story Assets. Story Assets are part of an encounter set and
      may not be included in a player's deck unless the resolution or setup of a
      scenario grants that player permission to do so.
    </li>
  </ul>

  <h2 id="At" style="color: var(--blue)">
    At (added in FAQ, section 'Card Ability Interpretation', point 2.2)
  </h2>

  <p>
    Some abilities have triggering conditions that use the words "at" or "if"
    instead of specifying "when" or "after," such as "at the end of the round,"
    or "if the Ghoul Priest is defeated." These abilities trigger in between any
    "when..." abilities and any "after..." abilities with the same triggering
    condition.
  </p>

  <p>See also: "<a href="#If">If</a>".</p>

  <h2 id="Attach_To">Attach To</h2>

  <p>
    If a card uses the phrase "attach to" it must be attached to (placed beneath
    and slightly overlapped by) the specified game element as it enters play.
    Once attached, such a card is referred to as an attachment.
  </p>

  <ul>
    <li>
      The "attach to" phrase is checked for legality each time a card would be
      attached to a game element, but is not checked again after that attachment
      occurs. If the initial "attach to" check does not pass, the card is not
      able to be attached, and remains in its prior state or game area. If such
      a card cannot remain in its prior state or game area, discard it.
    </li>

    <li>
      Once in play, an attachment remains attached until either the attachment
      or the game element to which it is attached leaves play (in which case the
      attachment is discarded), or unless a card ability explicitly detaches the
      card.
    </li>

    <li>
      An attachment exhausts and readies independently of the game element it's
      attached to.
    </li>
  </ul>

  <h3 id="Control_of_Attachments" style="color: var(--blue)">
    Control of Attachments (added in FAQ, section 'Game Play', point 1.14)
  </h3>

  <p>
    An attachment may change control depending on the card it is attached to.
  </p>

  <ul>
    <li>
      If an investigator attaches a player card to a player card he or she
      controls, he or she retains control of the attachment.
    </li>

    <li>
      If an investigator attaches a player card to a player card another
      investigator controls, that other investigator takes control of the
      attachment.
    </li>

    <li>
      If a player card with 1 or more player attachments changes control, the
      card’s new controller takes control of those player attachments.
    </li>

    <li>
      If an investigator attaches a player card to an encounter card, he or she
      retains control of the attachment (but does not gain control of the
      attached encounter card).
    </li>

    <li>
      A card with the permanent keyword cannot be chosen to be attached to
      another player card unless explicitly stated.
    </li>
  </ul>

  <h3 id="Moving_Attachments" style="color: var(--blue)">
    Moving Attachments (added in FAQ, section 'Game Play', point 1.25)
  </h3>

  <p>
    If an attachment "moves" from one game element to another, or attaches to a
    game element while already attached to a game element, it detaches from its
    original game element and attaches to the new one.
  </p>

  <h3 id="Controlling_and_Attaching_Permanent_Cards" style="color: var(--blue)">
    Controlling and Attaching Permanent Cards (added in FAQ, section 'Game
    Play', point 1.29)
  </h3>

  <p>
    A card with the permanent keyword cannot leave its controller’s play area
    unless directed by scenario card effects. Cards with the permanent keyword
    cannot be attached to other cards in an investigator’s play area.
    Investigators cannot take control of another investigator’s permanent cards.
  </p>

  <p>
    <i
      >For example: an investigator cannot attach Sin-Eater to Elle Rubash even
      if Sin-Eater has one or more doom on it.</i
    >
  </p>

  <h3 id="Enemy_Attachments_with_Victory_X" style="color: var(--blue)">
    Enemy Attachments with Victory X (added in FAQ, section 'Game Play', point
    1.33)
  </h3>

  <p>
    If a card with Victory X is attached to an enemy and that enemy is defeated,
    the attachment is placed in the victory display instead of the usual
    out-of-play area corresponding to its card type.
  </p>

  <h2 id="Attacker_Attacked">Attacker, Attacked</h2>

  <p>
    An "attacker" is an entity (usually an enemy or investigator) that is
    resolving its attack against another entity. The entity being attacked is
    referred to as the "attacked enemy" or the "attacked investigator."
  </p>

  <h2 id="Attack_of_Opportunity">Attack of Opportunity</h2>

  <p>
    Each time an investigator is engaged with one or more ready enemies and
    takes an action other than to
    <strong>fight</strong>, to <strong>evade</strong>, or to activate a
    <strong>parley</strong> or <strong>resign</strong> ability, each of those
    enemies makes an attack of opportunity against the investigator, in the
    order of the investigator's choosing. Each attack deals that enemy's damage
    and horror to the investigator.
  </p>

  <ul>
    <li>
      An attack of opportunity is made immediately after all costs of initiating
      the action that provoked the attack have been paid, but before the
      application of that action's effect upon the game state.
    </li>

    <li>
      An ability that costs more than one action only provokes one attack of
      opportunity from each engaged enemy.
    </li>

    <li>An enemy does not exhaust while making an attack of opportunity.</li>

    <li>
      After all attacks of opportunity are made, continue with the resolution of
      the action which instigated the attack.
    </li>

    <li>
      Attacks of opportunity count as enemy attacks for the purposes of card
      abilities.
    </li>
  </ul>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Game Play', point 1.1)</span
    >
    Attacks of Opportunity are only triggered when 1 or more of an
    investigator’s actions are being spent or used to trigger an ability or
    action. [free] abilities with a bold action designator do not provoke
    attacks of opportunity.
  </p>

  <h2 id="Automatic_Failure_Success" style="color: var(--blue)">
    Automatic Failure/Success (expanded in FAQ, section 'Card Ability
    Interpretation', point 2.9)
  </h2>

  <p>
    Some card or token abilities may cause a skill test to automatically fail or
    to automatically succeed. If a skill test automatically fails or
    automatically succeeds, it does so during step "ST.6" of the "<a
      href="#Skill_Test_Timing"
      >Skill Test Timing</a
    >" process outlined on page 26.
  </p>

  <ul>
    <li>
      If a skill test automatically fails, the investigator's total skill value
      for that test is considered 0.
    </li>

    <li>
      If a skill test automatically succeeds, the total difficulty of that test
      is considered 0.
    </li>
  </ul>

  <p>
    <b
      >(Here begin the expanded rules. NB this section overrules some of what is
      above.)</b
    >
    Some card effects make an investigator automatically succeed or
    automatically fail a skill test. If this occurs, depending on the timing of
    such an effect, certain steps of the skill test may be skipped in their
    entirety.
  </p>

  <ul>
    <li>
      If it is known that an investigator automatically succeeds or fails at a
      skill test before Step 3 ("Reveal chaos token") occurs, that step is
      skipped, along with Step 4. No chaos token(s) are revealed from the chaos
      bag, and the investigator immediately moves to Step 5. All other steps of
      the skill test resolve as normal.
    </li>

    <li>
      If a chaos token effect causes an investigator to automatically succeed or
      fail at a skill test, continue with Steps 3 and 4, as normal.
    </li>

    <li>
      If an ability "automatically evades" 1 or more enemies, this is not the
      same as automatically succeeding at an evasion attempt. As per the entry
      on "Evade" in the Rules Reference (see "<a href="#Evade">Evade</a>"), if
      an ability automatically evades 1 or more enemies, no skill test is made
      for the evasion attempt whatsoever. Consequentially, because no skill test
      is made, it is not considered a "successful" evasion. The investigator
      simply follows the steps for evading an enemy (exhausting it and breaking
      its engagement).
    </li>
  </ul>

  <p>
    <i
      >For example: Patrice uses the ability on Hope, which reads: "[action] If
      Hope is ready, exhaust or discard him: <b>Evade.</b> Attempt to evade with
      a base [agility] value of 5. (If you discarded Hope, this test is
      automatically successful.)" If Patrice chooses to discard Hope, the skill
      test automatically succeeds before chaos tokens are revealed; therefore
      Steps 3 and 4 of the skill test are skipped. However, the skill test still
      takes place. Cards may still be committed to the test, and the
      investigator’s total modified skill value is still determined, as it may
      have some bearing on other card abilities. However, if Patrice instead
      uses the ability on Stray Cat, which reads: "[fast] Discard Stray Cat:
      Automatically evade a non-<b>Elite</b> enemy at your location," no skill
      test is made whatsoever.</i
    >
  </p>

  <h2 id="Base_Value">Base Value</h2>

  <p>
    Base value is the value of an element before any modifiers are applied.
    Unless otherwise specified, the base value of an element derived from a card
    is the value printed on that card.
  </p>

  <h2 id="Bearer">Bearer</h2>

  <p>
    The bearer of a weakness is the investigator who started the game with the
    weakness in his or her deck or play area.
  </p>

  <p>See "<a href="#Weakness">Weakness</a>" on page 21.</p>

  <h2 id="Blank">Blank</h2>

  <p>
    If a card's printed text box is considered "blank" by an ability, that text
    box is treated as if it did not have any of its printed content. Text and/or
    icons gained from another source are not blanked.
  </p>

  <ul>
    <li>
      A card's text box includes: traits, keywords, card text and abilities.
    </li>
  </ul>

  <h2 id="Bonded" style="color: var(--red)">
    Bonded (added in <em>The Dream-Eaters</em>)
  </h2>

  <p>
    Cards with the bonded keyword are linked to another player card. They have
    no level and therefore are not available as deckbuilding options. Instead,
    the card to which they are bonded (which is listed in parentheses next to
    this keyword) brings the bonded card into the game.
  </p>

  <p>
    If your deck contains a card that summons one or more bonded cards, those
    bonded cards are set aside at the start of each game.
  </p>

  <p>
    If a weakness with the bonded keyword is added to an investigator's deck,
    hand, threat area, or play area, it does not remain a part of that
    investigator's deck for the rest of the campaign (unlike other weaknesses).
    It starts each game set aside with that investigator's other bonded cards.
  </p>

  <p>
    <i
      >For example: Hope, Zeal, and Augur all have the "Bonded (Miss Doyle)"
      keyword. This means each of those cards is bonded to the card Miss Doyle.
      Hope, Zeal, and Augur each have no level and are therefore not available
      as options to include when building your deck. However, Miss Doyle summons
      each of these cards when she is played. Therefore, a player with Miss
      Doyle in their deck should set aside Hope, Zeal, and Augur at the start of
      each game. These cards are not part of that investigator's deck and do not
      count towards their deck size.</i
    >
  </p>

  <table>
    <tr>
      <td>
        <img
          class="card-scan"
          src="/img/arkham/zh/cards/06030.avif"
          alt="Miss Doyle"
          loading="lazy"
        />
      </td>
      <td>
        <img
          class="card-scan"
          src="/img/arkham/zh/cards/06031.avif"
          alt="Hope"
          loading="lazy"
        />
      </td>
    </tr>
  </table>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Game Play', point 1.19)</span
    >
    If an investigator’s deck contains a card that summons one or more bonded
    cards, those bonded cards are set aside at the start of each game. The
    number of copies of each different bonded card that are set aside in this
    way is equal to the number of copies of that were included in the product in
    which that bonded card was introduced. The number of cards in your deck that
    summon the bonded card in question does not factor into this limit.
  </p>

  <p>
    <i
      >For example: An investigator may only have 3 copies of Soothing Melody
      set aside at the start of the game. Similarly, an investigator may only
      have 1 Essence of the Dream set aside at the start of the game, regardless
      of how many copies of Dream Diary they include in their deck.</i
    >
  </p>

  <h2 id="Campaign_Play">Campaign Play</h2>

  <p>
    A campaign is a series of interrelated scenarios in which each player plays
    the same investigator from one scenario to the next. As a campaign
    progresses, the investigator gains experience and trauma, and this is
    reflected by changes in his or her deck. Each decision made in a campaign
    may have repercussions in a later scenario.
  </p>

  <p>
    When starting a campaign, follow the instructions for that campaign's setup
    in the campaign guide. After playing through a scenario during a campaign,
    record the specified results of that scenario in the campaign log.
  </p>

  <h3 id="Experience">Experience</h3>

  <p>
    After recording the results of a scenario, the investigators are ready to
    reflect on their experiences and purchase new cards for their decks. To do
    this, follow these steps, in order:
  </p>

  <ol>
    <li>
      <strong>Count experience.</strong> Each investigator earns experience
      equal to the total victory value of all cards in the victory display plus
      or minus any bonuses or penalties indicated by the campaign guide for that
      resolution. This total is added to any unspent experience an investigator
      has recorded from previous scenarios in this campaign.
    </li>

    <li>
      <strong>Purchase new cards.</strong> New cards may be purchased and added
      to a player's deck by spending experience equal to the card's level
      (denoted by a number of pips in the upper left hand corner of the card).
      While purchasing new cards, observe the following rules:

      <ul>
        <li>
          An investigator's deckbuilding guidelines (found on the back of the
          investigator card) must be observed while that investigator is
          purchasing new cards. Only cards the investigator has access to may be
          purchased. The deck-size requirement must also be maintained, so that
          for each (nonpermanent) card purchased and added to a deck, a
          different card is removed from the deck. Weakness cards and cards that
          must be included in an investigator's deck may not be removed while
          that investigator is purchasing new cards.
        </li>

        <li>
          Each card costs experience equal to the card's level,
          <em>to a minimum of 1</em> (purchasing a level zero card still costs 1
          experience). The number of pips beneath a card's cost indicates the
          card's level.
        </li>

        <li>
          <span style="color: var(--blue)"
            >(Added in FAQ, section 'Game Play', point 1.8)</span
          >
          When purchasing a new card during campaign play, an investigator must
          pay a minimum of 1 experience. As a result, level 0 cards cost 1
          experience to purchase. This minimum only applies when purchasing new
          cards. It does not permanently alter a card’s level or experience
          cost, and does not apply when upgrading a card to a higher level
          version.
        </li>

        <li>
          When purchasing a higher level version of a card with the same title,
          the investigator may choose to "upgrade" that card by paying only the
          difference in experience (to a minimum of 1) between the two cards and
          removing the lower level version of the card from his or her deck.
        </li>

        <li>
          New cards are purchased (or upgraded) individually. If an investigator
          wishes to purchase more than 1 copy of a new card, each copy must be
          paid for separately, and one card must be removed from that
          investigator's deck for each copy purchased.
        </li>

        <li>
          The above processes, and any specific instructions provided by the
          campaign guide, are the only methods by which a player may modify his
          or her deck during a campaign.
        </li>
      </ul>
    </li>

    <li>
      <strong>Record unspent experience.</strong> Each investigator records any
      unspent experience on the campaign log. This experience may be spent at a
      later time during this campaign.
    </li>
  </ol>

  <h3 id="Trauma">Trauma</h3>

  <p>
    Trauma reflects permanent damage that has been done to an investigator's
    health and/or psyche.
  </p>

  <p>
    If an investigator is defeated in a scenario that investigator is eliminated
    from the scenario but not necessarily from the campaign.
  </p>

  <p>
    If an investigator is defeated by taking damage equal to his or her health,
    he or she suffers 1 physical trauma (recorded in the campaign log). For each
    physical trauma an investigator has, that investigator begins each
    subsequent scenario in the campaign with 1 damage. If an investigator has
    physical trauma equal to his or her printed health, the investigator is
    <strong>killed</strong>.
  </p>

  <p>
    If an investigator is defeated by taking horror equal to his or her sanity,
    he or she suffers 1 mental trauma (recorded in the campaign log). For each
    mental trauma an investigator has, that investigator begins each subsequent
    scenario in the campaign with 1 horror. If an investigator has mental trauma
    equal to his or her printed sanity, the investigator is driven
    <strong>insane</strong>.
  </p>

  <p>
    If an investigator is defeated by simultaneously taking damage equal to his
    or her health <em>and</em> horror equal to his or her sanity, he or she
    chooses which type of trauma to suffer.
  </p>

  <p>
    If an investigator is killed or driven insane, that player must choose a new
    investigator to use in the next scenario, and creates a new deck for that
    investigator. Investigators that are killed or driven insane cannot be used
    for the remainder of the campaign (see "<a
      href="#Killed_Insane_Investigators"
      >Killed/Insane Investigators</a
    >" on page 13).
  </p>

  <p>
    If a player attempts to choose a new investigator and there are no
    investigators remaining in the pool, the players have lost and the campaign
    ends.
  </p>

  <h3 id="Defeat_by_Card_Ability">Defeat by Card Ability</h3>

  <p>
    An investigator may be defeated by a card ability. A defeated investigator
    is eliminated from the game (see "<a href="#Elimination">Elimination</a>" on
    page 10). Should this occur, follow the instructions of the card ability to
    determine if there are any long-term repercussions of the defeat.
  </p>

  <h3 id="Advancing_to_Next_Scenario">Advancing to Next Scenario</h3>

  <p>
    After completing a scenario, resolving its resolution, updating the campaign
    log, and purchasing any new cards, advance to the next scenario
    (sequentially) in the campaign, unless the scenario resolution explicitly
    directs the investigators to a different scenario.
  </p>

  <h3 id="Joining_or_Leaving_a_Campaign">Joining or Leaving a Campaign</h3>

  <p>
    Once a campaign has begun, players can freely drop in and out of the
    campaign in between scenarios.
  </p>

  <p>
    If a player leaves the campaign, do not delete that player's information
    from the campaign log, as he or she may re-join at any time between
    scenarios.
  </p>

  <p>
    If a new player joins the campaign, he or she must choose an investigator
    not previously used during this campaign. That player begins as if it were
    his or her first scenario in the campaign, with no experience and no trauma.
  </p>

  <h3
    id="Transferring_Investigators_to_a_New_Campaign"
    style="color: var(--blue)"
  >
    Transferring Investigators to a New Campaign (added in FAQ, section 'Game
    Play', point 1.11)
  </h3>

  <p>
    This section expands on the ability for investigators to transfer from a
    completed campaign to another campaign, as originally described in the
    section "The End...or Is It?" in the Night of the Zealot campaign guide.
  </p>

  <p>
    <i
      >Note: The standard rules of the game dictate that players start each
      campaign with a clean state (new decks and 0 experience). The following is
      an optional variant that is likely to affect the game’s balance. Only
      intrepid investigators who wish to embrace the chaos should choose this
      option.</i
    >
  </p>

  <p>
    When transferring one or more investigators from a completed campaign to a
    new campaign, players should observe the following rules:
  </p>

  <ul>
    <li>
      Not all surviving investigators in the original campaign need to be
      transferred. It is okay to transfer some and start fresh with others.
    </li>

    <li>
      Investigator decks remain the same. This includes all story assets and
      weaknesses earned in the original campaign, as well as experience gained
      and trauma suffered. Everything recorded in the campaign log under that
      investigator’s "Earned Story Assets / Weaknesses" should be transferred to
      the new campaign, as well.
    </li>

    <li>
      All other notes in the Campaign Log should be wiped clean and do not
      transfer to the new campaign.
    </li>

    <li>
      The chaos bag is reset. This includes all additional chaos tokens that
      were added to the chaos bag throughout the original campaign.
    </li>

    <li>
      If an investigator has an ability that occurs "at the beginning of the
      campaign," or "at deck creation," such as Father Mateo’s bonus experience,
      it does not trigger a second time upon transferring that investigator into
      a new campaign.
    </li>

    <li>
      Cards and Campaign Guides are written with the assumption that
      investigators are not being transferred from one campaign to another. For
      this reason, campaigns are sometimes referred to as "the campaign."
      <i>(For example, "for the remainder of the campaign...")</i>
      In general, when interpreting such effects, treat each campaign as being
      separate from one another. However, some effects should be interpreted as
      if each campaign played is part of one continuous uninterrupted campaign.
      This includes rules that dictate how an earned weakness or story asset
      operates, or additional rules that a specific investigator must follow.
      <i
        >(For example, "for the remainder of the campaign, the bearer of X
        weakness must only speak in French.")</i
      >
    </li>
  </ul>

  <h2 id="Cancel">Cancel</h2>

  <p>
    Some card abilities can "cancel" other card or game effects. Cancel
    abilities interrupt the initiation of an effect, and prevent the effect from
    initiating.
  </p>

  <ul>
    <li>
      Any time the effects of an ability are canceled, the ability (apart from
      its effects) is still regarded as initiated, and any costs have still been
      paid. The effects of the ability, however, are prevented from initiating
      and do not resolve.
    </li>

    <li>
      If the effects of an event card are canceled, the card is still regarded
      as played, and it is still placed in its owner's discard pile.
    </li>

    <li>
      If the effects of a treachery card are canceled, the card is still
      regarded as having been drawn, and it is still placed in the encounter
      discard pile.
    </li>
  </ul>

  <h2 id="Cannot">Cannot</h2>

  <p>
    The word "cannot" is absolute, and cannot be countermanded by other
    abilities.
  </p>

  <h2 id="Cardtypes">Cardtypes</h2>

  <p>
    The game's cardtypes are presented in Appendix IV, with detailed card
    anatomies (see "<a href="#Appendix_IV_Card_Anatomy"
      >Appendix IV: Card Anatomy</a
    >" on page 28).
  </p>

  <ul>
    <li>
      If an ability causes a card to change its cardtype, it loses all other
      cardtypes it might possess and functions as would any card of the new
      cardtype.
    </li>
  </ul>

  <p>
    See also: "<a href="#Asset_Cards">Asset Cards</a>" on page 4, "<a
      href="#Enemy_Cards"
      >Enemy Cards</a
    >" on page 10, "<a href="#Event_Cards">Event Cards</a>" on page 11, "<a
      href="#Location_Cards"
      >Location Cards</a
    >" on page 14, "<a href="#Skill_Cards">Skill Cards</a>" on page 18, "<a
      href="#Treachery_Cards"
      >Treachery Cards</a
    >" on page 20.
  </p>

  <h2 id="Challenge_Scenarios" style="color: var(--red)">
    Challenge Scenarios (added in <em>Parallel Investigators</em>)
  </h2>

  <p>
    Challenge scenarios are special print-and-play scenarios that utilize
    existing products in the <i>Arkham Horror: The Card Game</i> collection,
    along with additional print-and-play cards, to create new content. These
    scenarios are designed with certain prerequisites in mind, in order to craft
    a challenging puzzle-like experience.
  </p>

  <h2 id="Chaos_Tokens">Chaos Tokens</h2>

  <p>
    Chaos tokens are revealed from the chaos bag during skill tests, to modify
    or influence the results of the skill test.
  </p>

  <p>
    [skull] [cultist] [elder_thing] [tablet] – If any of these tokens are
    revealed for a skill test, resolve the effect for that symbol as indicated
    on the scenario reference card for the current scenario.
  </p>

  <p>
    [auto_fail] – This is the auto-fail token. If this token is revealed for a
    skill test, it indicates the investigator automatically fails the test (see
    "<a href="#Automatic_Failure_Success">Automatic Failure/Success</a>" on page
    5).
  </p>

  <p>
    [elder_sign] – This is the elder sign token. If this token is revealed for a
    skill test, resolve the [elder_sign] effect on the investigator card
    belonging to the player performing the skill test.
  </p>

  <p>
    If a revealed chaos token (or the effect referenced by a chaos token) has a
    numerical modifier, that modifier is applied to the investigator's skill
    value for this test.
  </p>

  <p>
    See "<a href="#Skill_Test_Timing">ST.3 Reveal chaos token</a>" on page 26.
  </p>

  <h3 id="Bless_and_Curse_Tokens" style="color: var(--red)">
    Bless and Curse Tokens (added in
    <em>The Innsmouth Conspiracy</em>)
  </h3>

  <p>
    This expansion introduces two new kinds of chaos tokens: bless ([bless])
    tokens and curse ([curse]) tokens. By default, the chaos bag does not
    contain any [bless] or [curse] tokens. However, certain card effects can add
    these tokens or remove them from the chaos bag.
  </p>

  <table>
    <tr>
      <td>
        <img
          src="/assets-v20260923/rules/ChaosToken_Bless.png"
          alt="Bless Token"
          width="72"
          height="72"
          class="center"
          loading="lazy"
        />
      </td>
      <td>
        <img
          src="/assets-v20260923/rules/ChaosToken_Curse.png"
          alt="Curse Token"
          width="72"
          height="72"
          class="center"
          loading="lazy"
        />
      </td>
    </tr>
  </table>

  <ul>
    <li>
      [bless] tokens revealed during a skill test have the following effects:
      "+2. Reveal another token. Instead of returning this token to the chaos
      bag, return it to the token pool."
    </li>

    <li>
      No more than 10 total [bless] tokens can be included in the chaos bag or
      sealed on cards in play at any given time.
    </li>

    <li>
      [curse] tokens revealed during a skill test have the following effects:
      "–2. Reveal another token. Instead of returning this token to the chaos
      bag, return it to the token pool."
    </li>

    <li>
      No more than 10 total [curse] tokens can be included in the chaos bag or
      sealed on cards in play at any given time.
    </li>

    <li>
      [bless] or [curse] tokens revealed outside of a skill test have no effect
      on their own unless otherwise specified by a card effect.
    </li>
  </ul>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Frequently Asked Questions')</span
    >
    <b>Frequently asked Bless and Curse questions:</b>
  </p>

  <ol>
    <li>
      <i
        >Do [bless] and [curse] tokens have a modifier or value if they are
        revealed outside of a skill test?</i
      >
      No. [bless] and [curse] tokens revealed outside of a skill test have no
      modifier or value.
    </li>

    <li>
      <i
        >If adding a certain number of [bless] or [curse] tokens to the chaos
        bag is part of an ability's effect, and there are not enough [bless] or
        [curse] tokens remaining to fulfill that effect, what happens?</i
      >
      You perform as much of the ability as you can, adding [bless] or [curse]
      tokens until there are none left to add.
    </li>

    <li>
      <i
        >If adding a certain number of [bless] or [curse] tokens to the chaos
        bag is part of a card/ability's cost, and there are not enough [bless]
        or [curse] tokens remaining to fulfill that cost, what happens?</i
      >
      If the cost cannot be paid, the card/ability therefore cannot be
      played/triggered.
    </li>

    <li>
      <i
        >During a campaign, do [bless] and [curse] tokens remain in the chaos
        bag from scenario to scenario?</i
      >
      No, [bless] and [curse] tokens do not carry over from scenario to
      scenario.
    </li>

    <li>
      <i
        >When exactly are [bless] and [curse] tokens removed from the chaos bag?
        Are they still present in the chaos bag during the resolution of a
        scenario?</i
      >
      [bless] and [curse] tokens should be removed from the chaos bag when the
      game is cleaned up after the resolution of a scenario. This occurs before
      moving onto any subsequent story interludes, unless otherwise noted. -
      FAQ, v.2.0, August 2022
    </li>
  </ol>

  <h3 id="Frost_Tokens" style="color: var(--red)">
    Frost Tokens (added in <em>Edge of the Earth</em>)
  </h3>

  <p>
    This expansion introduces a new type of chaos token: the frost ([frost])
    token. At the start of the
    <i>Edge of the Earth</i> campaign, the chaos bag contains only a few
    relatively harmless [frost] tokens, if any. As the expedition continues,
    depending on the decisions the investigators make and the events that
    unfold, more [frost] tokens may be added to (or removed from) the chaos bag,
    altering the difficulty of every test the investigators perform. The more
    frost tokens added to the chaos bag, the more crippling their effects
    become.
  </p>

  <img
    src="/assets-v20260923/rules/ChaosToken_Frost.png"
    alt="Curse Token"
    width="72"
    height="72"
    class="center"
    loading="lazy"
  />

  <ul>
    <li>
      The first [frost] token revealed from the chaos bag during a skill test
      has the following effect: "–1. Reveal another token." If another [frost]
      token is revealed from the chaos bag during the same test, immediately end
      the "reveal chaos tokens" step of the skill test and resolve the test as
      an automatic failure.
      <i
        >(Return all revealed [frost] tokens to the chaos bag after the test
        ends.)</i
      >
    </li>

    <li>
      <i
        >For example: Bob investigates a location and there are two [frost]
        tokens in the chaos bag. During Bob's first investigation attempt, he
        reveals a [frost] token. This reduces his skill value by 1 and causes
        him to reveal another token. The next token he reveals is a +1,
        resulting in a total of 0 from both tokens. Bob succeeds! Emboldened,
        Bob attempts to investigate a second time. This time, he reveals a
        [frost] token, followed by a second [frost] token. Bob must immediately
        stop revealing tokens and resolve the investigation as an automatic
        failure.</i
      >
    </li>

    <li>
      No more than eight total [frost] tokens can be included in the chaos bag
      and/or sealed on cards in play at any given time.
    </li>

    <li>
      A [frost] token revealed outside of a skill test has no effect on its own
      unless otherwise specified by a card effect.
    </li>

    <li>
      A [frost] token added to the chaos bag remains in the chaos bag from
      scenario to scenario unless removed by a card or game effect. Use the
      "Chaos Bag" section of the Campaign Log to record which tokens are
      currently in the chaos bag.
    </li>
  </ul>

  <h3 id="Resolving_Multiple_Revealed_Chaos_Tokens" style="color: var(--blue)">
    Resolving Multiple Revealed Chaos Tokens (added in FAQ, section 'Card
    Ability Interpretation', point 2.5)
  </h3>

  <p>
    If an investigator is instructed to "resolve" multiple revealed chaos
    tokens, any game or card effects which refer to "the revealed chaos token"
    in the singular should be construed to apply to each of the revealed chaos
    tokens. For example, when applying chaos symbol effects during Step 4 of a
    skill test or applying modifiers to an investigator’s skill value during
    Step 5 of a skill test, the effects and modifiers of all of the resolved
    chaos tokens should be applied, even though the rules state "the revealed
    chaos token." Similarly, any card effects that refer to "the revealed chaos
    token" refer to all of the resolved tokens.
  </p>

  <p>
    <i
      >For example: An investigator plays Premonition, which reads: "Put
      Premonition into play, reveal a random chaos token from the chaos bag, and
      seal it on Premonition." That investigator then uses Olive McBride to
      "reveal 3 chaos tokens instead of 1, choose 2 of those tokens to resolve,
      and ignore the other." In this case, both of the resolved tokens would be
      sealed on Premonition, even though Premonition only refers to the revealed
      token as a singular token. Likewise, when Premonition instructs that
      investigator to "Resolve the token sealed here as if it were just revealed
      from the chaos bag," the investigator should resolve both of the tokens
      sealed on it.</i
    >
  </p>

  <p>
    Additionally, when resolving multiple chaos tokens, any game or card effects
    which trigger if a certain chaos token is revealed - such as the text "If
    the named chaos token is revealed during this skill test..." on Recall the
    Future - will trigger if any of the resolved chaos tokens meet the specified
    conditions. Such an effect will not trigger twice if two of the designated
    tokens are resolved.
  </p>

  <p>
    Note that this entry only applies when multiple chaos tokens are "resolved."
    If multiple chaos tokens are revealed and all but 1 of them are canceled or
    ignored, this entry does not apply.
  </p>

  <h2 id="Checkpoints" style="color: var(--red)">
    Checkpoints (added in <em>Edge of the Earth</em>)
  </h2>

  <p>
    Some of the scenarios in the
    <i>Edge of the Earth</i> campaign are split into multiple parts. Players may
    choose to play these parts one at a time (with breaks between each part), or
    they may play multiple parts one after another as part of a longer session.
    Each part is its own game with its own setup and resolution.
  </p>

  <p>
    After completing one part of a scenario, the campaign guide directs the
    investigators to a Checkpoint that instructs them how to proceed. If the
    investigators wish to proceed directly to the next part of the scenario, the
    Checkpoint will instruct them how to clean up the game to prepare for the
    next part of the scenario. If the investigators wish to take a break and
    resume playing during their next game session, the Checkpoint will instruct
    them to record information in the Campaign Log that makes setup for the next
    session quick and easy.
  </p>

  <h2 id="Choices_and_the_Grim_Rule" style="color: var(--blue)">
    Choices, and the Grim Rule (added in FAQ, section 'Game Play', point 1.5)
  </h2>

  <p>
    When investigators are forced to make a choice and there are multiple valid
    options, the lead investigator decides between those options. The Grim Rule
    does not play a part in these choices.
  </p>

  <p>
    <i
      >For example: Locked Door reads “Attach to the location with the most
      clues, and without a Locked Door attached.” If there are 3 locations that
      are tied for the most clues, and none of them already have a Locked Door
      attached, the lead investigator decides between those 3 locations. Players
      are not forced to decide which of those 3 options would be the objectively
      worst option.</i
    >
  </p>

  <p>
    The Grim Rule only comes into effect if players are unable to find the
    answer to a rules or timing conflict, and are thus unable to continue
    playing the game. It is designed to keep the game moving when looking up the
    correct answer would be too time-consuming or inconvenient for the players.
    The Grim Rule is not an exhaustive answer to rules/timing conflicts.
  </p>

  <h2 id="Clues">Clues</h2>

  <p>
    Clues represent the progress the investigators can make towards solving a
    mystery, unraveling a conspiracy, and/or advancing in a scenario.
  </p>

  <ul>
    <li>
      The first time an investigator enters a location, that location is
      revealed (turned face-up) and a number of clues equal to that location's
      clue value are placed on that location (from the token pool). Most clue
      values are conveyed as a "per investigator ([per_investigator])" value.
      This may occur during setup.
    </li>

    <li>
      A clue at a location can be discovered by successfully investigating the
      location (see "<a href="#Investigate_Action">Investigate Action</a>" on
      page 13), or by a card ability. If an investigator discovers a clue, he or
      she takes the clue from the location and places it on his or her
      investigator card, under his or her control.
    </li>

    <li>
      If there are no "<strong>Objective</strong> – " requirements for advancing
      the current act, during any investigator's turn the investigators may, as
      a group, spend the requisite number of clues (usually conveyed as a "per
      investigator" value) from their investigator cards to advance the act
      deck. This is normally done as a [free] player ability. Any or all
      investigators may contribute any number of clues towards the total number
      of clues required to advance the act.
    </li>

    <li>
      A card ability that refers to clues "at a location" is referring to the
      undiscovered clues that are currently on that location.
    </li>
  </ul>

  <p>
    See also: "<a href="#Act_Deck_and_Agenda_Deck">Act Deck and Agenda Deck</a>"
    on page 3, "<a href="#Tokens">Tokens, Running out of</a>" on page 20.
  </p>

  <h3 id="Clues_on_Player_Cards" style="color: var(--blue)">
    Clues on Player Cards (added in FAQ, section 'Game Play', point 1.28)
  </h3>

  <p>
    Some card effects such as Kate Winthrop’s ability may place clues on a card
    controlled by an investigator. Clues that have been placed on a player card
    are still controlled by that player and may be spent as normal. If a game
    effect would cause a card with clues on it to leave play or leave an
    investigator’s control, place each clue on that card on its location.
  </p>

  <h2 id="Collection">Collection</h2>

  <p>
    If an ability refers to a player's collection
    <em>(for example, "search the collection")</em>, the collection of cards
    from which that player's deck was assembled is used.
  </p>

  <p>
    <em
      >Example: Sean and Etienne are each using a deck built from Sean's
      collection. If Etienne is instructed to "search the collection," he
      searches Sean's collection.</em
    >
  </p>

  <ul>
    <li>
      <span style="color: var(--blue)"
        >(Added in FAQ, section 'Rulebook Errata', v2.5)</span
      >
      The collection exists outside of the game. Effects that search the
      collection cannot search in-game areas, such as decks or set-aside cards.
    </li>

    <li>
      <span style="color: var(--blue)"
        >(Added in FAQ, section 'Rulebook Errata', v2.5)</span
      >
      If a player owns multiple copies of a single product, their collection is
      still only defined (for the purposes of game effects) as a single copy of
      each unique product they own.
    </li>
  </ul>

  <h2 id="Concealed_X" style="color: var(--red)">
    Concealed X (added in <em>The Scarlet Keys</em>)
  </h2>

  <p>
    Concealed X is a keyword that appears on some enemy cards in
    <i>The Scarlet Keys</i> campaign. Concealed enemies represent hidden enemies
    whose true location is a mystery until the investigators work to expose
    where - and in some cases, who - they truly are.
  </p>

  <p>
    When a scenario includes one or more concealed enemies, investigators are
    instructed to set aside several concealed mini-cards. These mini-cards are
    double-sided. The facedown side represents the possible location of a
    concealed enemy. The revealed side reveals the mini-card’s true nature - an
    enemy’s true location, or simply a decoy.
  </p>

  <p>
    When an investigator draws an enemy with the concealed X keyword (or is
    instructed to resolve an enemy’s concealed keyword), they spawn that enemy
    into a game area above the agenda deck, not at any location. This area is
    called "the shadows," and represents enemies the investigators know exist
    somewhere on the map, but are unsure where. Then, that investigator takes
    the set-aside concealed mini-card that matches that enemy, along with X
    decoys (where X is defined by that enemy’s concealed X value), shuffles them
    facedown, and puts them into play distributed as evenly as possible among
    each location in play, starting with the locations nearest to them. Then, at
    each of those locations that already had 1 or more concealed mini-cards,
    they shuffle each of them facedown as well.
  </p>

  <p>
    <i
      >For example: Amina draws Coterie Agent (A), which has "concealed 2." She
      first spawns the Coterie Agent into the shadows. Then, she takes the
      set-aside Coterie Agent (A) mini-card, along with 2 decoys, shuffles them
      facedown, and places one at each of the three locations nearest to her.
      Then, if any of those locations already had 1 or more concealed
      mini-cards, she would shuffle each concealed mini-card at those locations,
      as well.</i
    >
  </p>

  <p>Enemies in the shadows observe the following additional rules:</p>

  <ul>
    <li>
      Enemies in the shadows are considered to be in play, but not at any
      particular location. They cannot move until they leave the shadows.
    </li>

    <li>
      Enemies in the shadows can qualify as the "nearest" enemy, but only if
      there are no other enemies in play at any location.
    </li>

    <li>
      Enemies in the shadows cannot be damaged or leave play via player card
      effects.
    </li>
  </ul>

  <h2 id="Concealed_Mini_Cards" style="color: var(--red)">
    Concealed Mini-Cards (added in <em>The Scarlet Keys</em>)
  </h2>

  <p>
    While in play, concealed mini-cards represent the possible location of an
    enemy in the shadows. In order to deal with such an enemy, its true location
    must first be discovered by exposing its mini-card. This can be done via one
    of three methods: fighting, evading, or investigating.
  </p>

  <ul>
    <li>
      Concealed mini-cards are not enemies and cannot be engaged like enemies.
      However, any investigator at the same location as a concealed mini-card
      may attempt to expose it by successfully attacking it or evading it (as if
      it were an engaged enemy), or by successfully investigating its location.
      The difficulty to successfully attack or evade a concealed mini-card is
      equal to the shroud value of its location.

      <ul>
        <li>
          An investigator may also use a card effect that automatically evades
          an enemy, deals damage to an enemy, or discovers a clue at a location
          in order to instead expose a concealed mini-card.
        </li>
      </ul>
    </li>
    <li>
      If an investigator chooses to expose a concealed mini-card, that effect
      replaces the standard effects of the action or ability that exposed it.
      <i
        >(i.e., if an enemy’s mini-card is exposed by evasion or damage, the
        matching enemy is not evaded, nor does it take damage. If a mini-card is
        exposed by discovering clues or investigating, no clues are
        discovered.)</i
      >
    </li>

    <li>
      If a concealed mini-card is exposed (via any of the above methods), flip
      it to its revealed side.

      <ul>
        <li>If it is a decoy, set it aside, out of play, with no effect.</li>

        <li>
          If it is an enemy’s mini-card, that enemy is now exposed. Place the
          matching enemy in the shadows at that mini-card’s location, then set
          that mini-card aside, out of play.
          <i
            >(That enemy is no longer in the shadows, and is now at the location
            where its mini-card was located).</i
          >
          Then, if there are no other enemies in the shadows, set all remaining
          concealed mini-cards in play aside, out of play.
        </li>
      </ul>
    </li>
    <li>
      Only one concealed mini-card may be exposed per effect unless explicitly
      stated. (i.e., an effect that deals 3 damage to each enemy at a location
      does not expose all concealed mini-cards at that location; only one.)
    </li>
  </ul>

  <p>
    <i
      >For example: There is a Coterie Agent and a Coterie Assassin in the
      shadows. There is a concealed mini-card at Kymani’s location and another
      concealed mini-card at a connecting location. (1) First, Kymani plays an
      event that discovers a clue at their location, but instead of discovering
      a clue, they choose to expose the concealed mini-card at their location,
      flipping it over. That mini-card is a decoy, and is set aside without
      effect. (2) Next, they move to the connecting location with the other
      concealed mini-card and attempt to expose it using an evade action. They
      succeed and flip the mini-card over... revealing the Coterie Assassin’s
      mini-card! (3) The Coterie Assassin’s mini-card is set aside, and the
      Coterie Assassin in the shadows is moved to Kymani’s location, engaging
      them. Because there is another enemy in the shadows, they do not remove
      any of the other concealed mini-cards from play.</i
    >
  </p>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Frequently Asked Questions')</span
    >
    <b>Frequently asked Concealed Mini-Card questions:</b>
  </p>

  <ol>
    <li>
      <i
        >How many concealed mini-cards can I expose if I resolve an ability with
        multiple effects, such as Power Word with its Tonguetwister or Thrice
        Spoken commands, or Breaking and Entering?</i
      >
      An ability that contains multiple effects able to expose an enemy can have
      just one of those effects replaced with the exposure. A concealed
      mini-card may be exposed by successfully attacking it,
      successfully/automatically evading it, successfully investigating its
      location, automatically dealing damage to it, or automatically discovering
      a clue at its location. Any of these effects can be replaced with the
      exposing of one mini-card, and only one mini-card at a time can be exposed
      by such an effect. For example, Breaking and Entering has two effects:
      investigating and, if successful, automatically evading an enemy. Either
      of these effects may be replaced with exposing a concealed mini-card, but
      not both. Likewise, if you issue the Betray and Confess commands via Power
      Word’s Tonguetwister upgrade, only the damage or the clue discovery may be
      replaced with an exposure; the other effect is resolved as normal. This
      holds true even if issuing two commands to 3 enemies via Thrice Spoken:
      only 1 single concealed mini-card may be exposed even when resolving the
      effect for 3 different enemies.
    </li>

    <li>
      <i
        >Does a concealed mini-card count as an enemy for the purposes of card
        effects that depend on having an enemy at my location?</i
      >
      No. A concealed mini-card can be attacked or evaded "as if it were an
      engaged enemy", but for all other effects, it is not considered an enemy
      at the location. For example, if Trish Scarborough discovers a clue at a
      location with a concealed mini-card but no enemies, she is unable to
      trigger her [reaction] ability because the clue was not discovered at a
      location "with an enemy." Additionally, card effects that require an
      investigator to "choose an enemy", such as Expose Weakness, cannot be used
      to target a concealed mini-card.
    </li>
  </ol>

  <h2 id="Constant_Abilities">Constant Abilities</h2>

  <p>See "<a href="#Abilities_Constant">Ability</a>" on page 2.</p>

  <h2 id="Control">Control</h2>

  <p>
    See "<a href="#Ownership_and_Control">Ownership and Control</a>" on page 16.
  </p>

  <h2 id="Copy">Copy</h2>

  <p>
    A copy of a card is defined by title. A second copy of a card is any other
    card that shares the same title, regardless of cardtype, text, artwork, or
    any other differing characteristics between the cards.
  </p>

  <h2 id="Costs">Costs</h2>

  <p>
    There are two types of costs in the game: resource costs and ability costs.
  </p>

  <p>
    A card's resource cost is the numerical value that must be paid (in
    resources) to play the card from hand. To pay a resource cost, an
    investigator takes the specified number of resources from his or her
    resource pool and places them in the token pool.
  </p>

  <p>
    Some triggered card abilities are presented in a "cost: effect" construct.
    In such a construct, the aspect preceding the colon indicates the ability
    costs that must be paid and any triggering conditions that must be met to
    trigger the ability. The aspect following the colon is the effect.
  </p>

  <ul>
    <li>
      If multiple costs for a single card or ability require payment, those
      costs must be paid simultaneously.
    </li>

    <li>
      Only the controller of a card or ability may pay its costs. Game elements
      another player controls may not be used to pay a cost.
    </li>

    <li>
      When a player is exhausting, sacrificing, or otherwise using cards to pay
      costs, only cards that are in play and under that player’s control may be
      used, unless the cost specifies an out-of-play state.
    </li>

    <li>
      If a cost requires a game element that is not in play, the player paying
      the cost may only use game elements that are in his or her game areas
      (such as his or her hand or deck) to pay the cost.
    </li>

    <li>
      If the investigators are instructed to pay a cost as a group, each
      investigator (or each investigator in the group defined by the ability)
      may contribute to paying the cost.
    </li>

    <li>
      An ability cannot initiate – and therefore its costs cannot be paid – if
      the resolution of its effect will not change the game state.
    </li>

    <li>
      If an investigator takes damage or horror as a cost and reassigns any of
      it to an asset, the cost is still considered paid.
    </li>
  </ul>

  <h3 id="Ignoring_All_Costs" style="color: var(--blue)">
    "Ignoring all costs" (added in FAQ, section 'Card Ability Interpretation',
    point 2.24)
  </h3>

  <p>
    Some cards like Knowledge is Power or Word of Woe allow an investigator to
    play a card or activate an ability on an asset, "ignoring all costs." These
    effects only ignore the activation costs of an ability, such as [action]
    costs, resource costs, spending uses, etc. - in other words, anything
    written "before the colon." They do not ignore additional costs that must be
    paid when resolving that ability, or are otherwise written "after the
    colon;" these must be paid as normal. Effects or costs that exile a card
    and/or remove a card from the game cannot be ignored.
  </p>
  <p>
    <i
      >For example, if an investigator uses Knowledge is Power to activate the
      [action] ability on Old Book of Lore, Knowledge is Power allows you to
      ignore the action cost and exhausting of Old Book of Lore to activate its
      ability and search your deck for a card, but does not waive the additional
      cost to spend a secret to play that card. Likewise, playing Word of Woe
      waives the action cost to activate the ability on Earthly Serenity, but
      does not waive the cost to spend charges to heal an investigator at your
      location. Additionally, Pushed to the Limit does not allow an investigator
      to waive the cost of exiling Fire Extinguisher when resolving its second
      ability.</i
    >
  </p>

  <h3
    id="Costs_and_Restrictions_during_the_Initiation_Sequence"
    style="color: var(--blue)"
  >
    Costs and Restrictions during the Initiation Sequence (added in FAQ, section
    'Game Play', point 1.32)
  </h3>

  <p>
    When checking play restrictions and costs to determine whether a card may be
    played or an ability triggered, if the card or ability in question itself
    modifies those restrictions or costs during initiation or resolution such
    that they are able to be met or paid prior to taking effect, the preliminary
    confirmations are considered to have been successfully fulfilled.
  </p>

  <p>
    <i
      >For example: An investigator may play Spectral Razor targeting an
      unengaged enemy with Aloof, on the condition that they do subsequently
      fulfill the <b>Fight</b> action's restriction (that it cannot be performed
      against an unegaged Aloof enemy) via Spectral Razor's ability to engage
      that enemy.</i
    >
  </p>

  <h2 id="Customizable" style="color: var(--red)">
    Customizable (added in <em>The Scarlet Keys</em>)
  </h2>

  <p>
    Customizable is a keyword that appears on some player cards. Customizable
    cards might seem unremarkable at first, but have tremendous potential for
    improvement over the course of a campaign. By spending experience points,
    each one can be custom‑tailored to become a powerful tool in an
    investigator’s deck.
  </p>

  <p>
    Each customizable card starts at level 0 and has a separate sheet containing
    a checklist of upgrades that can be purchased using experience points. Each
    upgrade is accompanied by one or more checkboxes.
  </p>

  <p>
    Unless otherwise specified by a card effect, an investigator can only mark
    checkboxes on an upgrade sheet before or after a scenario, when they are
    upgrading their deck or purchasing new cards for their deck. Spending 1
    point of experience allows an investigator to mark one checkbox on one of
    their cards’ upgrade sheets.
  </p>

  <p>
    To purchase an upgrade, an investigator must mark all of an upgrade’s
    checkboxes. Once an upgrade is purchased,
    <i>each copy</i> of the card it is paired with is treated as having that
    upgrade (as a gained card ability) for that investigator only.
  </p>

  <p>
    <i
      >For example, Hunter’s Armor has the following upgrade: “Durable. Hunter’s
      Armor gets +2 health.” If 1 experience point is spent to check off one of
      the two boxes next to Durable, the upgrade is not yet purchased. After
      both boxes are marked (costing a total of 2 experience points), the
      upgrade is purchased, and each copy of Hunter’s Armor in that
      investigator’s deck is affected by the upgrade.</i
    >
  </p>

  <table>
    <tr>
      <td>
        <img
          class="card-scan"
          src="/img/arkham/zh/cards/09021.avif"
          alt="Hunter's Armor"
          loading="lazy"
        />
      </td>
      <td>
        <img
          class="card-scan"
          src="/assets-v20260923/rules/09021-upgradesheet.jpg"
          alt="Hunter's Armor - Upgradesheet"
          loading="lazy"
        />
      </td>
    </tr>
  </table>

  <ul>
    <li>
      A customizable card’s level is equal to half the total number of
      checkboxes marked on its upgrade sheet, rounded up.
      <i
        >(For example, a customizable card with three marked checkboxes is a
        level 2 card. Spending 3 experience to mark three more checkboxes would
        make it a level 3 card.) Note that this means some investigators are not
        able to upgrade a customizable card past a certain point, if their
        deckbuilding options would forbid them from including the card in their
        deck after the upgrade is made.</i
      >
    </li>

    <li>
      An upgrade sheet cannot have more than a total of 10 checkboxes marked.
      <i
        >(This means that the maximum number of experience points that may be
        spent on a particular customizable card is 10, and its maximum level is
        5.)</i
      >
    </li>

    <li>
      Spending experience points on one or more upgrades for a customizable card
      already in an investigator’s deck is considered to be "upgrading" a card
      for the purposes of card effects.
    </li>

    <li>
      An investigator may directly purchase one or more copies of a new
      customizable card with one or more upgrades by spending only the amount of
      experience points required to purchase those upgrades.
      <i
        >(Doing so counts as purchasing a new card, not upgrading an existing
        card.)</i
      >
    </li>

    <li>
      Upgrades for customizable cards are considered to be present on a card at
      all times (even while the card is in an out-of-play area, such as an
      investigator’s hand or discard pile).
    </li>

    <li>
      Spending 1 or more experience points on upgrades on a customizable card’s
      upgrade sheet is permanent and cannot be refunded.
    </li>

    <li>
      During gameplay, upgrade sheets should be placed in an out-of-play area
      nearby, so they can be quickly referenced.
      <i
        >(Alternatively, if playing with opaque card sleeves, investigators may
        sleeve the upgrade sheet behind the card it modifies, so they can
        quickly access it whenever they need.)</i
      >
    </li>

    <li>
      Additional printer-friendly upgrade sheets can be downloaded and printed
      from
      <a href="www.FantasyFlightGames.com">Fantasy Flight Games</a>.
    </li>
  </ul>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Frequently Asked Questions')</span
    >
    <b>Frequently asked Customizable questions:</b>
  </p>

  <ol>
    <li>
      <i
        >If I exile the last copy of an upgraded customizable card from my deck,
        would it retain those upgrades if I repurchase the card?</i
      >
      No. If all copies of a customizable card are removed from your deck, any
      upgrades on the upgrade sheet are also removed. If those cards are later
      repurchased, treat them as newly purchased cards with blank upgrade
      sheets.
    </li>

    <li>
      <i
        >If I have 2 copies of an upgraded customizable card in my deck, and
        exile 1 of them, what would be the experience cost to repurchase that
        card?</i
      >
      You have two options to repurchase an exiled customizable card: either
      paying the cost of the card as indicated by its upgrade sheet, or if
      you're able, spending experience on the card's upgrade sheet to add a copy
      of that card for free to your deck.
    </li>

    <li>
      <i
        >If I play or take control of another investigator's customizable card,
        does that card retain its upgrades?</i
      >
      Yes. Any upgrades purchased for a customizable card by its owner are
      considered to be printed on that card, regardless of who plays or controls
      it.
    </li>
  </ol>

  <h2 id="Day_and_Night" style="color: var(--red)">
    Day [day] and Night [night] (added in <em>The Feast of Hemlock Vale</em>)
  </h2>

  <p>
    During setup during The Feast of Hemlock Vale campaign, players may be
    instructed to put the Time Marker card into play. To do so, find the Time
    Marker card in the
    <i>The First Day</i>, <i>The Second Day</i>, or
    <i>The Third Day</i> encounter sets that corresponds to the current day and
    place it next to the agenda deck. This is the current day and time.
  </p>

  <p>
    Some cards have different effects depending on whether the scenario takes
    place during the Day or Night. Text following a (<b>Day [day]</b>) or
    (<b>Night [night]</b>) keyword is only active if the scenario or prelude being
    played is during the Day or Night, respectively. Any other ability not
    preceded by these keywords is active regardless of the time period.
  </p>

  <p>
    Setup instructions may have specific instructions depending on the current
    day and time. <i>(e.g.</i> "If it is <b>Day 2</b>, put River Hawthorne into
    play at the Cranberry Bog"
    <i>only applies when playing that scenario as a</i> <b>Day 2</b>
    <i>scenario and not a</i> <b>Night 2</b>
    <i>scenario).</i>
  </p>

  <h2 id="Dealing_Damage_Horror">Dealing Damage/Horror</h2>

  <p>
    There are two types of afflictions that may beset an investigator in the
    game: damage and horror. Damage afflicts an investigator's health, and
    horror afflicts an investigator's sanity.
  </p>

  <p>
    When an investigator or enemy is dealt damage and/or horror, follow these
    steps, in order:
  </p>

  <p>
    <strong>1. Assign Damage/Horror:</strong> Determine the amount of damage
    and/or horror being dealt. Place damage and/or horror tokens equal to the
    amount of damage and horror being dealt next to the cards that will be
    taking the damage/horror.
  </p>

  <ul>
    <li>
      When an investigator is dealt damage or horror, that investigator may
      assign it to eligible asset cards he or she controls. To be eligible, an
      asset card must have health in order to be assigned damage, and it must
      have sanity in order to be assigned horror.
    </li>

    <li>
      An asset cannot be assigned damage beyond the amount of damage it would
      take to defeat the card, and cannot be assigned horror beyond the amount
      of horror it would take to defeat the card.
    </li>

    <li>
      All damage/horror that cannot be assigned to an asset must be assigned to
      the investigator.
    </li>
  </ul>

  <p>
    <strong>2. Apply Damage/Horror:</strong> Any assigned damage/horror that has
    not been prevented is now placed on each card to which it has been assigned,
    simultaneously. If no damage/horror is applied in this step, no
    damage/horror has been successfully dealt.
  </p>

  <ul>
    <li>
      Abilities that prevent, reduce, or reassign damage and/or horror that is
      being dealt are resolved between steps 1 and 2.
    </li>

    <li>
      After applying damage/horror, if an investigator has damage equal to or
      higher than his or her health or horror equal to or higher than his or her
      sanity, he or she is defeated. When an investigator is defeated, he or she
      is eliminated from the scenario (see "<a href="#Elimination"
        >Elimination</a
      >" on page 10).
    </li>

    <li>
      After applying damage/horror, if an enemy has damage equal to or higher
      than its health, it is defeated and placed in the encounter discard pile
      (or in its owner's discard pile if it is a weakness).
    </li>

    <li>
      After applying damage/horror, if an asset has damage equal to or higher
      than its health or horror equal to or higher than its sanity, it is
      defeated and placed in its owner's discard pile.
    </li>
  </ul>

  <p>
    See also "<a href="#Interpreting_You_When_Taking_or_Being_Dealt_Damage"
      >Interpreting "You" When Taking or Being Dealt Damage</a
    >".
  </p>

  <h2 id="Deck">Deck</h2>

  <p>
    There are 4 main types of decks that appear in any game: the Investigator
    Deck, the Encounter Deck, the Act Deck, and the Agenda Deck.
  </p>

  <ul>
    <li>
      The order of cards within a deck may not be altered unless a player is
      instructed to do so by a card ability.
    </li>
  </ul>

  <p>
    See also: "<a href="#Investigator_Deck">Investigator Deck</a>" on page 13,
    "<a href="#Encounter_Deck">Encounter Deck</a>" on page 10, "<a
      href="#Act_Deck_and_Agenda_Deck"
      >Act Deck and Agenda Deck</a
    >" on page 3.
  </p>

  <h2 id="Deckbuilding">Deckbuilding</h2>

  <p>When building a custom deck, the following guidelines must be observed:</p>

  <ul>
    <li>A player must choose exactly 1 investigator card.</li>

    <li>
      A player's investigator deck must include the exact number of player cards
      indicated on the back of his or her investigator card as the "Deck Size."
      Weaknesses, investigator-specific cards, and scenario cards that are added
      to a player's deck do not count towards this number.
    </li>

    <li>
      A player's investigator deck may not include more than 2 copies (by title)
      of any given player card.
    </li>

    <li>
      Each standard player card in a player's investigator deck must be chosen
      from among the "Deckbuilding Options" available on the back of his or her
      investigator card.
    </li>

    <li>
      Most investigators have 0 experience to spend at the beginning of a
      campaign, which means that they may only include level 0 cards in their
      decks. Some investigators, and/or some campaigns, may provide a player
      with additional experience at the beginning of a campaign, which can be
      used immediately to purchase higher level cards (see "<a
        href="#Campaign_Play"
        >Campaign Play</a
      >" on page 5).
    </li>

    <li>
      All other "Deckbuilding Requirements" listed on the back of a player's
      investigator card must be observed.
    </li>

    <li>
      Each required random basic weakness is added to a player's deck at the end
      of the deckbuilding process.
    </li>

    <li>
      Story Assets may not be included in a player's deck unless the setup or
      resolution of a scenario grants that player permission to do so. These
      assets are indicated by the lack of a card level and the presence of an
      encounter set symbol (see "<a href="#Asset_Cards">Asset Cards</a>" on page
      4).
    </li>

    <li>
      During a campaign, players build a deck before playing the first scenario.
      In between scenarios, players can purchase new cards or upgrade cards in
      their deck following the rules found under "<a href="#Campaign_Play"
        >Campaign Play</a
      >" on page 5.
    </li>
  </ul>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Game Play', point 1.18)</span
    >
    If 1 or more cards are forcibly removed from an investigator’s deck and
    returned to the collection (such as when a card is exiled, or when a
    campaign effect forces an investigator to remove cards from their deck),
    that investigator must purchase cards so that a legal deck size is
    maintained. When purchasing cards in this manner, that investigator may
    purchase level 0 cards at 0 experience cost until a legal deck size is
    reached.
  </p>

  <ul>
    <li>
      This rule also applies if an effect alters an investigator’s deck size,
      deckbuilding restrictions, or deckbuilding options such that 1 or more
      cards must be removed from or added to their deck as a result.
    </li>
  </ul>

  <h3 id="Classes">Classes</h3>

  <p>
    Most player cards, including investigators, belong to one of 5 classes. Each
    class has its own distinct flavor and identity, as described below.
  </p>

  <p>
    Guardians ([guardian]) feel compelled to defend humanity, and thus go out of
    their way to combat the forces of the Mythos. They have a strong sense of
    duty and selflessness that drives them to protect others, and to hunt
    monsters down.
  </p>

  <p>
    Mystics ([mystic]) are drawn to and influenced by the arcane forces of the
    Mythos. Many have spell-casting abilities, able to manipulate the forces of
    the universe through magical talent.
  </p>

  <p>
    Rogues ([rogue]) are self-serving and out for themselves. Wily and
    opportunistic, they are always eager for a way to exploit their current
    situation.
  </p>

  <p>
    Seekers ([seeker]) are primarily concerned with learning more about the
    world and about the Mythos. They wish to research forgotten lore, map out
    uncharted areas, and study strange creatures.
  </p>

  <p>
    Survivors ([survivor]) are everyday people in the wrong place at the wrong
    time, simply trying to survive. Ill-prepared and ill-equipped, Survivors are
    the underdogs, who rise to the occasion when their lives are threatened.
  </p>

  <p>
    Some cards are not affiliated with any class; these cards are neutral.
    Generally, investigators only have access to cards from their class.
  </p>

  <p>
    Some investigators have access to cards from other classes. Refer to the
    "Deckbuilding Options" on the back of an investigator card to view which
    cards an investigator has access to.
  </p>

  <h3 id="Synergy_and_Neutral_Cards" style="color: var(--blue)">
    Synergy and Neutral Cards (added in FAQ, section 'Card Ability
    Interpretation', point 2.27)
  </h3>

  <p>
    Cards with the <b><i>Synergy</i></b> trait do not consider Neutral
    (classless) player cards when identifying the number of different classes
    among cards an investigator controls.
  </p>

  <h3 id="Deckbuilding_Options" style="color: var(--blue)">
    Deckbuilding Options (added in FAQ, section 'Game Play', point 1.15)
  </h3>

  <p>
    The following section clarifies how certain investigators’ deckbuilding
    options function.
  </p>

  <ul>
    <li>
      If one of the categories of an investigator’s deckbuilding options
      contains the word "other" in it, cards only fall into this category if
      they fall into no other category.
      <i
        >(For example, if an investigator’s deckbuilding options reads:
        "Guardian cards level 0–5, up to 10 other <b>Weapon</b> cards," then a
        Guardian card with the <b>Weapon</b> trait would not occupy one of those
        10 limited slots, because it first falls into the unlimited Guardian
        category).</i
      >
    </li>

    <li>
      If one of the categories of an investigator’s deckbuilding options lists
      card text in it, cards fall into this category if the listed text appears
      in the card in any capacity, even if it is circumstantial.
      <i
        >(For example, if an investigator’s deckbuilding options reads: "cards
        that 'heal horror' level 0–5," any card with an ability that heals any
        amount of horror will fall into this category, even if it only heals
        horror under specific circumstances.)</i
      >
    </li>
  </ul>

  <h3
    id="Purchasing_Player_Cards_with_Deckbuilding_Effects"
    style="color: var(--blue)"
  >
    Purchasing Player Cards with Deckbuilding Effects (added in FAQ, section
    'Game Play', point 1.37)
  </h3>

  <p>
    When purchasing cards between scenarios, each card is purchased one at a
    time. If a card is purchased that has abilities that affect deckbuilding,
    upgrading, or purchasing cards, those abilities immediately come into effect
    for the current purchasing period.
  </p>

  <p>
    <i
      >For example: Purchasing Adaptable allows an investigator to swap level 0
      cards immediately. Purchasing Underworld Market immediately increases an
      investigator's Deck Size.</i
    >
  </p>

  <table>
    <tr>
      <td>
        <img
          class="card-scan"
          src="/img/arkham/zh/cards/02110.avif"
          alt="Adaptable"
          loading="lazy"
        />
      </td>
      <td>
        <img
          class="card-scan"
          src="/img/arkham/zh/cards/09077.avif"
          alt="Underworld Market"
          loading="lazy"
        />
      </td>
    </tr>
  </table>

  <h2 id="Defeat">Defeat</h2>

  <p>
    Taking damage and/or horror may cause an investigator, enemy, or asset to be
    defeated.
  </p>

  <ul>
    <li>
      If an investigator has as much or more damage on it as it has health (or
      as much or more horror on it as it has sanity), that investigator is
      defeated. An investigator might also be defeated by a card ability. When
      an investigator is defeated, he or she is eliminated from the scenario
      (see "<a href="#Elimination">Elimination</a>" on page 10).
    </li>

    <li>
      In campaign play, an investigator that is defeated by taking damage equal
      to his or her health suffers 1 physical trauma. An investigator that is
      defeated by taking horror equal to his or her sanity suffers 1 mental
      trauma. Taking trauma may cause an investigator to be
      <strong>killed</strong> or driven <strong>insane</strong> (see "<a
        href="#Campaign_Play"
        >Campaign Play</a
      >" on page 5 for more information).
    </li>

    <li>
      If an enemy has as much or more damage on it as it has health, that enemy
      is defeated and placed on the encounter discard pile (or on its owner's
      discard pile if it is a weakness).
    </li>

    <li>
      If an asset with a health value has as much or more damage than it has
      health, it is defeated. If an asset with a sanity value has as much or
      more horror than it has sanity, it is defeated. A defeated asset is placed
      on its owner's discard pile.
    </li>
  </ul>

  <h2 id="Delayed_Effects">Delayed Effects</h2>

  <p>
    Some abilities create delayed effects. Such abilities specify a future
    timing point, or indicate a future condition that may arise, and dictate an
    effect that will happen at that time.
  </p>

  <ul>
    <li>
      Each delayed effect initiates automatically and immediately (as a forced
      ability) if its future timing point or future condition occurs.
    </li>

    <li>
      A delayed effect affects all specified entities that are in the specified
      game area and eligible at the time the delayed effect resolves.
    </li>
  </ul>

  <h2 id="Different" style="color: var(--blue)">
    "Different" (added in FAQ, section 'Card Ability Interpretation', point
    2.17)
  </h2>

  <p>
    Some card abilities refer to "different" cards. Different cards are cards
    with different titles (excluding subtitles).
    <i
      >(e.g. two copies of Ward of Protection are not considered to be
      "different," even if they have different levels.)</i
    >
  </p>

  <p>
    Some card abilities refer to "different" actions or "different" abilities.
    An ability or action is different from another ability/action if the two are
    non‑identical abilities, separate abilities on the same card, or abilities
    on two different cards.
    <i
      >(e.g. the two separate fight abilities on Sledgehammer are different from
      one another, however identical fight abilities on two copies of Machete
      are not different from one another, nor are two basic fight actions).</i
    >
  </p>

  <ul>
    <li>
      The exception to this rule is locations. Separate location cards are, by
      their very nature, not the same location. Therefore, multiple copies of
      locations with the same title are still considered to be different
      locations.
    </li>
  </ul>

  <h2 id="Difficulty_level">Difficulty (level)</h2>

  <p>
    There are four levels of difficulty in
    <em>Arkham Horror: The Card Game</em>: Easy, Standard, Hard, and Expert. At
    the beginning of a campaign or standalone scenario, the players choose which
    difficulty level to use. The campaign setup section of that campaign or
    scenario's Campaign Guide indicates which chaos tokens should be placed into
    the chaos bag when playing on each difficulty level.
  </p>

  <ul>
    <li>
      When playing in Easy or Standard mode, use the "Easy/Standard" side of
      each scenario's reference card. When playing in Hard or Expert mode, use
      the "Hard/Expert" side of each scenario's reference card instead.
    </li>
  </ul>

  <h2 id="Difficulty_skill_tests">Difficulty (skill tests)</h2>

  <p>
    The difficulty of a skill test is the target number an investigator is
    trying to equal or exceed with his or her modified skill value to pass that
    test.
  </p>

  <ul>
    <li>
      When attacking an enemy, the base difficulty of the skill test is the
      enemy's fight value.
    </li>

    <li>
      When investigating a location, the base difficulty of the skill test is
      the location's shroud value.
    </li>

    <li>
      When attempting to evade an enemy, the base difficulty for the skill test
      is the enemy's evade value.
    </li>

    <li>
      When resolving a skill test created by a card ability, the base difficulty
      is indicated as a parenthetical value following the indication of which
      skill is being tested. <em>For example: Intellect (3).</em>
    </li>
  </ul>

  <p>
    See "<a href="#Skill_Test_Timing">Skill Test Timing</a>" on page 26 for the
    full rules on skill tests.
  </p>

  <h2 id="Direct_Damage_Direct_Horror">Direct Damage, Direct Horror</h2>

  <p>
    If an ability causes a card to take direct damage or direct horror, that
    damage or horror must be assigned directly to the specified card, and cannot
    be assigned or re-assigned elsewhere.
  </p>

  <h2 id="Discard_Piles">Discard Piles</h2>

  <p>
    Any time a card is discarded, it is placed faceup on top of its owner's
    discard pile. Encounter cards are owned by the encounter deck.
  </p>

  <ul>
    <li>Each discard pile is an out-of-play area.</li>

    <li>
      Each investigator has his or her own discard pile, and the encounter deck
      has its own discard pile.
    </li>

    <li>
      Each discard pile is open information, and may be looked at by any player
      at any time.
    </li>

    <li>
      The order of cards in a discard pile may not be altered unless a player is
      instructed to do so by a card ability.
    </li>

    <li>
      If multiple cards are discarded simultaneously, the owner of the cards may
      physically place them on top of his or her discard pile one at a time, in
      any order. If multiple encounter cards are discarded simultaneously, they
      are placed on top of the encounter discard pile in any order (determined
      by lead investigator).
    </li>

    <li>
      Any ability that would shuffle a discard pile of zero cards back into a
      deck does not shuffle the deck.
    </li>

    <li>
      <span style="color: var(--blue)"
        >(Added in FAQ, section 'Game Play', point 1.13)</span
      >
      A single card cannot be shuffled into an empty player deck or encounter
      deck via card effect. If this shuffling would occur during the playing or
      revelation of a card that is typically discarded after it is resolved,
      such as an event or treachery card, it is discarded. Otherwise, the card
      remains in its current game area.
    </li>
  </ul>

  <h2 id="Doom">Doom</h2>

  <p>
    Doom represents the progress the forces of the Mythos make towards
    completing foul rituals, summoning cosmic entities, and/or advancing a
    scenario's agenda.
  </p>

  <ul>
    <li>
      During each Mythos phase, 1 doom is placed on the current agenda (see "<a
        href="#Mythos_Phase"
        >I. Mythos phase</a
      >" on page 24).
    </li>

    <li>
      If there are no "<strong>Objective</strong> – " requirements for advancing
      the current agenda and the requisite amount of doom is in play (among the
      agenda and all cards in play), the agenda advances during the "Check doom
      threshold" step of the Mythos phase. Unless a card otherwise specifies
      that it can advance the agenda, this is the only time at which the agenda
      can advance.
    </li>

    <li>
      Doom on cards other than the agenda (such as enemies, allies, locations,
      etc.) counts towards the amount of doom in play.
    </li>
  </ul>

  <p>
    See also: "<a href="#Act_Deck_and_Agenda_Deck">Act Deck and Agenda Deck</a>"
    on page 3, "<a href="#Tokens">Tokens, Running out of</a>" on page 20.
  </p>

  <h2 id="Doubt_and_Conviction" style="color: var(--red)">
    Doubt and Conviction (added in <em>The Path to Carcosa</em>)
  </h2>

  <p>
    Some story resolutions and interludes in
    <i>The Path to Carcosa</i> campaign instruct the players to "Mark one
    <b>Doubt</b>" or "Mark one <b>Conviction</b>" in their Campaign Log. This is
    done by filling in one of the boxes next to "<b>Doubt</b>" or "<b
      >Conviction</b
    >
    at the bottom of the Campaign Log.
  </p>

  <p>
    Later in the campaign, some scenarios may be changed or altered depending on
    whether the investigators "have more
    <b>Doubt</b> than <b>Conviction</b>" or "have more <b>Conviction</b> than
    <b>Doubt</b>." The investigators have more <b>Doubt</b> than
    <b>Conviction</b> if the number of boxes filled in next to <b>Doubt</b> is
    greater than the number of boxes filled in next to <b>Conviction</b> (and
    vice versa). <b>Doubt</b> and <b>Conviction</b> are shared among all of the
    investigators, and they are not tied to any specific investigator.
    <b>Doubt</b> and <b>Conviction</b> have no game effect except when
    explicitly referenced by the Campaign Guide or by a card effect.
  </p>

  <h2 id="Draw_Action">Draw Action</h2>

  <p>
    "Draw" is an action an investigator may take during his or her turn in the
    investigation phase.
  </p>

  <p>
    When an investigator takes this action, that investigator draws one card
    from his or her deck.
  </p>

  <h2 id="Drawing_Cards">Drawing Cards</h2>

  <p>
    When a player is instructed to draw one or more cards, those cards are drawn
    from the top of his or her investigator deck and added to his or her hand.
  </p>

  <p>
    When a player is instructed to draw one or more encounter cards, those cards
    are drawn from the top of the encounter deck, and resolved following the
    rules for drawing encounter cards under framework step "<a
      href="#Mythos_Phase"
      >1.4 Each investigator draws 1 encounter card</a
    >" on page 24.
  </p>

  <ul>
    <li>
      When a player draws two or more cards as the result of a single ability or
      game step, those cards are drawn simultaneously. If a deck empties
      middraw, reset the deck and complete the draw.
    </li>

    <li>
      There is no limit to the number of cards a player may draw each round.
    </li>

    <li>
      If an investigator with an empty investigator deck needs to draw a card,
      that investigator shuffles his or her discard pile back into his or her
      deck, then draws the card, and upon completion of the entire draw takes
      one horror.
    </li>

    <li>
      <span style="color: var(--blue)"
        >(Added in FAQ, section 'Card Ability Interpretation', point 2.14,
        "Draw" vs "Add to hand")</span
      >
      If a card explicitly adds a card to an investigator’s hand without using
      the word "draw," it does not count as "drawing" a card for the purposes of
      other card effects.
      <i
        >(Note that some abilities such as relevation abilities on weaknesses
        and <b>Dilemma</b> cards trigger regardless of whether the card is
        "drawn" or "added" to your hand.)</i
      >
    </li>
  </ul>

  <h2 id="Effects">Effects</h2>

  <p>
    A card effect is any effect that arises from the resolution of ability text
    printed on, or gained by, a card. A framework effect is any effect that
    arises from the resolution of a framework event (see "<a
      href="#Framework_Event_Details"
      >Framework Event Details</a
    >" on page 24).
  </p>

  <ul>
    <li>
      Card effects may be preceded by costs, triggering conditions, play
      restrictions, and/or play permissions; such elements are not considered
      effects (see "<a href="#Ability">Ability</a>" on page 2).
    </li>

    <li>
      Once initiated, players must resolve as much of each aspect of the effect
      as they are able, unless the effect uses the word "may."
    </li>

    <li>
      When a non-targeting effect attempts to interact with a number of entities
      (such as "draw 3 cards" or "search the top 5 cards of your deck") that
      exceeds the number of entities that currently exist in the specified game
      area, the effect interacts with as many entities as possible.
    </li>

    <li>
      The expiration of a lasting effect (or the cessation of a constant
      ability) is not considered to be generating a game state change by a card
      effect.
    </li>

    <li>
      All aspects of an effect have timing priority over all "after..."
      triggering conditions that might arise as a consequence of that effect.
      <em
        >(For example, if an effect reads "Gain 3 resources and draw 3 cards,"
        resolve both aspects of the effect (gaining resources and drawing cards)
        before initiating an ability that reads "After drawing a card...")</em
      >
    </li>
  </ul>

  <p>
    See also: "<a href="#Delayed_Effects">Delayed Effects</a>" on page 8, "<a
      href="#Lasting_Effects"
      >Lasting Effects</a
    >" on page 14, "<a href="#Priority_of_Simultaneous_Resolution"
      >Priority of Simultaneous Resolution</a
    >" on page 17.
  </p>

  <h2 id="Elimination">Elimination</h2>

  <p>
    A player is eliminated from a scenario any time his or her investigator is
    defeated, or if he or she resigns. The only manner in which eliminated
    investigators interact with the game is when establishing "per investigator"
    values (see "<a href="#Per_Investigator">Per Investigator</a>" on page 16).
    Any time a player is eliminated:
  </p>

  <ol start="0">
    <li>
      For the purpose of resolving weakness cards, the game has ended for the
      eliminated investigator. Trigger any “when the game ends” abilities on
      each weakness the eliminated investigator owns that is in play. Then,
      remove those weaknesses from the game.
    </li>

    <li>
      The cards he or she controls in play and all of the cards in his or her
      out-of-play areas (such as hand, deck, discard pile) are removed from the
      game.
      <ul>
        <li>
          Any card that player owns but does not control that is in play remains
          in play, but if that card leaves play it is removed from the game.
        </li>
      </ul>
    </li>

    <li>
      All clue tokens that player possesses are placed at the location the
      investigator was at when he or she was eliminated, and all of that
      player's resource tokens are returned to the token pool.
    </li>

    <li>
      All enemies engaged with that player are placed at the location the
      investigator was at when he or she was eliminated, unengaged but otherwise
      maintaining their current game state.
    </li>

    <li>
      All other cards in the eliminated investigator's threat area are placed in
      the appropriate discard pile.
    </li>

    <li>
      If the lead investigator is eliminated, the remaining players (if any)
      choose a new lead investigator.
    </li>

    <li>
      If there are no remaining players, the scenario ends. Refer to "no
      resolution was reached" entry for that scenario in the campaign guide.
    </li>
  </ol>

  <h2 id="Elusive" style="color: var(--red)">
    Elusive (added in <em>The Feast of Hemlock Vale</em>)
  </h2>

  <p>
    Elusive is a keyword ability that appears on some enemies in this expansion.
    Elusive enemies represent enemies who want to avoid the investigators for
    their own survival or to accomplish their own goals.
  </p>

  <p>
    If a ready enemy with the elusive keyword attacks or is attacked, after that
    attack resolves, that enemy immediately disengages from all investigators,
    moves to a connecting location (with no investigators if able), and
    exhausts.
  </p>

  <ul>
    <li>
      This effect occurs whether the enemy was engaged with the attacking
      investigator or not.
    </li>
  </ul>

  <h2 id="Empty_Location">Empty Location</h2>

  <p>An empty location is a location with no enemies or investigators at it.</p>

  <h2 id="Encounter_Cards_Vs_Scenario_Cards" style="color: var(--blue)">
    "Encounter Cards" vs "Scenario Cards" (added in FAQ, section 'Card Ability
    Interpretation', point 2.15)
  </h2>

  <p>
    These two terms are used interchangeably to mean any non-player card used in
    a scenario, such as the contents of the encounter deck, locations, acts,
    agendas, the scenario reference card, etc.
  </p>

  <h2 id="Encounter_Deck">Encounter Deck</h2>

  <p>
    The encounter deck contains the encounter cards (enemy, treachery, and story
    asset cards) the investigators may encounter during a scenario.
  </p>

  <ul>
    <li>
      If the encounter deck is empty, shuffle the encounter discard pile back
      into the encounter deck.
    </li>
  </ul>

  <h2 id="Encounter_Set">Encounter Set</h2>

  <p>
    An encounter set is a collection of encounter cards, denoted by a common
    encounter set symbol near each card's cardtype.
  </p>

  <h2 id="Enemy_Cards">Enemy Cards</h2>

  <p>
    Enemies represent villains, cultists, ne'er-do-wells, terrible monsters, and
    unfathomable entities from alternate dimensions or the cosmos beyond. When
    an enemy card is drawn by an investigator, that investigator must spawn it
    following any spawn direction the card bears (see "<a href="#Spawn">Spawn</a
    >" on page 19). If the encountered enemy has no spawn direction, the enemy
    spawns engaged with the investigator encountering the card and is placed in
    that investigator's threat area.
  </p>

  <p>
    See "<a href="#Mythos_Phase">1.4 Each investigator draws 1 encounter card</a
    >" on page 24.
  </p>

  <ul>
    <li>
      A ready, unengaged enemy engages any time it is at the same location as an
      investigator (see "<a href="#Enemy_Engagement">Enemy Engagement</a>" on
      page 10).
    </li>

    <li>
      If an investigator is engaged with a ready enemy and takes an action other
      than to <strong>fight</strong>, to <strong>evade</strong>, or to activate
      a <strong>parley</strong> or <strong>resign</strong> ability, that enemy
      makes an attack of opportunity (see "<a href="#Attack_of_Opportunity"
        >Attack of Opportunity</a
      >" on page 5).
    </li>

    <li>
      Enemies with the hunter keyword move during the Enemy Phase (see "<a
        href="#Enemy_Phase"
        >III. Enemy phase</a
      >" on page 25).
    </li>

    <li>
      Engaged enemies attack during the Enemy Phase (see "<a href="#Enemy_Phase"
        >III. Enemy phase</a
      >" on page 25).
    </li>
  </ul>

  <h2 id="Enemy_Engagement">Enemy Engagement</h2>

  <p>
    While an enemy card is in play, it is either engaged with an investigator
    (and placed in that investigator's threat area), or it is unengaged and at a
    location (and placed at that location). Each enemy in an investigator's
    threat area is considered to be at the same location as that investigator,
    and should the investigator move, the enemy remains engaged and moves to the
    new location simultaneously with the investigator.
  </p>

  <p>
    Any time a ready unengaged enemy is at the same location as an investigator,
    it engages that investigator, and is placed in that investigator's threat
    area. If there are multiple investigators at the same location as a ready
    unengaged enemy, follow the enemy's prey instructions to determine which
    investigator is engaged. There is no limit on the number of enemies that can
    be engaged with a single investigator.
  </p>

  <p>
    <em> For example, a ready unengaged enemy immediately engages if: </em>
  </p>

  <ul>
    <li>
      <em>It spawns at the same location as an investigator,</em>
    </li>

    <li>
      <em> It moves into the same location as an investigator, </em>
    </li>

    <li>
      <em> An investigator moves into the same location as it. </em>
    </li>
  </ul>

  <p>
    An exhausted unengaged enemy does not engage, but if an exhausted enemy at
    the same location as an investigator becomes ready, it engages as soon as it
    is readied.
  </p>

  <ul>
    <li>
      <em>
        Note: An enemy with the
        <a href="#Aloof">Aloof</a> keyword does not engage in the manner
        described above.
      </em>
    </li>
  </ul>

  <p>See "<a href="#Engage_Action">Engage Action</a>" below.</p>

  <h2>Enemy Phase</h2>

  <p>See "<a href="#Enemy_Phase">III. Enemy phase</a>" on page 25.</p>

  <h2 id="Engage_Action">Engage Action</h2>

  <p>
    "Engage" is an action an investigator may take during his or her turn in the
    investigation phase.
  </p>

  <p>
    To engage an enemy at the same location
    <em
      >(for example, this could be done to engage an exhausted enemy, an aloof
      enemy, or an enemy engaged with another investigator)</em
    >, an investigator places the chosen enemy in his or her threat area. The
    investigator and the enemy are now engaged.
  </p>

  <ul>
    <li>
      An investigator may perform the engage action to engage an enemy that is
      engaged with a different investigator at the same location. The enemy
      simultaneously disengages from the previous investigator and engages the
      investigator performing the action.
    </li>

    <li>
      An investigator cannot use the engage action to engage an enemy he or she
      is already engaged with.
    </li>
  </ul>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Card Ability Interpretation', point 2.3)</span
    >
    When an investigator engages an enemy, that enemy has also engaged that
    investigator, and vice-versa. There is no difference between engaging an
    enemy and being engaged by an enemy. Effects that trigger "after an enemy
    engages you" will trigger at the same time as effects that trigger "after
    you engage an enemy."
  </p>

  <h2 id="Enters_Play">Enters Play</h2>

  <p>
    The phrase "enters play" refers to any time a card makes a transition from
    an out-of-play area into a play area (see "<a
      href="#In_Play_and_Out_of_Play"
      >In Play and Out of Play</a
    >" on page 13).
  </p>

  <ul>
    <li>
      If an ability (either on the card itself or from another card) causes a
      card to enter play in a state different from that specified by the rules,
      there is no transition to that state. It merely enters play in that state.
    </li>
  </ul>

  <h2 id="Evade_Action">Evade, Evade Action</h2>

  <p>
    "Evade" is an action an investigator may take during his or her turn in the
    investigation phase.
  </p>

  <p>
    To evade an enemy engaged with an investigator, that investigator makes an
    agility test against the enemy's evade value (see "<a href="#Skill_Tests"
      >Skill Tests</a
    >" on page 18).
  </p>

  <p>
    If the test is successful, the investigator successfully evades the enemy
    (see below). (This occurs during step 7 of the skill test, per "<a
      href="#Skill_Test_Timing"
      >ST.7 Apply skill test results</a
    >" on page 26.)
  </p>

  <p>
    If the test fails, the investigator does not evade the enemy, and it remains
    engaged with him or her.
  </p>

  <ul>
    <li>
      If an ability "automatically" evades 1 or more enemies, no skill test is
      made for the evasion attempt.
    </li>

    <li>
      Any time an enemy is evaded (whether by an evade action, or by card
      ability), the enemy is exhausted (if it was ready) and the engagement is
      broken. Move the enemy from the investigator's threat area to the
      investigator's location to mark that it is no longer engaged with that
      investigator.
    </li>

    <li>
      Unlike the fight and engage action, an investigator can only perform an
      evade action against an enemy engaged with him or her.
    </li>
  </ul>

  <h2 id="Event_Cards">Event Cards</h2>

  <p>
    Event cards represent tactical actions, maneuvers, spells, tricks, and other
    instantaneous effects at a player's disposal.
  </p>

  <ul>
    <li>
      If an event card does not have the fast keyword, it may only be played
      from a player's hand by performing a "Play" action during his or her turn.
      You must follow all play permissions/restrictions that card has.
    </li>

    <li>
      A fast event card may be played from a player's hand any time its play
      instructions specify (see "<a href="#Fast">Fast</a>" on page 11).
    </li>

    <li>
      Any time a player plays an event card, its costs are paid, its effects are
      resolved (or canceled), and the card is placed in its owner's discard pile
      after those effects resolve (or are canceled).
    </li>

    <li>
      If the effects of an event card are canceled, the card is still considered
      to have been played, and its costs remain paid. Only the effects have been
      canceled.
    </li>

    <li>
      Playing an event card from hand (or not playing it) is always optional for
      a player, unless the event uses the word "must" in its play instructions.
    </li>

    <li>
      An event card cannot be played unless the resolution of its effect has the
      potential to change the game state.
    </li>

    <li>
      See "<a href="#Treachery_and_Event_Subtitles"
        >Treachery and Event Subtitles</a
      >" below for information on event subtitles.
    </li>
  </ul>

  <h2 id="Exceptional">Exceptional</h2>

  <p>Exceptional is a deckbuilding keyword ability.</p>

  <ul>
    <li>
      A card with the exceptional keyword costs twice its printed experience
      cost to purchase.
    </li>

    <li>
      A player's investigator deck cannot include more than 1 copy (by title) of
      any given exceptional card.
    </li>
  </ul>

  <h2 id="Exhaust">Exhaust, Exhausted</h2>

  <p>
    Occasionally, a card ability or game step will cause a card to exhaust to
    indicate it has been used to perform a function. When a card exhausts, it is
    rotated 90 degrees. A card in this state is said to be exhausted.
  </p>

  <ul>
    <li>
      An exhausted card cannot exhaust again until it is ready (typically by a
      game step or card ability).
    </li>
  </ul>

  <h2 id="Exile" style="color: var(--red)">
    Exile (added in <em>The Dunwich Legacy</em>)
  </h2>

  <p>
    Some player cards in <em>The Dunwich Legacy</em> cycle must be exiled when
    they are used. When a card is exiled, it is removed from the game and
    returned to your collection. During campaign play, a card that has been
    exiled must be purchased again with experience points (between scenarios) if
    you wish to re-include it in your deck. If exiling 1 or more cards would
    reduce your deck below your investigator's deck size, when purchasing cards
    between scenarios, you must purchase cards so that a legal deck size is
    maintained (when purchasing cards in this manner, you may purchase level 0
    cards for 0 experience cost until a legal deck size is reached).
  </p>

  <h2>Experience</h2>

  <p>See "<a href="#Experience">Campaign Play</a>" on page 5.</p>

  <h2 id="Explore" style="color: var(--red)">
    Explore (added in <em>The Forgotten Age</em>)
  </h2>

  <p>
    Some abilities in this campaign (and others) are identified with an
    "Explore" action designator. Such abilities are generally used to find new
    locations to put into play, and are initiated using the "activate" action.
  </p>

  <p>
    "Explore" abilities instruct you to draw the top card of the "exploration
    deck," which is a separate deck that is constructed during the setup of some
    scenarios. This deck consists of several single-sided locations and
    treachery cards.
  </p>

  <ul>
    <li>
      Each "Explore" ability indicates a particular type of location that you
      are seeking to draw.
      <b
        >If a location of that type is drawn, it is put into play, and you move
        to that location.</b
      >
      This is considered a "successful" exploration.
    </li>

    <li>
      If any other location is drawn, place it next to the exploration deck, and
      draw the next card from the exploration deck. Repeat this process until a
      location of the indicated type is drawn, or a treachery is drawn. After
      this action has ended, shuffle each location next to the exploration deck
      back into the exploration deck.
    </li>

    <li>
      If a treachery card is drawn, it is resolved as normal. If it is
      discarded, place it in the encounter discard pile as you would normally.
      There is no discard pile for the exploration deck. This is considered an
      "unsuccessful" exploration.
    </li>

    <li>
      As a single-sided location is put into play from the exploration deck,
      place clues on that location equal to its clue value.
    </li>
  </ul>

  <p>
    <i
      >Example: Agenda 1a — “Expedition into the Wild” has the following
      ability: “[action]: <b>Explore.</b> Draw the top card of the exploration
      deck. If it is a connecting location, put it into play and move to it.”
      Ursula Downs is at the Expedition Camp and wishes to find a new location
      to travel to. She spends her first action to explore, drawing the top card
      of the exploration deck. The card she draws is Circuitous Trail. Because
      Circuitous Trail is a location that is not connected to the Expedition
      Camp, it is placed next to the exploration deck, and Ursula draws the next
      card in the exploration deck. This time, she draws the Low on Supplies
      treachery card, which she resolves as normal and places in the encounter
      discard pile. Her exploration is unsuccessful, and she must shuffle the
      Circuitous Trail that she drew previously back into the exploration deck.
      Ursula decides to explore one more time, spending a second action. This
      time, she draws Path of Thorns, which is connected to the Expedition Camp.
      Her exploration is successful. Path of Thorns is put into play with clues
      on it equal to its clue value, and Ursula immediately moves from the
      Expedition Camp to the Path of Thorns.</i
    >
  </p>

  <h2 id="Farthest_From_All_Investigators" style="color: var(--blue)">
    "Farthest from all investigators" (added in FAQ, section 'Card Ability
    Interpretation', point 2.16)
  </h2>

  <p>
    Some card effects instruct investigators to put a card into play at the
    location farthest from all investigators. This is determined by finding the
    location from which the shortest distance (by movement) to any investigator
    is the highest out of all eligible locations. In the event of a tie, as
    usual, the lead investigator decides.
  </p>

  <p>
    <i
      >For example: Location A is 5 connections away from investigator A and 1
      connection away from investigator B. Location B is 3 connections away from
      investigator A and 4 connections away from investigator B. Location B is
      therefore the farthest from both investigators, because its distance to
      the nearest investigator is greater than that of location A. (This is true
      even though location A is farther from investigator A.)</i
    >
  </p>

  <h2 id="Fast">Fast</h2>

  <p>
    Fast is a keyword ability. A fast card does not cost an action to be played
    and is not played using the "Play" action.
  </p>

  <ul>
    <li>
      A fast event card may be played from a player's hand any time its play
      instructions specify. If the instructions specify when/after a timing
      point, the card may be played as if the described timing point were a
      triggering condition for playing the card. If the instructions specify a
      duration or period of time, the card may be played during any player
      window within that period. If the instructions specify both a when/after
      timing point and a duration or period of time, the card may be played in
      reference to any instance of the specified triggering condition within
      that time period.
    </li>

    <li>
      A fast asset may be played by an investigator during any player window on
      his or her turn.
    </li>

    <li>
      Because fast cards do not cost actions to play, they do not provoke
      attacks of opportunity (see "<a href="#Attack_of_Opportunity"
        >Attack of Opportunity</a
      >" on page 5).
    </li>
  </ul>

  <h2 id="Fight_Action">Fight Action</h2>

  <p>
    "Fight" is an action an investigator may take during his or her turn in the
    investigation phase.
  </p>

  <p>
    To fight an enemy at his or her location, an investigator resolves an attack
    against that enemy by making a combat test against the enemy's fight value
    (see "<a href="#Skill_Tests">Skill Tests</a>" on page 18).
  </p>

  <p>
    If the test is successful, the attack succeeds and damage is dealt to the
    attacked enemy. The default damage dealt by an attack is 1. Some weapons,
    spells, or other special attacks may modify this damage. (This occurs during
    step 7 of the skill test, per "<a href="#Skill_Test_Timing"
      >ST.7 Apply skill test results</a
    >" on page 26.)
  </p>

  <p>
    If the test fails, no damage is dealt to the attacked enemy. However, if an
    investigator fails this test against an enemy that is engaged with another
    single investigator, the damage of the attack is dealt to the investigator
    engaged with that enemy.
  </p>

  <ul>
    <li>
      An investigator may fight any enemy at his or her location, including: an
      enemy he or she is engaged with, an unengaged enemy at the same location,
      or an enemy engaged with another investigator who is at the same location.
    </li>
  </ul>

  <h2 id="Flavor_Text">Flavor Text</h2>

  <p>
    Flavor text is additional text that provides thematic context to a card
    and/or its abilities. Flavor text does not interact with the game in any
    manner.
  </p>

  <h2 id="Flood_Tokens" style="color: var(--red)">
    Flood Tokens (added in <em>The Innsmouth Conspiracy</em>)
  </h2>

  <p>
    Throughout this campaign, scenario card effects can flood locations. Each
    location has one of three different flood levels: it is either unflooded,
    partially flooded, or fully flooded. A location's flood level can be tracked
    using the double‑sided flood tokens included in this deluxe box.
    <b>A location's flood level has no inherent game effect.</b>
    However, some card effects may change or become stronger while you are at a
    flooded location, particularly if that location is fully flooded.
  </p>

  <ul>
    <li>A location with no flood token is unflooded.</li>

    <li>
      If a location becomes partially flooded, place a flood token on it with
      the partially flooded side faceup to designate this.
    </li>

    <li>
      If a location becomes fully flooded, place a flood token on it with the
      fully flooded side faceup (or if it is already partially flooded, flip its
      flood token over) to designate this.
    </li>

    <li>
      If a location's flood level is "increased," it changes from unflooded to
      partially flooded, or from partially flooded to fully flooded. A fully
      flooded location cannot have its flood level increased.
    </li>

    <li>
      If a location's flood level is "decreased," it changes from fully flooded
      to partially flooded, or from partially flooded to unflooded. If a
      location becomes unflooded, remove its flood token
    </li>

    <li>
      For the purposes of card effects, both partially flooded locations and
      fully flooded locations are considered to be "flooded."
    </li>
  </ul>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Frequently Asked Questions')</span
    >
    <b>Frequently asked Flood questions:</b>
  </p>

  <ol>
    <li>
      <i
        >If an investigator starts their turn at a fully flooded location,
        enters an unrevealed location with no flood token, and that location
        becomes flooded "after it is revealed," does the investigator still
        "struggle for air?" Or does this count as entering an unflooded
        location?</i
      >
      Technically the investigator has entered an unflooded location, which then
      became flooded after it was revealed, so they would not struggle for air.
    </li>
  </ol>

  <h2 id="For_Each_Or_For_Every" style="color: var(--blue)">
    "For each" or "for every" (added in FAQ, section 'Card Ability
    Interpretation', point 2.23)
  </h2>

  <p>
    Some card effects instruct an investigator to perform an effect multiple
    times for each instance of a particular condition (e.g. "for each horror on
    you," or "for each card in your hand"). If such an effect can be calculated
    and resolved simultaneously, it should be resolved (and may be canceled,
    ignored, or prevented) as a single cumulative effect. If it cannot be
    resolved simultaneously (for example, if it has multiple steps or other
    dependencies), each instance should be resolved as a separate effect (and
    must be canceled, ignored, or prevented independently of each other effect).
  </p>

  <p>
    <i
      >For example: A treachery card instructs you to "take 1 horror for each
      point you fail by." Since you can calculate how many points you fail by
      and resolve the dealt horror simultaneously, it should be resolved as a
      single instance of horror.</i
    >
  </p>

  <p>
    <i
      >A different treachery card instructs you: "For each point you fail by,
      you must either lose 1 action or take 1 horror. This treachery must be
      resolved as separate effects; each point failed by requires you to make a
      choice, whether that choice is to lose an action or to take a horror. Each
      instance must be resolved separately, even if the resulting outcome only
      causes you to take horror.</i
    >
  </p>

  <h2 id="Forced_Abilities">Forced Abilities</h2>

  <p>See "<a href="#Abilities_Forced">Ability</a>" on page 2.</p>

  <h2 id="Gains">Gains</h2>

  <p>The word "gains" is used in multiple contexts.</p>

  <ul>
    <li>
      If a player gains one or more resources, the player takes the specified
      number of resources from the token pool and adds them to his or her
      resource pool.
    </li>

    <li>
      If an investigator gains an action, that investigator is permitted one
      additional action to spend during the specified time period.
    </li>

    <li>
      If a card gains a characteristic (such as an icon, a trait, a keyword, or
      ability text), the card functions as if it possesses the gained
      characteristic.
    </li>

    <li>
      "Gained" characteristics are not considered to be "printed" on the card.
      If an ability refers to the printed characteristics of a card, it does not
      refer to gained characteristics.
    </li>
  </ul>

  <h2 id="Game">Game</h2>

  <p>
    A 'game' consists of a single scenario, not an entire campaign. In a
    campaign, the beginning of a new scenario marks the start of a new game.
  </p>

  <h2 id="Hand_Size">Hand Size</h2>

  <p>See "<a href="#Upkeep_Phase">IV. Upkeep phase</a>" on page 25.</p>

  <h2 id="Heal">Heal</h2>

  <p>
    "Heal" is an instruction to remove the indicated amount of damage or the
    indicated amount of horror from a card.
  </p>

  <ul>
    <li>
      If a card is healed for more damage or horror than it currently has on it,
      remove as much of the indicated amount as possible.
    </li>
  </ul>

  <h2 id="Haunted" style="color: var(--red)">
    Haunted (added in <em>The Circle Undone</em>)
  </h2>

  <p>
    Haunted is a new ability that appears on some locations. Each time an
    investigator fails a skill test while investigating a location, after
    applying all results for that skill test, that investigator must resolve all
    "<b>Haunted</b>
    –" abilities on that location.
  </p>

  <p>
    A location is "haunted" for the purposes of other card effects if it has at
    least one "<b>Haunted</b> –" ability (printed or otherwise).
  </p>

  <h2 id="Health_and_Damage">Health and Damage</h2>

  <p>
    Health represents a card's physical fortitude. Damage tracks the physical
    harm that has been done to a card during a scenario.
  </p>

  <ul>
    <li>
      Any time a card takes damage, place a number of damage tokens equal to the
      amount of damage just taken on the card (see "<a
        href="#Dealing_Damage_Horror"
        >Dealing Damage/Horror</a
      >" on page 7).
    </li>

    <li>
      If an investigator has damage on him or her equal to or greater than his
      or her health, that investigator is defeated. When an investigator is
      defeated, he or she is eliminated from the scenario (see "<a
        href="#Elimination"
        >Elimination</a
      >" on page 10).
    </li>

    <li>
      In campaign play, an investigator that is defeated by taking damage equal
      to his or her health suffers 1 physical trauma. Taking physical trauma may
      cause an investigator to be <strong>killed</strong> (see "<a
        href="#Campaign_Play"
        >Campaign Play</a
      >" on page 5 for more information).
    </li>

    <li>
      If an enemy has damage on it equal to or greater than its health, that
      enemy is defeated and placed in the encounter discard pile.
    </li>

    <li>
      If an asset with a health value has damage on it equal to or greater than
      its health, it is defeated and placed on its owner's discard pile.
    </li>

    <li>
      An asset card without a health value is not considered to have a health of
      0, cannot gain health, and cannot have damage assigned to it.
    </li>

    <li>
      A card's "remaining health" is its base health minus the amount of damage
      on it, plus or minus any active health modifiers.
    </li>
  </ul>

  <p>
    See also: "<a href="#Direct_Damage_Direct_Horror"
      >Direct Damage, Direct Horror</a
    >" on page 9.
  </p>

  <h2 id="Hidden" style="color: var(--red)">
    Hidden (added in <em>The Path to Carcosa</em>, updated in
    <em>The Dream-Eaters</em>)
  </h2>

  <p>
    An encounter card or weakness with the hidden keyword has a revelation
    ability that secretly adds that card to your hand. This should be done
    without revealing that card or its text to the other investigators.
  </p>

  <ul>
    <li>
      While a hidden treachery is in your hand, treat it as if it were in your
      threat area. Its constant abilities are active, and abilities on it can be
      triggered, but only by you.
    </li>

    <li>
      While a hidden enemy is in your hand, it is not considered to be engaged
      with you or in your threat area, and it does not attack unless otherwise
      specified. However, its constant abilities are active, and abilities on it
      can be triggered, but only by you.
    </li>

    <li>
      A hidden card counts toward your hand size, but it cannot leave your hand
      by any means except those described on the card.
    </li>
  </ul>

  <p>
    For the best experience, players are encouraged to stay "in character" and
    not share information about hidden cards in their hand.
  </p>

  <h3 id="Hidden_Cards_in_Hand_When_Eliminated" style="color: var(--blue)">
    Hidden Cards in Hand When Eliminated (added in FAQ, section 'Game Play',
    point 1.22)
  </h3>

  <p>
    When an investigator is eliminated, each encounter card in their hand with
    the hidden keyword should be placed in the encounter discard pile, in the
    same way as encounter cards in their threat area.
  </p>

  <h2 id="Hunter">Hunter</h2>

  <p>Hunter is a keyword ability.</p>

  <p>
    During the enemy phase (in
    <a href="#Enemy_Phase">framework step 3.2</a>), each ready, unengaged enemy
    with the hunter keyword moves to a connecting location, along the shortest
    path towards the nearest investigator. Enemies at a location with one or
    more investigators do not move.
  </p>

  <ul>
    <li>
      If there are multiple equidistant investigators who qualify as "the
      nearest investigator," the enemy moves towards the one of those who best
      meets its prey instructions. If none do, or if the enemy has no prey
      instructions, the lead investigator may choose an investigator for the
      enemy to move towards.
    </li>

    <li>
      If a hunter enemy would be compelled to a location to which the move is
      blocked by a card ability, the enemy does not move.
    </li>
  </ul>

  <p>See also: "<a href="#Prey">Prey</a>" on page 17.</p>

  <h2 id="If" style="color: var(--blue)">
    If (added in FAQ, section 'Card Ability Interpretation', point 2.2)
  </h2>

  <p>
    Some abilities have triggering conditions that use the words "at" or "if"
    instead of specifying "when" or "after," such as "at the end of the round,"
    or "if the Ghoul Priest is defeated." These abilities trigger in between any
    "when..." abilities and any "after..." abilities with the same triggering
    condition.
  </p>

  <p>See also: "<a href="#At">At</a>".</p>

  <h2 id="Immune">Immune</h2>

  <p>
    If a card is immune to a specified set of effects
    <em
      >(for example, "immune to treachery card effects," or "immune to player
      card effects")</em
    >, it cannot be affected by or chosen to be affected by effects belonging to
    that set. Only the card itself is protected, and peripheral entities
    associated with an immune card (such as attached assets, tokens placed on,
    or abilities originating from an immune card) are not themselves immune.
  </p>

  <ul>
    <li>
      If a card gains immunity to an effect, pre-existing lasting effects that
      have been applied to the card are not removed. If a card loses immunity to
      an effect, pre-existing lasting effects of that nature are not applied to
      the card.
    </li>

    <li>
      Immunity only protects a card from effects. It does not protect a card
      from costs.
    </li>
  </ul>

  <h2 id="In_Play_and_Out_of_Play">In Play and Out of Play</h2>

  <p>
    The cards that a player controls in his or her play area are considered in
    play.
  </p>

  <p>
    The current act, the current agenda, each location in the play area, and
    each encounter card in a investigator's threat area or at a location, are
    all considered in play.
  </p>

  <p>
    Out of play refers to the cards in a player's hand, in any deck, in any
    discard pile, in the victory display, and those that have been set aside
    and/or removed from the game.
  </p>

  <ul>
    <li>
      A card enters play when it transitions from an out-of-play origin to an in
      play area.
    </li>

    <li>
      A card leaves play when it transitions from a in play area to an
      out-of-play destination.
    </li>

    <li>
      Tokens on in play cards are considered in play. Resources in each
      investigator's resource pool are also considered in play.
    </li>
  </ul>

  <h2 id="In_Player_Order">In Player Order</h2>

  <p>
    If the players are instructed to perform a sequence "in player order," the
    lead investigator performs his or her part of the sequence first, followed
    by the other players in clockwise order. The phrase "the next player" is
    used in this context to refer to the next player (clockwise) to act in
    player order.
  </p>

  <h2 id="Instead">Instead</h2>

  <p>
    The word "instead" is indicative of a replacement effect. A replacement
    effect is an effect that replaces the resolution of a triggering condition
    with an alternate means of resolution.
  </p>

  <ul>
    <li>
      If multiple replacement effects are initiated against the same triggering
      condition and create a conflict in how to resolve the triggering
      condition, the most recent replacement effect is the one that is used for
      the resolution of the triggering condition.
    </li>

    <li>
      The word "would" is used to define the triggering condition of some
      abilities, and establishes a higher priority for those abilities than
      abilities referencing the same triggering condition without the word
      "would." (For instance, "When X would occur" resolves before "When X
      occurs.")
    </li>

    <li>
      If a replacement effect that uses the word "would" changes the nature of a
      triggering condition, the original triggering condition is replaced with
      the new triggering condition. No further abilities referencing the
      original triggering condition may be used.
    </li>
  </ul>

  <h2 id="Investigate_Action">Investigate Action</h2>

  <p>
    "Investigate" is an action an investigator may take during his or her turn
    in the investigation phase.
  </p>

  <p>
    Each time an investigator takes this action, he or she makes an intellect
    test against the shroud value of that location (see "<a href="#Skill_Tests"
      >Skill Tests</a
    >" on page 18).
  </p>

  <p>
    If the test is successful, the investigator has succeeded in investigating
    the location, he or she discovers one clue at the location. (This occurs
    during step 7 of the skill test, per "<a href="#Skill_Test_Timing"
      >ST.7 Apply skill test results</a
    >" on page 26.)
  </p>

  <p>
    Any time an investigator discovers a clue from a location, that player takes
    the clue from the location and places it on his or her investigator card,
    under his or her control.
  </p>

  <p>
    If the test is failed, the investigator has failed in investigating the
    location. No clues are discovered during step 7 of the skill test.
  </p>

  <h2>Investigation Phase</h2>

  <p>
    See "<a href="#Investigation_Phase">II. Investigation phase</a>" on page 24.
  </p>

  <h2 id="Investigator_Deck">Investigator Deck</h2>

  <p>
    A player's "investigator deck" is the deck that contains that player's
    asset, event, skill, and weakness cards. A reference to "your deck" refers
    to the investigator deck under your control.
  </p>

  <h3 id="Scenario_Effects_on_Investigator_Decks" style="color: var(--blue)">
    Scenario Effects on Investigator Decks (added in FAQ, section 'Game Play',
    point 1.36)
  </h3>

  <p>
    A scenario may instruct an investigator to add a card to their deck. Unless
    this instruction includes the word "may," the investigator must add that
    card to their deck; this effect cannot be canceled or ignored, and is not
    restricted by an investigator's Deckbuilding Options.
  </p>

  <h2 id="Joes_Hunch_Deck" style="color: var(--red)">
    Joe's "Hunch Deck" (added in <em>The Circle Undone</em>)
  </h2>

  <p>
    As a private eye, Joe Diamond has learned to follow his instincts, and
    therefore he has a separate hunch deck, which is constructed during step 4
    of the setup of each scenario. The cards in this hunch deck are chosen from
    Joe's 40-card deck and therefore count toward his total deck size. With the
    exception of these setup instructions, all references to Joe's "deck" refer
    to Joe's standard investigator deck and not his hunch deck. Joe's hunch deck
    has no discard pile; cards from your hunch deck are discarded to your
    standard discard pile when played.
  </p>

  <h2 id="Keys" style="color: var(--red)">
    Keys (token) (added in <em>The Innsmouth Conspiracy</em>)
  </h2>

  <p>
    This expansion introduces key tokens that represent important objects or
    pieces of information that can be claimed and used during scenarios.
  </p>

  <p>
    Key tokens have two sides. When facedown, all seven keys have the same
    universal key symbol, so they can be randomized without the investigators
    knowing which is which. When faceup, each key is color coded with a unique
    color (<i>red</i>, <i>blue</i>, <i>green</i>, <i>yellow</i>, <i>purple</i>,
    <i>black</i>, <i>white</i>).
  </p>

  <p>
    If a scenario uses one or more keys, the setup of that scenario indicates
    how many are set aside and whether they should be faceup or randomized
    facedown. Keys can enter play via several different card effects, and they
    are usually placed on an enemy, location, or story asset. Keys can be
    acquired in any of three ways:
  </p>

  <ul>
    <li>
      If a location with a key on it has no clues, an investigator may take
      control of each of the location's keys as a [free] ability.
    </li>

    <li>
      If an investigator causes an enemy with a key on it to leave play, that
      investigator must take control of each of the keys that were on that
      enemy. (If it leaves play through some other means, place its keys on its
      location.)
    </li>

    <li>
      Some card effects may allow an investigator to take control of keys in
      other ways.
    </li>
  </ul>

  <p>
    When an investigator takes control of a key, they flip it faceup (if it is
    facedown) and place it on their investigator card. If an investigator who
    controls one or more keys is eliminated, place each of their keys on their
    location. As an [action] ability, an investigator may give any number of
    their keys to another investigator at the same location.
  </p>

  <p>
    <b>Keys have no inherent game effect.</b> However, some card effects may
    change depending on which keys an investigator controls. Additionally, keys
    may sometimes be required in order to progress during a scenario.
  </p>

  <h2 id="Keys2" style="color: var(--red)">
    Keys (cardtype) (added in <em>The Scarlet Keys</em>)
  </h2>

  <p>
    <i>The Scarlet Keys</i> campaign features a new cardtype: keys. Keys are
    powerful artifacts that may be "shifted" to either aid or hinder
    investigators, depending on whom they are attached to and whether their
    <b><i>Stable</i></b> or <b><i>Unstable</i></b> side is faceup.
  </p>

  <ul>
    <li>
      During the resolution of a scenario, a key may become bound to a single
      bearer, whose name is marked in the Campaign Log. A key may be bound to an
      investigator, a story asset, or an enemy.
    </li>

    <li>
      A key always enters play attached to its bearer (as marked in the Campaign
      Log). At the start of each scenario, each investigator who is the bearer
      of 1 or more keys attaches those keys to their investigator card. Whenever
      a story asset or enemy enters play, if it is the bearer of 1 or more keys,
      those keys also enter play attached to their bearer.

      <ul>
        <li>
          If a key’s bearer is an investigator or a story asset, it enters play
          <b><i>Stable</i></b> side faceup.
        </li>

        <li>
          If a key’s bearer is an enemy, it enters play
          <b><i>Unstable</i></b> side faceup.
        </li>
      </ul>
    </li>
    <li>
      A key cannot leave play unless its bearer leaves play. If the bearer of 1
      or more keys leaves play, each key they control is set aside, out of play.
      <i
        >(Those keys do, however, remain bound to their bearer for future
        scenarios unless explicitly noted otherwise.)</i
      >
    </li>

    <li>
      While a key is attached to an investigator, that investigator may trigger
      its shift ability during any player window as a [free] ability. This is
      called "shifting" the key. As part of this ability’s resolution, it will
      instruct the investigator to flip the key to its other side, so its other
      shift ability is active. The investigator will then have to perform the
      shift ability on its <b><i>Unstable</i></b> side in order to flip it back
      over again.

      <ul>
        <li>
          While a key is attached to a story asset, it may be shifted by any
          investigator who controls that asset in the same way.
        </li>

        <li>
          Each key (by title) attached to an investigator or story asset can
          only be shifted once per round.
        </li>
      </ul>
    </li>
    <li>
      While a key is under an enemy’s control, its shift ability only resolves
      when a card or game effect instructs an investigator to shift that key,
      after which it remains <b><i>Unstable</i></b> side faceup.

      <ul>
        <li>
          A key attached to an enemy cannot be flipped to its
          <b><i>Stable</i></b> side.
        </li>

        <li>
          There is no limit to the number of times a key attached to an enemy
          can be shifted.
        </li>
      </ul>
    </li>
    <li>
      Some card effects may directly flip a key attached to an investigator or
      story asset from its
      <b><i>Stable</i></b> side to its <b><i>Unstable</i></b> side, or vice
      versa. This is not the same as shifting a key, and does not resolve its
      shift ability.
    </li>
    <li>
      <span style="color: var(--blue)"
        >(Added in FAQ, section 'Card Ability Interpretation', point 2.30)</span
      >
      A Key card changes its card category based on its bearer/controller. While
      attached to an investigator, or to a story asset controlled by an
      investigator, a Key is a player card. Otherwise, a Key is a scenario card.
    </li>
  </ul>

  <h2 id="Keywords">Keywords</h2>

  <p>
    A keyword is a card ability which conveys specific rules to its card. Each
    keyword has its own rules which can be found in the keyword's own section of
    the glossary. The keywords in this game are: <a href="#Aloof">aloof</a>,
    <a href="#Fast">fast</a>, <a href="#Hunter">hunter</a>,
    <a href="#Massive">massive</a>, <a href="#Peril">peril</a>,
    <a href="#Retaliate">retaliate</a>, <a href="#Surge">surge</a>,
    <a href="#Uses">uses</a>.
  </p>

  <ul>
    <li>
      There are also two deckbuilding keywords:
      <a href="#Exceptional">exceptional</a> and
      <a href="#Permanent">permanent</a>. Deckbuilding keywords affect deck
      customization while building and/or leveling up a deck. They have no
      effect during gameplay. There are no exceptional or permanent cards in the
      core set – each of these keywords will be presented in future expansions.
    </li>

    <li>
      A single card that has and/or is gaining the same keyword from multiple
      sources functions as if it has one instance of that keyword.
    </li>

    <li>
      The initiation of any keyword which uses the word "may" in its keyword
      description is optional. The application of all other keywords is
      mandatory.
    </li>
  </ul>

  <p>See "<a href="#Abilities_Keywords">Ability</a>" on page 2.</p>

  <h2 id="Killed_Insane_Investigators">Killed/Insane Investigators</h2>

  <p>
    During campaign play, investigators who are killed or driven insane must be
    recorded in your campaign log and cannot be used for the remainder of the
    campaign.
  </p>

  <ul>
    <li>
      An investigator with physical trauma equal to or higher than his or her
      printed health is killed.
    </li>

    <li>
      An investigator with mental trauma equal to or higher than his or her
      printed sanity is driven insane.
    </li>

    <li>
      An investigator may also be killed or driven insane by card ability, or
      during a scenario's resolution.
    </li>

    <li>
      When playing a standalone scenario, there is no practical difference
      between being killed, driven insane, or defeated.
    </li>
  </ul>

  <p>See "<a href="#Campaign_Play">Campaign Play</a>" on page 5.</p>

  <h2 id="Lasting_Effects">Lasting Effects</h2>

  <p>
    Some card abilities create conditions that affect the game state for a
    specified duration
    <em
      >(for example, "until the end of the phase" or " for this skill test")</em
    >. Such effects are known as lasting effects.
  </p>

  <ul>
    <li>
      A lasting effect persists beyond the resolution of the ability that
      created it, for the duration specified by the effect. The effect continues
      to affect the game state for the specified duration regardless of whether
      the card that created the lasting effect is or remains in play.
    </li>

    <li>
      If a lasting effect affects in-play cards (or cards in a specified area),
      it is only applied to cards that are in play (or the specified area) when
      the lasting effect is established. Cards that enter play (or the specified
      area) after its establishment are not affected by the lasting effect.
    </li>

    <li>
      A lasting effect expires as soon as the timing point specified by its
      duration is reached. This means that an "until the end of the phase"
      lasting effect expires before an "at the end of the phase" ability or
      delayed effect may initiate.
    </li>

    <li>
      A lasting effect that expires at the end of a specific time period can
      only be initiated during that time period.
    </li>
  </ul>

  <h2 id="Lead_Investigator">Lead Investigator</h2>

  <p>
    The lead investigator is sometimes required to make important scenario
    decisions. At the beginning of a scenario, the investigators choose a lead
    investigator. If they cannot agree on a choice, a lead investigator is
    chosen at random.
  </p>

  <ul>
    <li>
      If there are ever multiple valid options for a choice or decision that
      must be made
      <em
        >(for example, a hunter enemy that could move in two different
        directions)</em
      >, the lead investigator is the final arbiter in choosing among those
      options.
    </li>

    <li>
      If the lead investigator is eliminated, the remaining players (if any)
      choose a new lead investigator.
    </li>
  </ul>

  <h2 id="Leaves_Play">Leaves Play</h2>

  <p>
    The phrase "leaves play" refers to any time a card makes a transition from
    an in-play state to an out-of-play state (see "<a
      href="#In_Play_and_Out_of_Play"
      >In Play and Out of Play</a
    >" on page 13).
  </p>

  <p>
    If a card leaves play, the following consequences occur simultaneously with
    the card leaving play:
  </p>

  <ul>
    <li>All tokens on the card are returned to the token pool.</li>

    <li>All attachments on the card are discarded.</li>

    <li>
      All lasting effects and/or delayed effects affecting the card while it was
      in play expire for that card.
    </li>
  </ul>

  <h2 id="Limbo" style="color: var(--blue)">
    Limbo (added in FAQ, section 'Game Play', point 1.23, updated FAQ v2.5)
  </h2>

  <p>
    While the effects of an event or treachery card are being resolved, or while
    a skill is committed to a skill test, it is neither in play, in the discard
    pile, nor is it in an investigator’s hand. For the purposes of rules
    clarification, this liminal state is called "limbo."
  </p>

  <p>
    An event card enters limbo during step 3 of the Initiation Sequence, after
    costs are paid and attacks of opportunity are made
    <i
      >(see "<a href="#Appendix_I_Initiation_Sequence"
        >Appendix I: Initiation Sequence</a
      >")</i
    >. A treachery card enters limbo after it is drawn, while its revelation
    ability is being resolved. A skill card enters limbo as it is committed to a
    skill test.
  </p>

  <p>
    Limbo is not a physical game area. While in limbo, a card is typically
    placed on the table to show that its effects are currently being resolved
    (unless it is attached to another game element, in which case it remains in
    its current position). It is no longer considered to be in any
    investigator’s hand, but it has not yet been placed in any discard pile. It
    is technically not in play, and does not count as being in play for the
    purposes of other card effects, however its effects may still alter the game
    state. After resolving the card’s effects <i>in full</i>, it is placed in
    its relevant discard pile and is no longer in limbo. If its effects cause it
    to enter play (such as attaching to another game element or placing it in an
    investigator’s threat or play area), it leaves limbo and enters play at that
    point in time.
  </p>
  <h2 id="Limits_and_Maximums">Limits and Maximums</h2>

  <p>
    <strong>"Limit X per [period]"</strong> is a limit that appears on cards
    that remain in play through the resolution of an ability's effect. Each
    instance of an ability with such a limit may be initiated X times during the
    designated period. If a card leaves play and re-enters play during the same
    period, the card is considered to be bringing a new instance of the ability
    to the game.
  </p>

  <p>
    <strong>"Limit X per [card/game element]"</strong> is a limit that appears
    on attachment cards, and restricts the number of copies of that card (by
    title) that can be attached to each designated card or game element.
  </p>

  <ul>
    <li>Unless stated otherwise, limits are player specific.</li>

    <li>
      A "group limit," however, applies to the entire group of investigators.
      <em
        >(For example, if an investigator triggers an ability that is "group
        limit once per game," no other investigator may trigger that ability
        during that game.)</em
      >
    </li>
  </ul>

  <p>
    <strong>"Max X per [period]"</strong> imposes a maximum across all copies of
    a card (by title) for all players. Generally, this phrase imposes a maximum
    number of times that copies of that card can be played during the designated
    time period. If a maximum includes the word "committed"
    <em>(For example, "Max 1 committed per skill test")</em>, it imposes a
    maximum number of copies of that card that can be committed to skill tests
    during the designated period. If a maximum appears as part of an ability, it
    imposes a maximum number of times that ability can be initiated from all
    copies (by title) of cards bearing that ability (including itself), during
    the designated period.
  </p>

  <p>
    If the effects of a card or ability with a limit or maximum are canceled, it
    is still counted against the limit/maximum, because the ability has been
    initiated.
  </p>

  <h3 id="Limits_Pertaining_to_Play_Areas" style="color: var(--blue)">
    Limits Pertaining to Play Areas (added in FAQ, section 'Card Ability
    Interpretation', point 2.3)
  </h3>

  <p>
    Some limits may pertain to a particular play area, such as "Limit 1 per
    deck," "Limit 1 in the victory display," or "Limit 1 in play." This limit
    restricts the number of copies of that card (by title) that can exist in the
    specified play area. Another copy of that card cannot enter the specified
    play area if this limit has already been reached. Remember that limits are
    player specific unless otherwise noted. For example, a card with "Limit 1
    per deck" can exist in two different investigator decks.
  </p>

  <p>
    <i
      >Note: "Limit X per investigator" is a limit that pertains to an
      investigator’s play area.</i
    >
  </p>

  <h2 id="Location_Cards">Location Cards</h2>

  <p>
    Location cards represent the places the investigators may explore during a
    scenario.
  </p>

  <ul>
    <li>
      Use each investigator's mini-card to indicate which location he or she is
      at.
    </li>

    <li>
      While an investigator is at a location, that investigator, each of his or
      her assets, and each card in that investigator's threat area is at the
      same location.
    </li>

    <li>
      Locations enter play in an "unrevealed" state, so that the side with no
      shroud value and/or clue value is faceup. Do not read the "revealed" side
      at this time.
    </li>

    <li>
      The first time a location is entered by an investigator, that location is
      revealed by turning it to its other side and placing a number of clues on
      it equal to its clue value (this may occur during setup). Most clue values
      are conveyed as a "per investigator" ([per_investigator]) value.
    </li>

    <li>
      A location with its shroud/clue value side faceup is in the "revealed"
      state.
    </li>
  </ul>

  <h3 id="Being_at_No_Location" style="color: var(--blue)">
    Being at No Location (added in FAQ, section 'Game Play', point 1.21)
  </h3>

  <p>
    Unless explicitly specified by game text, enemies and investigators must
    always be at a location during gameplay. If an effect (such as a "cannot
    move" effect) would cause an investigator or enemy to not be at a location,
    ignore that effect.
  </p>

  <h3 id="Revealing_and_Flipping_Locations" style="color: var(--blue)">
    Revealing and Flipping Locations (added in FAQ, section 'Game Play', point
    1.39)
  </h3>

  <p>
    If a location is revealed, then leaves play, and later re-enters play and is
    revealed again, place clues on it up to its clue value (as if this were the
    first time an investigator had revealed that location this game).
  </p>

  <p>
    If a location with 2 revealed sides flips without leaving play, do not place
    or replenish clues on that location when it flips unless otherwise stated.
  </p>

  <h2 id="Lola_and_Roles" style="color: var(--red)">
    Lola and "Roles" (added in <em>The Path to Carcosa</em>)
  </h2>

  <p>
    As a renowned actress, Lola Hayes can play many different roles. At the
    beginning of each scenario, after investigators draw opening hands, Lola
    Hayes must choose a role (Neutral, Guardian, Seeker, Rogue, Mystic, or
    Survivor). Lola can only play cards, commit cards to skill tests, or trigger
    [action], [fast], or [reaction] abilities on Neutral cards or cards whose
    class matches her role. This restriction only applies to player cards, not
    to encounter cards or weaknesses. Note that Constant and
    <b>Forced</b> abilities remain active on cards whose class does not match
    Lola's role.
  </p>

  <h2 id="Massive">Massive</h2>

  <p>
    Massive is a keyword ability. A ready enemy with the massive keyword is
    considered to be engaged with each investigator at the same location as it.
  </p>

  <ul>
    <li>
      An exhausted enemy with the massive keyword is not considered to be
      engaged with any investigators.
    </li>

    <li>
      An enemy with the massive keyword cannot be placed in an investigator's
      threat area.
    </li>

    <li>
      When an enemy with the massive keyword attacks during the enemy phase,
      resolve its (full) attack against each investigator it is engaged with,
      one investigator at a time. The lead investigator chooses the order in
      which these attacks resolve. The massive enemy does not exhaust until its
      final attack of the phase resolves.
    </li>

    <li>
      When an enemy with the massive keyword makes an attack of opportunity,
      that attack only resolves against the investigator who provoked the
      attack.
    </li>

    <li>
      A massive enemy does not move with an engaged investigator who moves away
      from the massive enemy's location.
    </li>

    <li>
      If an investigator fails a combat test against a massive enemy, no damage
      is dealt to the engaged investigators.
    </li>
  </ul>

  <h3 id="Massive_Enemy_Attacks" style="color: var(--blue)">
    Massive Enemy Attacks (added in FAQ, section 'Card Ability Interpretation',
    point 2.29)
  </h3>

  <p>
    A massive enemy that is ready during the enemy phase attacks each
    investigator at its location, one at a time, in an order determined by the
    lead investigator. Because it is engaged with each investigator at its
    location, these attacks occur outside the standard timing of enemy attacks,
    which are usually resolved in player order.
  </p>

  <p>
    While resolving a massive enemy's attacks, if an investigator becomes
    engaged with the enemy, that investigator will be added to the list of
    targets the enemy will perform an attack against. If a massive enemy
    exhausts before resolving all of its attacks, it does not initiate any
    remaining attacks.
  </p>

  <h2 id="May">May</h2>

  <p>
    The word "may" indicates that a specified player has the option to do that
    which follows. If no player is specified, the option is granted to the
    controller of the card with the ability in question.
  </p>

  <h2 id="Modifiers">Modifiers</h2>

  <p>
    Some abilities cause values or quantities of characteristics to be modified.
    The game state constantly checks and (if necessary) updates the count of any
    variable value or quantity that is being modified.
  </p>

  <p>
    Any time a new modifier is applied (or removed), the entire quantity is
    recalculated from the start, considering the unmodified base value and all
    active modifiers.
  </p>

  <ul>
    <li>
      When calculating a value, treat all modifiers as being applied
      simultaneously. However, while performing the calculation, all additive
      and subtractive modifiers are calculated before doubling and/or halving
      modifiers.
    </li>

    <li>
      Fractional values are rounded up after all modifiers have been applied.
    </li>

    <li>
      A quantity on a card (such as a stat, an icon, a number of instances of a
      trait or keyword) cannot be reduced so that it functions with a value
      below zero. Negative modifiers in excess of a value's current quantity can
      be applied, but, after all active modifiers have been applied, any
      resultant value below zero is treated as zero.
      <em
        >(For example: Danny tests agility and reveals a –8 chaos token. When
        applied to his agility of 4, this would reduce his skill value to –4.
        However, his agility cannot be reduced so that it functions with a value
        below zero. While the –8 modifier still exists, his agility is treated
        as zero. If Danny were to play "Lucky!" to receive a +2 bonus to the
        test, this bonus would not be applied to the functioning skill value of
        zero; but rather, it is applied in conjunction with all active
        modifiers. Danny's agility would then be calculated as follows: base
        skill 4, –8 from chaos token, +2 from "Lucky!" for a total of –2, which
        is still treated as zero.)</em
      >
    </li>
  </ul>

  <h2 id="Move">Move</h2>

  <p>
    Any time an entity (an investigator or enemy) moves, transfer that enemy
    card or investigator's mini card from its current location to a different
    location.
  </p>

  <ul>
    <li>
      Unless otherwise specified by the move effect or ability, the moving
      entity must move to a connecting location. Connecting locations are
      identified on the location card representing the entity's current
      location, as shown below.
    </li>

    <li>
      Any time an entity moves, it is considered to leave the previous location,
      and to enter the new location, simultaneously.
    </li>

    <li>
      If an entity is "moved to..." a specific location, the entity is moved
      directly to that location, and does not pass through other locations en
      route.
    </li>

    <li>
      If an investigator moves to an unrevealed location, that location is
      revealed by turning it to its other side, and placing a number of clues on
      it equal to its clue value. Most clue values are conveyed as a "per
      investigator" ([per_investigator]) value.
    </li>

    <li>
      If an enemy moves to an unrevealed location, that location remains
      unrevealed.
    </li>

    <li>
      Game elements (tokens or cards) may also be moved by card abilities from
      one card to another, or from one game area to another game area.
    </li>

    <li>
      When an entity or game element moves, it cannot move to its same (current)
      placement. If there is no valid destination for a move, the move cannot be
      attempted.
    </li>
  </ul>

  <img
    alt="Example of a Move action"
    src="/assets-v20260923/rules/keyword_move.png"
    class="center frame"
    loading="lazy"
    width="312"
  />

  <h2 id="Move_Action">Move Action</h2>

  <p>
    "Move" is an action an investigator may take during his or her turn in the
    investigation phase.
  </p>

  <p>
    When an investigator takes this action, move that investigator (using his or
    her mini card) to any other location that is marked as a connecting location
    on his or her current location (see "<a href="#Move">Move</a>" on page 15).
  </p>

  <h2 id="Mulligan">Mulligan</h2>

  <p>
    After a player draws a starting hand during setup, that player has a single
    opportunity to declare a mulligan on any number of the drawn cards he or she
    does not wish to keep in his or her starting hand. These cards are set
    aside, and an equivalent number of cards are drawn and added to the player's
    starting hand. The set-aside cards are then shuffled back into the player's
    deck.
  </p>

  <ul>
    <li>Players take or forgo the opportunity to mulligan in player order.</li>
  </ul>

  <h2 id="Multiclass_Cards" style="color: var(--blue)">
    Multi-class Cards (added in FAQ, section 'Game Play', point 1.16, updated in
    FAQ v.1.9, June 2019)
  </h2>

  <p>
    A multi-class card is a card which bears multiple class icons instead of
    one, and is a card of each of those classes. For example, .45 Thompson (0)
    has both a Rogue ([rogue]) and a Guardian ([guardian]) icon and is thus both
    a Rogue card and a Guardian card for all purposes. Generally, a multi-class
    card can be included in an investigator’s deck if that investigator has
    access to <i>either</i> of that card’s classes.
  </p>

  <img
    class="card-scan"
    src="/img/arkham/zh/cards/05115.avif"
    alt=".45 Thompson (0)"
    loading="lazy"
  />

  <p>
    If an investigator has limited access to one of the classes on a multi-class
    card and unlimited access to one of the other classes on that card, it will
    still occupy one of the investigator’s limited slots unless their
    deckbuilding options contains the word "other" in it
    <i>(see <a href="#Deckbuilding_Options">Deckbuilding Options</a>)</i>.
  </p>

  <p>
    The following section clarifies how multi-class cards operate depending on
    how an investigator’s deckbuilding options are presented.
  </p>

  <ul>
    <li>
      <b
        >Investigators with unlimited access to more than one class
        <i
          >(i.e. All Core Set investigators, Minh Thi Phan, Sefina Rousseau,
          William Yorick, Leo Anderson, Joe Diamond, Preston Fairmont, Diana
          Stanley)</i
        >:</b
      >
      A multi-class card can be included in that investigator’s deck if it falls
      into <i>either</i> of the listed classes.
    </li>

    <li>
      <b
        >Investigators from The Dunwich Legacy expansion
        <i
          >(i.e. Zoey Samaras, Rex Murphy, Jenny Barnes, Jim Culver, "Ashcan"
          Pete)</i
        >:</b
      >
      A multi-class card will not occupy one of these investigator’s five "out
      of class" slots if one of its classes is the class they have unlimited
      access to. A card cannot take up more than one "out of class" slot,
      regardless of how many class icons the card bears.
    </li>

    <li>
      <b
        >Investigators with unlimited access to one class and limited access to
        one or more "other" classes
        <i
          >(i.e. Marie Lambeau, Finn Edwards, Carolyn Fern, investigators from
          Edge of the Earth)</i
        >:</b
      >
      A multi-class card will not occupy one of the investigator’s limited
      slots, because it falls into the unlimited category
      <i>(see <a href="#Deckbuilding_Options">Deckbuilding Options</a>)</i>.
    </li>

    <li>
      <b>Lola Hayes:</b> A multi-class card will count as a card of each of its
      classes toward her Deckbuilding Requirement.
    </li>
  </ul>

  <h2 id="Must">Must</h2>

  <p>
    If an investigator is instructed that he or she "must" choose among multiple
    options, the investigator is compelled to choose an option that has the
    potential to change the game state.
  </p>

  <ul>
    <li>
      In the absence of the word "must" while choosing among multiple options,
      any option may be chosen upon the resolution of the effect – even an
      option that does not change the game state.
    </li>
  </ul>

  <h2 id="Myriad" style="color: var(--red)">
    Myriad (added in <em>The Dream-Eaters</em>)
  </h2>

  <p>
    An investigator may include up to three copies of a player card with the
    myriad keyword in their deck (by title), instead of the normal limit of two
    copies. Additionally, when you purchase a myriad card for your deck, you may
    purchase up to two additional copies of that card (at the same level) at no
    experience cost.
  </p>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Game Play', point 1.20)</span
    >
    When counting the total amount of experience in your deck, each copy of a
    Myriad card after the first copy does not count towards your experience
    total.
  </p>

  <h2>Mythos Phase</h2>

  <p>See "<a href="#Mythos_Phase">I. Mythos phase</a>" on page 24.</p>

  <h2 id="Nearest">Nearest</h2>

  <p>
    Some card abilities reference the "nearest" entity. Nearest refers to the
    entity of the specified kind at a location that can be reached in the fewest
    number of connections, even if one or more of those connections are blocked
    by another card ability. The path to the nearest entity is the "shortest"
    path to that entity.
  </p>

  <h2 id="Nested_Sequences" style="color: var(--blue)">
    Nested Sequences (added in FAQ, section 'Game Play', point 1.4)
  </h2>

  <p>
    Each time a triggering condition occurs, the following sequence is followed:
    1) execute “when...” effects that interrupt that triggering condition, (2)
    resolve the triggering condition, and then, (3) execute “after...” effects
    in response to that triggering condition.
  </p>

  <p>
    Within this sequence, if the use of a [reaction] or
    <b>Forced</b> ability leads to a new triggering condition, the game pauses
    and starts a new sequence: (1) execute “when...” effects that interrupt the
    new triggering condition, (2) resolve the new triggering condition, and
    then, (3) execute “after...” effects in response to the new triggering
    condition. This is called a <b>nested sequence</b>. Once this nested
    sequence is completed, the game returns to where it left off, continuing
    with the original triggering condition’s sequence.
  </p>

  <p>
    It is possible that a nested sequence generates further triggering
    conditions (and hence more nested sequences). There is no limit to the
    number of nested sequences that may occur, but each nested sequence must
    complete before returning to the sequence that spawned it. In effect, these
    sequences are resolved in a Last In, First Out (LIFO) manner.
  </p>

  <p>
    <i
      >For example: Roland and Agnes are embroiled in a fierce battle. Roland
      has a Guard Dog in his play area, and is engaged with a Goat Spawn with 2
      damage on it. Agnes is engaged with a Ghoul Minion. Roland wishes to play
      a .45 Automatic, which provokes an attack of opportunity from the Goat
      Spawn, dealing 1 damage to Roland. Roland assigns this damage to his Guard
      Dog, which has a [reaction] ability: “When an enemy attack deals damage to
      Guard Dog: Deal 1 damage to the attacking enemy.” Before resolving the
      playing of Roland’s .45 Automatic, Guard Dog’s ability resolves, and 1
      damage is dealt to the Goat Spawn, which would defeat it. Goat Spawn has
      the following <b>Forced</b> ability: “When Goat Spawn is defeated: Each
      investigator at this location takes 1 horror.” Before resolving the damage
      dealt to the Guard Dog, 1 horror is dealt to each investigator at the
      location, including Agnes, who has a [reaction] ability: “After 1 or more
      horror is placed on Agnes Baker: Deal 1 damage to an enemy at your
      location.” Before resolving the Goat Spawn’s defeat, Agnes deals 1 damage
      to the Ghoul Minion engaged with her. Now that there are no further
      [reaction] or <b>Forced</b> abilities to trigger, the players return to
      the previous triggering condition and resolve the Goat Spawn’s defeat, and
      resolve any “After...” effects that might occur when it is defeated. Then,
      the players resolve the damage dealt to the Guard Dog, and resolve any
      “After...” effects that might occur from that damage. Finally, the players
      return to the original triggering condition, and Roland is able to put his
      .45 Automatic into play.</i
    >
  </p>

  <h2 id="Nested_Skill_Tests" style="color: var(--blue)">
    Nested Skill Tests (added in FAQ, section 'Game Play', point 1.17)
  </h2>

  <p>
    A skill test cannot initiate during another skill test. If during the
    resolution of a skill test another skill test would initiate, instead the
    second skill test does not initiate until the first skill test has finished
    resolving. If the first skill test was part of an action, the second skill
    test does not initiate until that action has finished resolving.
  </p>

  <p>
    <i
      >For example: Ursula performing an investigate action. As part of this
      investigate action, she must perform an [intellect] test. During the
      resolution of that skill test, she plays Expose Weakness, a fast event
      which initiates another [intellect] test. Instead of resolving the second
      [intellect] test during the first one, the initiation of the second
      [intellect] test is delayed until after the first skill test (and
      therefore the investigate action) has finished resolving.</i
    >
  </p>

  <h2 id="Ownership_and_Control">Ownership and Control</h2>

  <p>
    A card's owner is the player whose deck (or game area) held the card at the
    start of the game.
  </p>

  <p>
    A player controls the cards located in his or her out-of-play game areas
    (such as the hand, deck, discard pile).
  </p>

  <p>
    The scenario controls the cards in its out-of-play game areas (such as the
    encounter, act, and agenda decks, and the encounter discard pile).
  </p>

  <ul>
    <li>
      Cards by default enter play under their owner's control. Some abilities
      may cause cards to change control during a game.
    </li>

    <li>
      If a card would enter an out-of-play area that does not belong to the
      card's owner, the card is physically placed in its owner's equivalent
      out-of-play area instead. The card is considered to have entered its
      controller's out-of-play area, and only the physical placement of the card
      is adjusted.
    </li>
  </ul>

  <h2 id="Parallel_Investigators" style="color: var(--red)">
    Parallel Investigators (added in <em>Parallel Investigators</em>)
  </h2>

  <p>
    Parallel investigators are alternate, print-and-play versions of
    investigators from existing <i>Arkham Horror: The Card Game</i> products.
    These investigators, along with their advanced signature cards, are fully
    playable in any scenario or campaign.
  </p>

  <ul>
    <li>
      When building a Daisy Walker deck, you may choose whether to use the
      original version or the parallel version of both her front side and her
      back side. Each version has its own advantages and disadvantages. You can
      also mix and match the two versions. This means that you can use both
      original sides, both parallel sides, the original front side and parallel
      back side, or the parallel front side and original back side.
    </li>
    <li>
      Regardless of which version of Daisy you use, you may also optionally
      upgrade Daisy’s signature cards to her new advanced signature cards
      (replacing the original versions). These versions are indicated by the
      Advanced keyword on Daisy’s Tote Bag and the “Advanced Weakness” subtitle
      bar on The Necronomicon. These are included only as a set—if you choose to
      upgrade Daisy’s Tote Bag, you must also upgrade The Necronomicon. Doing so
      costs no experience, and may be done at any point during a campaign.
      However, once this upgrade is made, it cannot be undone unless you are
      instructed otherwise.
    </li>
  </ul>

  <img
    alt="Example of a Parallel Investigator card"
    src="/assets-v20260923/rules/parallel_investigators.jpg"
    class="center frame"
    loading="lazy"
    width="1000"
  />

  <h2 id="Parley">Parley</h2>

  <p>
    Some abilities are identified with a
    <strong>Parley</strong> action designator. Such abilities are initiated
    using the "Activate" action (see "<a href="#Activate_Action"
      >Activate Action</a
    >" on page 4).
  </p>

  <h2 id="Partner" style="color: var(--red)">
    Partner (added in <em>Edge of the Earth</em>)
  </h2>

  <p>
    Partner is a keyword ability that appears on the nine story assets in the
    <i>Expedition Team</i> encounter set. Each of these assets represents a
    powerful ally whom investigators can bring along during scenarios in this
    campaign to improve their chances of success. However, bringing an asset
    with the partner keyword endangers that asset, with the risk of losing them
    permanently.
  </p>

  <ul>
    <li>
      At the start of each scenario in this campaign, each investigator is given
      the option to choose a partner asset and put it into play. Partner assets
      cannot be added to an investigator’s deck. An investigator may choose a
      different partner (or no partner) to bring each time they are given this
      choice.
    </li>

    <li>
      A partner asset cannot leave play unless it is defeated (for example, it
      cannot be discarded by card effects unless it is explicitly defeated). If
      an investigator is defeated, any partner asset they have with them is also
      defeated.
    </li>

    <li>
      If a partner asset is defeated, remove it from the game. Then, cross off
      that character’s name in the Expedition Team section of the Campaign Log.
    </li>

    <li>
      Damage or horror on a partner asset is recorded in the Expedition Team
      section of the Campaign Log at the end of each game.
      <i>(The Campaign Guide will instruct you when to do this.)</i>
    </li>

    <li>
      If an investigator resigns from a scenario, their partner asset leaves
      play, but is not defeated. Keep all damage and horror on it, as it will be
      recorded in the Campaign Log after the game ends.
    </li>
  </ul>

  <h2 id="Patrol" style="color: var(--red)">
    Patrol (added in <em>Murder at the Excelsior Hotel</em>)
  </h2>

  <p>
    Some enemies have the patrol keyword. During the enemy phase (in framework
    step 3.2), each ready, unengaged enemy with the patrol keyword moves to a
    connecting location along the shortest path toward the designated location
    (as described in parentheses next to the word patrol).
  </p>

  <ul>
    <li>
      If there are multiple locations that qualify as the desginated location,
      the lead investigator may choose which location the enemy moves toward.
    </li>

    <li>
      If an enemy with patrol would be compelled to move to a location which is
      blocked by a card ability, the enemy does not move.
    </li>

    <li>
      <span style="color: var(--blue)"
        >(Added in FAQ, section 'Frequently Asked Questions')</span
      >
      <i
        >Q: What happens when an enemy with the patrol keyword is already at its
        target location at the start of the enemy phase?</i
      >
      A: If a patrol enemy is at the target location indicated by its patrol
      ability at the start of step 3.2 of the enemy phase, that enemy does not
      move.
    </li>
  </ul>

  <h2 id="Per_Investigator">Per Investigator ([per_investigator])</h2>

  <p>
    When the [per_investigator] symbol appears after a value, that value is
    multiplied by the number of investigators who started the scenario.
  </p>

  <ul>
    <li>
      The "per investigator" multiplication is done before all other modifiers,
      and the product of this multiplication is treated as the printed value of
      the card.
    </li>

    <li>
      Text that uses the phrase "per investigator" also counts the number of
      investigators who started the scenario, and is applied before all other
      modifiers.
    </li>

    <li>
      If investigators have been eliminated from the scenario, they still count
      toward "per investigator" values.
    </li>
  </ul>

  <h2 id="Peril">Peril</h2>

  <p>Peril is a keyword ability.</p>

  <p>
    While resolving the drawing of an encounter card with the peril keyword, an
    investigator cannot confer with the other players. Those players cannot play
    cards, trigger abilities, or commit cards to that investigator's skill
    test(s) while the peril encounter is resolving.
  </p>

  <h2 id="Permanent">Permanent</h2>

  <p>Permanent is a deckbuilding keyword ability.</p>

  <ul>
    <li>
      A card with the permanent keyword does not count towards your deck size.
    </li>

    <li>
      A card with the permanent keyword still counts as being part of your deck
      and must therefore adhere to all other deckbuilding restrictions.
    </li>

    <li>
      A card with the permanent keyword starts each game in play and is not
      shuffled into your investigator deck during setup.
    </li>

    <li>
      A card with the permanent keyword cannot leave play (except by
      elimination).
    </li>

    <li>
      Once added to your deck, permanent cards cannot be removed from your deck
      or swapped out of your deck unless explicitly stated otherwise.
    </li>

    <li>
      <span style="color: var(--blue)"
        >(Added in FAQ, section 'Rulebook Errata', v2.5)</span
      >
      A permanent card cannot have its text box blanked or treated as if it were
      blank.
    </li>
  </ul>

  <p>
    See also: "<a href="#Controlling_and_Attaching_Permanent_Cards"
      >Controlling and Attaching Permanent Cards</a
    >".
  </p>

  <h2 id="Play">Play</h2>

  <p>
    To play a card, an investigator must pay the card's resource cost and meet
    any applicable play restrictions and conditions. Most cards can only be
    played by taking a play action (see "<a href="#Play_Action">Play Action</a>"
    on page 16).
  </p>

  <p>
    A card with the fast keyword is not played during a play action. Such a card
    may be played any time its specified triggering condition is met or, if it
    has no triggering condition, during an appropriate player window (see "<a
      href="#Fast"
      >Fast</a
    >" on page 11).
  </p>

  <p>
    Any time an event card is played, its effects are resolved and it is then
    placed in its owner's discard pile.
  </p>

  <p>
    Any time an asset is played, it is placed in the investigator's play area
    and remains in play until an ability or game effect causes it to leave play.
    Most assets take up one or more slots while in play (see "<a href="#Slots"
      >Slots</a
    >" on page 19).
  </p>

  <p>
    Skill cards are not "played." These cards are
    <em>committed</em> to a skill test from a player's hand in order to use
    their abilities.
  </p>

  <p>
    See also: "<a href="#Appendix_I_Initiation_Sequence"
      >Appendix I: Initiation Sequence</a
    >" on page 22, "<a href="#Play_Restrictions_Permissions_and_Instructions"
      >Play Restrictions, Permissions, and Instructions</a
    >" on page 17.
  </p>

  <h2 id="Play_Action">Play Action</h2>

  <p>
    "Play" is an action an investigator may take during his or her turn in the
    investigation phase.
  </p>

  <p>
    When an investigator takes this action, that investigator selects an asset
    or event card in his or her hand, pays its resource cost, and plays it (see
    "<a href="#Play">Play</a>" on page 16).
  </p>

  <ul>
    <li>
      Cards with the "fast" keyword are not played by using this action (see "<a
        href="#Fast"
        >Fast</a
      >" on page 11).
    </li>

    <li>
      Skill cards are not "played." These cards are
      <em>committed</em> to a skill test from a player's hand in order to use
      their abilities.
    </li>
  </ul>

  <h2 id="Play_Restrictions_Permissions_and_Instructions">
    Play Restrictions, Permissions, and Instructions
  </h2>

  <p>
    Many cards and abilities contain specific instructions pertaining to when or
    how they may or may not be used, or to specific conditions that must be true
    in order to use them. In order to use such an ability or to play such a
    card, its play restrictions must be observed.
  </p>

  <p>
    A permission allows a player to play a card or use an ability outside the
    timing specifications provided by the game rules.
  </p>

  <p>
    A play instruction describes the timing point at which, and/or time period
    during which, an event card may be played.
  </p>

  <h2 id="Prey">Prey</h2>

  <p>
    Given the opportunity, some enemies will pursue a defined investigator.
    These enemies are identified with the bold word "<strong>Prey</strong>" in
    their text box, followed by instructions on whom they should engage.
  </p>

  <ul>
    <li>
      If an enemy that is about to automatically engage an investigator at its
      location has multiple options of whom to engage, that enemy engages the
      investigator who best meets its "prey" instructions (if multiple
      investigators are tied in meeting these instructions, the lead
      investigator may decide among them) (see "<a href="#Enemy_Engagement"
        >Enemy Engagement</a
      >" on page 10).
    </li>

    <li>
      If an enemy that is moving towards the nearest investigator has a choice
      between multiple equidistant investigators, that enemy must select among
      those investigators the one who best meets its "prey" instructions. (If
      multiple equidistant investigators meet the prey criteria, the lead
      investigator decides among those investigators. See "<a href="#Hunter"
        >Hunter</a
      >" on page 12.)
    </li>

    <li>
      If an enemy's prey instructions contain the word "only," that enemy only
      moves towards and engages that investigator (as if it were the only
      investigator in play), and ignores all other investigators while moving
      and engaging. Other investigators may use the engage action or card
      abilities to engage the enemy.
    </li>

    <li>
      Prey has no immediate effect on where an enemy will spawn (see "<a
        href="#Spawn"
        >Spawn</a
      >" on page 19).
    </li>
  </ul>

  <h2 id="Printed">Printed</h2>

  <p>
    The word "printed" refers to the text, characteristic, icon, or value that
    is physically printed on the card.
  </p>

  <h2 id="Priority_of_Simultaneous_Resolution">
    Priority of Simultaneous Resolution
  </h2>

  <p>
    If an effect affects multiple players simultaneously, but the players must
    individually make choices to resolve the effect, these choices are made in
    player order. Once all necessary choices have been made, the effect resolves
    simultaneously upon all affected entities.
  </p>

  <ul>
    <li>
      If two or more forced abilities (including delayed effects) would resolve
      at the same time, the lead investigator determines the order in which the
      abilities resolve.
    </li>

    <li>
      If two or more constant abilities and/or lasting effects cannot be applied
      simultaneously, the lead investigator determines the order in which they
      are applied.
    </li>
  </ul>

  <h2 id="Prologue_Investigators" style="color: var(--red)">
    Prologue Investigators (added in <em>The Circle Undone</em>)
  </h2>

  <p>
    The four investigator cards depicted here (Gavriella Mizrah, Jerome Davids,
    Penny White, and Valentino Rivas) are marked with the
    <i>Disappearance at the Twilight Estate</i> encounter set icon and can only
    be used in the prologue for <i>The Circle Undone</i>. They cannot be used in
    other scenarios. Keep them with the rest of the scenario cards for
    <i>Disappearance at the Twilight Estate</i>, and do not integrate them into
    your collection of player cards.
  </p>

  <table>
    <tr>
      <td>
        <img
          alt="Scan of 05046"
          class="card-scan"
          src="/img/arkham/zh/cards/05046.avif"
          loading="lazy"
        />
      </td>
      <td>
        <img
          alt="Scan of 05047"
          class="card-scan"
          src="/img/arkham/zh/cards/05047.avif"
          loading="lazy"
        />
      </td>
    </tr>
    <tr>
      <td>
        <img
          alt="Scan of 05048"
          class="card-scan"
          src="/img/arkham/zh/cards/05048.avif"
          loading="lazy"
        />
      </td>
      <td>
        <img
          alt="Scan of 05049"
          class="card-scan"
          src="/img/arkham/zh/cards/05049.avif"
          loading="lazy"
        />
      </td>
    </tr>
  </table>

  <h2 id="Put_into_Play">Put into Play</h2>

  <p>
    Some card abilities cause a card to be "put into play." Such abilities place
    the card directly into play from an out-of-play state.
  </p>

  <ul>
    <li>
      The resource cost of a card being put into play
      <strong>is not paid</strong>.
    </li>

    <li>
      Unless otherwise stated by the put into play ability, cards that enter
      play in this manner must do so in a play area that satisfies the standard
      game rules associated with playing or drawing (for encounter cards) that
      card.
    </li>

    <li>
      A card that has been put into play is not considered to have been played
      or drawn.
    </li>
  </ul>

  <h2 id="Qualifiers">Qualifiers</h2>

  <p>
    If card text includes a qualifier followed by multiple terms, the qualifier
    applies to each term in the list.
    <em
      >(For example, in the phrase "each unique ally and item," the word
      "unique" is a qualifier that applies both to "ally" and to "item.")</em
    >
  </p>

  <h2 id="Reaction_Opportunities" style="color: var(--blue)">
    Reaction Opportunities (added in FAQ, section 'Game Play', point 1.3)
  </h2>

  <p>
    When a triggering condition resolves, investigators are granted the
    opportunity to resolve [reaction] abilities in response to that triggering
    condition. It is only after all investigators have passed their reaction
    opportunity that the game moves forward.
  </p>

  <p>
    Using a [reaction] ability in response to a triggering condition does not
    prevent other [reaction] abilities from being used in response to that same
    triggering condition.
  </p>

  <p>
    <i
      >For example: Roland has just defeated an enemy and wishes to trigger his
      [reaction] ability: “After you defeat an enemy: Discover 1 clue at your
      location.” He discovers 1 clue at his location. He may then play Evidence!
      in response to defeating that same enemy. As both cards have the same
      triggering condition (“After you defeat an enemy”), triggering one of
      these reactions does not prevent Roland from triggering the other.</i
    >
  </p>

  <h2 id="Ready">Ready</h2>

  <p>
    A card that is in an upright state so that its controller can read its text
    from left to right is considered ready.
  </p>

  <ul>
    <li>The default state in which cards enter play is ready.</li>

    <li>
      When an exhausted card readies, it is returned to the upright state. It is
      then said to be in a ready state.
    </li>

    <li>
      A ready card cannot ready again (it must first be exhausted, typically by
      a game step or card ability).
    </li>
  </ul>

  <h2 id="Record_in_your_Campaign_Log">“Record in your Campaign Log...”</h2>

  <p>
    Often the players will be instructed to record a key phrase in the Campaign
    Log. This should be written under “Campaign Notes” unless specified
    otherwise. Because the players may be instructed to check the Campaign Log
    for this phrase at a later time in the campaign, the indicated phrase should
    be recorded as it appears, without alteration.
  </p>

  <p>
    <i
      >For example: If the players are instructed to record in the Campaign Log
      that “the investigators were four hours late,” this shouldn’t be rewritten
      as “the investigators were pretty late,” because the exact number of hours
      might be important in a later scenario.</i
    >
  </p>

  <h2 id="Relentless" style="color: var(--red)">
    Relentless (added in <em>The Drowned City</em>)
  </h2>

  <p>
    Some enemies in this campaign have the relentless keyword. During the enemy
    phase (after framework step 3.3), each enemy with the relentless keyword
    that has attacked this phase (even if that attack was canceled) readies and
    attacks the investigator(s) it is engaged with a second time.
  </p>

  <h2 id="Remember_that">“Remember that...”</h2>

  <p>
    Sometimes a scenario card will instruct the investigators to “remember” a
    key phrase, often based on an action they have taken or a decision they have
    made within that scenario. This phrase may come up later during that
    scenario, and may trigger additional or different effects. There is no need
    to record this phrase in the Campaign Log, because it will only ever matter
    during that scenario, or during that scenario’s resolution. The players do
    not need to “remember” any such instruction beyond the end of the scenario
    in which it appears.
  </p>

  <h2 id="Removed_from_Game">Removed from Game</h2>

  <p>
    A card that has been removed from the game is placed away from the game area
    and has no further interaction with the game in any manner for the duration
    of its removal.
  </p>

  <p>
    If there is no specified duration, a card that has been removed from the
    game is considered removed until the end of the game.
  </p>

  <h2 id="Replacing_an_Opening_Hand" style="color: var(--blue)">
    Replacing an Opening Hand (added in FAQ, section 'Card Ability
    Interpretation', point 2.6)
  </h2>

  <p>
    If an ability replaces an investigator’s opening hand with a different set
    of cards, that set of cards is considered to be their new opening hand for
    the purposes of effects which would alter the number of cards in their
    opening hand.
  </p>

  <p>
    If an ability replaces an investigator’s opening hand with a number of cards
    "kept" from a larger set of cards, an effect which alters the number of
    cards in that investigator’s opening hand alters both the cards originally
    drawn to replace that opening hand, and the number of cards "kept" from that
    larger set.
  </p>

  <p>
    <i
      >For example, the ability on Sefina Rousseau reads: "When you would draw
      your opening hand: Draw 13 cards,instead. Choose up to 5 events to place
      beneath this card and keep 8 cards as your opening hand. Discard the
      rest." If a card effect or game effect alters the number of cards in
      Sefina’s opening hand, it would alter both the number of cards drawn from
      her ability and the number of cards she keeps as her opening hand.</i
    >
  </p>

  <h2 id="Replacement_Cards" style="color: var(--red)">
    Replacement Cards (added in <em>Parallel Investigators</em>)
  </h2>

  <p>
    Signature cards with the Replacement keyword are optional replacements for
    the given card. When building a deck, you may choose to replace the specific
    cards listed under “Deckbuilding Requirements” with all of that
    investigator’s replacement cards. Doing so satisfies your Deckbuilding
    Requirements. During a campaign, this choice cannot be unmade.
  </p>

  <p>
    <i>
      For example: Marta is building a Lola Hayes deck. Improvisation and Crisis
      of Identity are listed under Deckbuilding Requirements for Lola Hayes.
      Marta may choose to instead replace those four cards with all five
      versions of Leading Lady, as well as Samuel Blake.
    </i>
  </p>

  <p>
    You may also choose to include all cards listed under “Deckbuilding
    Requirements” as well as all of that investigator’s replacement cards.
    Replacement cards added in this manner do not count towards the
    investigator’s deck size.
  </p>

  <p>
    <i>
      For example: Marta is building a Lola Hayes deck. Instead of deciding
      between her typical signature cards and her replacement signature cards,
      Marta may choose to add all ten cards to her deck.
    </i>
  </p>

  <h2 id="Researched" style="color: var(--red)">
    Researched (added in <em>Edge of the Earth</em>)
  </h2>

  <p>
    Researched is a keyword ability that appears on some higher-level cards
    (most prominently on Seeker cards.)
  </p>

  <p>
    To be included in an investigator's deck, a card with the Researched keyword
    must first be "identified" or "translated" by performing a task on the lower
    level version of that card and recording the result in your Campaign Log.
  </p>

  <ul>
    <li>
      You can only include a researched card in your deck by upgrading it from
      its lower level version.
    </li>

    <li>
      You may only include a researched card in your deck if, in your Campaign
      Log, you have recorded the completion of the task described in the lower
      level version of that card.
    </li>

    <li>
      After an investigator has completed this task and recorded it in the
      Campaign Log, any investigator in that campaign may upgrade the relevant
      card following the normal rules for upgrading player cards.
    </li>
  </ul>

  <p>
    <i
      >For example, Archive of Conduits (Gateway to Tindalos) has the
      "Researched" keyword. Therefore, an investigator cannot purchase Archive
      of Conduits (Gateway to Tindalos) directly. They must instead upgrade it
      from Archive of Conduits (Unidentified), and they can only do so if they
      have "identified the gateway."</i
    >
  </p>

  <table>
    <tr>
      <td>
        <img
          src="/img/arkham/zh/cards/08033.avif"
          alt="Archive of Conduits (Unidentified)"
          class="card-scan"
          loading="lazy"
        />
      </td>
      <td>
        <img
          src="/img/arkham/zh/cards/08041.avif"
          alt="Archive of Conduits (Gateway to Tindalos)"
          class="card-scan"
          loading="lazy"
        />
      </td>
    </tr>
  </table>

  <h2 id="Resign">Resign</h2>

  <p>
    Some abilities are identified with a
    <strong>Resign</strong> action designator. Such abilities are initiated
    using the "Activate" action (see "<a href="#Activate_Action"
      >Activate Action</a
    >" on page 4).
  </p>

  <ul>
    <li>
      When an investigator resigns, the investigator is eliminated by
      resignation (see "<a href="#Elimination">Elimination</a>" on page 10.) An
      investigator who resigns is not considered to have been defeated.
    </li>
  </ul>

  <h2 id="Resource_Action">Resource Action</h2>

  <p>
    "Resource" is an action an investigator may take during his or her turn in
    the investigation phase.
  </p>

  <p>
    When an investigator takes this action, that investigator gains one resource
    by taking it from the token pool and adding it to his or her resource pool.
  </p>

  <h2 id="Resources">Resources</h2>

  <p>
    Resources represent the various means of acquiring new cards at an
    investigator's disposal – supplies, money, tools, knowledge, spell
    components, etc.
  </p>

  <ul>
    <li>
      In order to play a card or use an ability that costs resources, an
      investigator must pay that card or ability's resource cost by taking the
      specified number of resources from his or her resource pool and returning
      them to the token pool (see "<a href="#Costs">Costs</a>" on page 7).
    </li>

    <li>
      Resources can be gained by performing the "Resource" action (see "<a
        href="#Resource_Action"
        >Resource Action</a
      >" on page 17).
    </li>

    <li>
      Investigators acquire one resource during each Upkeep phase (see "<a
        href="#Upkeep_Phase"
        >4.4 Each investigator draws 1 card and gains 1 resource</a
      >" on page 25).
    </li>
  </ul>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Card Ability Interpretation', point 2.8)</span
    >
    If an ability refers to the number of "resources you have," "your
    resources," or any variation on the above, it is only referring to the
    number of resources in that investigator’s resource pool. Resources on other
    cards that investigator controls do not count toward this total unless
    explicitly stated.
  </p>

  <p>See also: "<a href="#Tokens">Tokens, Running out of</a>" on page 20.</p>

  <h2 id="Retaliate">Retaliate</h2>

  <p>Retaliate is a keyword ability.</p>

  <p>
    Each time an investigator fails a skill test while attacking a ready enemy
    with the retaliate keyword, after applying all results for that skill test,
    that enemy performs an attack against the attacking investigator. An enemy
    does not exhaust after performing a retaliate attack.
  </p>

  <ul>
    <li>
      This attack occurs whether the enemy is engaged with the attacking
      investigator or not.
    </li>
  </ul>

  <h2 id="Revelation">Revelation</h2>

  <p>
    A revelation ability may appear on encounter cards or on weakness cards.
  </p>

  <ul>
    <li>
      When an investigator draws an encounter card, that investigator must
      resolve all "<strong>Revelation</strong>
      – " abilities on the card. This occurs before the card enters play, or in
      the case of a treachery card, before it is placed in the discard pile.
    </li>

    <li>
      When a weakness card enters an investigator's hand, that investigator must
      immediately resolve all revelation abilities on the card as if it were
      just drawn.
    </li>
  </ul>

  <h3 id="Dilemmas_and_Revelation_Abilities" style="color: var(--red)">
    Dilemmas and Revelation Abilities (added in
    <em>The Scarlet Keys</em>)
  </h3>

  <p>
    Some player cards (namely those with the
    <b><i>Dilemma</i></b> trait) possess revelation abilities. As with
    revelation abilities on other cardtypes, these abilities resolve when the
    card is drawn or otherwise enters your hand, not when the card is played.
  </p>

  <ul>
    <li>
      These cards have no cost (“–”). These cards cannot be played; their
      effects only resolve when they are drawn or added to your hand.
    </li>

    <li>
      After resolving a revelation ability on a player card, place it in its
      owner’s discard pile.
    </li>

    <li>
      Revelation abilities do not resolve during setup. If one or more player
      cards with revelation abilities are drawn during setup, wait until the
      game begins, then each player (in player order) resolves all of their own
      revelation abilities in the order of their choosing.
    </li>
  </ul>

  <h3 id="Revelation_Ability_Priority" style="color: var(--blue)">
    Revelation Ability Priority (added in FAQ, section 'Card Ability
    Interpretation', point 2.25)
  </h3>

  <p>
    If an investigator has both a <b><i>Dilemma</i></b> card and a weakness
    and/or encounter card in their hand, the weakness and/or encounter card must
    be resolved first. If a <b><i>Dilemma</i></b> card is drawn while resolving
    a skill test, resolve the skill test in full before resolving the
    <b><i>Dilemma</i></b
    >’s <b>Revelation</b> effect.
  </p>

  <h2 id="Sanity_and_Horror">Sanity and Horror</h2>

  <p>
    Sanity represents a card's mental and emotional fortitude. Horror tracks the
    harm that has been done to a card's psyche by exposure to the Mythos.
  </p>

  <ul>
    <li>
      When a card takes horror, place a number of horror tokens equal to the
      amount of horror just taken on the card (see "<a
        href="#Dealing_Damage_Horror"
        >Dealing Damage/Horror</a
      >" on page 7).
    </li>

    <li>
      If an investigator has horror on him or her equal to or greater than his
      or her sanity, that investigator is defeated. When an investigator is
      defeated, he or she is eliminated from the scenario (see "<a
        href="#Elimination"
        >Elimination</a
      >" on page 10).
    </li>

    <li>
      In campaign play, an investigator that is defeated by taking horror equal
      to his or her sanity suffers 1 mental trauma. Taking mental trauma may
      cause an investigator to be driven <strong>insane</strong> (see "<a
        href="#Campaign_Play"
        >Campaign Play</a
      >" on page 5 for more information).
    </li>

    <li>
      If an asset with a sanity value has horror on it equal to or greater than
      its sanity, it is defeated and placed on its owner's discard pile.
    </li>

    <li>
      A card's "remaining sanity" is its base sanity minus the amount of horror
      on that card, plus or minus any active sanity modifiers.
    </li>

    <li>
      An asset card without a sanity value is not considered to have a sanity of
      0, cannot gain sanity, and cannot have horror assigned to it.
    </li>
  </ul>

  <p>
    See also: "<a href="#Direct_Damage_Direct_Horror"
      >Direct Damage, Direct Horror</a
    >" on page 9.
  </p>

  <h2 id="Seal" style="color: var(--red)">
    Seal (added in <em>The Forgotten Age</em>)
  </h2>

  <p>
    As an additional cost for a card with the seal keyword to enter play, its
    controller must search the chaos bag for the specified chaos token and place
    it on top of the card, thereby sealing it. If there is a choice of which
    token to seal, the card's controller chooses. If the specified token is not
    in the chaos bag, the card cannot enter play. A sealed chaos token is not
    considered to be in the chaos bag, and therefore cannot be revealed from the
    chaos bag as part of a skill test or ability.
  </p>

  <p>
    When a chaos token is "released," it is returned to the chaos bag and is no
    longer considered sealed.
    <strong
      >If a card with one or more chaos tokens sealed on it leaves play for any
      reason, any chaos tokens sealed on it are immediately released.</strong
    >
  </p>

  <p>
    Some cards (with or without the seal keyword) may also have abilities that
    seal one or more chaos tokens as part of their effect. This is done
    following the same process as above: searching the chaos bag for the
    specified token, removing it from the chaos bag, and placing it on the card.
    If the specified token is not in the chaos bag, the effect fails.
  </p>

  <h2 id="Search">Search</h2>

  <p>
    When a player is instructed to search for a card, that player is permitted
    to look at all of the cards in the searched area without revealing those
    cards to the other players.
  </p>

  <ul>
    <li>
      If an effect searches an entire deck, the deck must be shuffled upon
      completion of the search.
    </li>

    <li>
      When resolving a search effect, a player is obligated to find the object
      of the search should one or more eligible options be found within the
      searched area.
    </li>

    <li>
      While cards are in the process of being searched, they are not considered
      to have left their game area of origin.
    </li>
  </ul>

  <h3 id="Looking_At_Searching_And_Finding" style="color: var(--blue)">
    "Looking at," "Searching," and "Finding" (added in FAQ, section 'Card
    Ability Interpretation', point 2.13)
  </h3>

  <p>
    These three terms all involve sifting through out-of-play cards (typically
    an investigator’s deck or the encounter deck), but do not count as one
    another for the purposes of other card effects.
    <i
      >For example, if an investigator "looks at" the top 3 cards of their deck,
      this is not a search effect. Additionally, while "finding" a card does
      typically involve searching through out-of-play areas, this is also not
      considered to be a search effect.</i
    >
  </p>

  <h3 id="Searching_During_Setup" style="color: var(--blue)">
    Searching During Setup (added in FAQ, section 'Game Play', point 1.26)
  </h3>

  <p>
    If an investigator is instructed to search a deck for 1 or more cards during
    setup, abilities that trigger when a deck is searched (such as Mandy
    Thompson’s [reaction] ability or abilities on <b><i>Research</i></b> cards)
    cannot be resolved, as the game has not yet begun.
  </p>

  <h2 id="Self_Referential_Text">Self-Referential Text</h2>

  <p>
    When a card's ability text refers to its own title, it is referring to
    itself only, and not to other copies (by title) of the card.
  </p>

  <p>
    Self-referential abilities using the word "this" (e.g. "this card") refer
    only to the card on which the ability is located, and not to copies of that
    card.
  </p>

  <h2 id="Set_Aside">Set Aside</h2>

  <p>
    Some scenarios instruct the players to set aside specific cards. Set-aside
    cards have no interaction with the game until they are referenced by
    instructions within the scenario or by a card ability.
  </p>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Card Ability Interpretation', point 2.7)</span
    >
    If an effect instructs an investigator to take control of a card that is
    currently set-aside, that effect puts that card into play in that
    investigator’s play area.
  </p>

  <h2 id="Signature_Cards">Signature Cards</h2>

  <p>
    An investigator's "signature cards" are the cards that are only available to
    that investigator, and cannot be included in another investigator’s deck.
    This includes player cards with the text “(Investigator Name) deck only,” as
    well as non-basic weaknesses that are listed under “Deckbuilding
    Requirements” and therefore can only be included in that investigator’s
    deck.
  </p>

  <p>Signature cards are governed by the following additional rules:</p>

  <ul>
    <li>
      The number of each signature card listed under an investigator's
      "Deckbuilding Requirements" is the exact number of copies of that card
      that is to be included in that investigator’s deck. If no number is
      specified, that number is 1.<br />

      <i
        >For example: Under "Deckbuilding Requirements" for Roland Banks, the
        following cards are listed: "Roland's .38 Special, Cover Up, 1 random
        basic weakness.” Roland Banks must include exactly 1 copy of his
        signature cards—Roland’s .38 Special and Cover Up. He is not permitted
        to include more than 1 copy of either of these cards.</i
      >
    </li>

    <li>
      An investigator cannot play or commit another investigator’s signature
      cards, control another investigator’s signature cards while they are in
      play, or possess another investigator’s signature cards in their hand
      <span style="color: var(--blue)"
        >(amended in FAQ, section 'Definitions and Terms', v.2.0)</span
      >. If a game effect would force a player to take control of a card with
      another investigator's signature card attached to it, that signature card
      is discarded
      <span style="color: var(--blue)"
        >(amended in FAQ, section 'Definitions and Terms', v.2.1)</span
      >.<br />

      <i
        >For example: Roland has the Roland's .38 Special card in play. He has
        the card "Teamwork" which can allow investigators at the same location
        to trade or give assets among one another. However, because Roland’s .38
        Special is one of Roland’s signature cards, he cannot give it to another
        investigator.</i
      >
    </li>

    <li>
      Signature cards need not abide by typical deckbuilding restrictions, and
      do not count toward any deckbuilding limitations if other cards share the
      same title.
    </li>
  </ul>

  <h2 id="Skill_Cards">Skill Cards</h2>

  <p>
    Skill cards represent innate or learned attributes or character traits that
    improve an investigator's skill tests.
  </p>

  <p>
    Skill cards are not played from a player's hand. In order to resolve their
    abilities, skill cards must be committed to a skill test.
  </p>

  <p>
    If a skill card is committed to a skill test, its ability may be used during
    the resolution of that skill test, as specified on the card.
  </p>

  <p>See "<a href="#Skill_Test_Timing">Skill Test Timing</a>" on page 26.</p>

  <h2 id="Skill_Tests">Skill Tests</h2>

  <p>
    A number of situations in the game require an investigator to make a skill
    test, using one of his or her four skills: willpower ([willpower]),
    intellect ([intellect]), combat ([combat]), or agility ([agility]). A skill
    test pits the investigator's value in a specified skill against a difficulty
    value that is determined by the ability or game step that initiated the
    test. The investigator is attempting to match or exceed this difficulty
    value in order to succeed at the test.
  </p>

  <p>
    A skill test is often referred to as a test of the specified skill.
    <em
      >(For example: "agility test," "combat test," "willpower test," or
      "intellect test.")</em
    >
  </p>

  <p>See "<a href="#Skill_Test_Timing">Skill Test Timing</a>".</p>

  <h3 id="Skill_Test_Results_and_Advanced_Timing" style="color: var(--blue)">
    Skill Test Results and Advanced Timing (added in FAQ, section 'Game Play',
    point 1.7)
  </h3>
  <p>
    During Step 7 of Skill Test Timing ("Apply skill test results"), all of the
    effects of the successful skill test are determined and resolved, one at a
    time. This includes the effects of the test itself (such as the clue
    discovered while investigating, or the damage dealt during an attack), as
    well as any "If this test is successful..." effects from card abilities or
    skill cards committed to the test.
  </p>

  <p>
    [reaction] or <b>Forced</b> abilities with a triggering condition dependent
    upon the skill test being successful or unsuccessful (such as "After you
    successfully investigate," or "After you fail a skill test by 2 or more") do
    not trigger at this time. These abilities are triggered during Step 6,
    "Determine success/failure of skill test."
  </p>

  <h3 id="Variable_Difficulty_Skill_Tests" style="color: var(--blue)">
    Variable Difficulty Skill Tests (added in FAQ, section 'Game Play', point
    1.38)
  </h3>

  <p>
    While performing a skill test whose difficulty is modified based on another
    aspect of the game, that difficulty changes whenever the corresponding
    aspect's status does.
  </p>

  <p>
    If an ability or game effect checks a variable difficulty, most commonly
    during a skill test's ST.6 to determine whether that test succeeded or
    failed, the value of that difficulty is set for the effect in question and
    is not re-evaluated if the variable difficulty continues to change.
  </p>

  <p>
    <i
      >For example: An investigator draws Empyrean Brilliance during a Day
      scenario. They have five cards in hand, making the [willpower] test’s
      difficulty 4. They commit one card to the test during ST.2, at which point
      their hand size drops below 5 and the test's difficulty updates
      correspondingly to 2. If, instead, they committed no cards and proceeded
      to fail the test during ST.6, their hand size would drop below 5 during
      ST.7 due to Empyrean Brilliance's effect. While the skill test's
      difficulty would then update to 2, the test's success/failure (and degree
      thereof) has already been determined and is not re-evaluated based on the
      new difficulty.</i
    >
  </p>

  <img
    src="/img/arkham/zh/cards/10730.avif"
    alt="Empyrean Brilliance"
    class="card-scan"
    loading="lazy"
  />

  <h2 id="Slots">Slots</h2>

  <p>
    Each investigator has a number of specific slots that can be filled at any
    given moment. Each asset in an investigator's play area or threat area with
    a slot symbol is held in a slot of that type. Slots limit the number of
    asset cards the investigator is permitted to have in play simultaneously.
  </p>

  <p>The slots normally available to an investigator are:</p>

  <ul>
    <li><strong> 1 accessory slot</strong></li>

    <li><strong> 1 body slot</strong></li>

    <li><strong> 1 ally slot</strong></li>

    <li><strong> 2 hand slots</strong></li>

    <li><strong> 2 arcane slots</strong></li>
  </ul>

  <p>
    If an asset has no slot symbols on it, it does not take up any of the above
    slots. There is no limit to the number of slot-less assets an investigator
    can have in play. The following symbols (on an asset) indicate which slot(s)
    that asset fills:
  </p>

  <table>
    <tr>
      <td>[accessory_inverted] 1 accessory slot</td>
    </tr>
    <tr>
      <td>[body_inverted] 1 body slot</td>
    </tr>
    <tr>
      <td>[ally_inverted] 1 ally slot</td>
    </tr>
    <tr>
      <td>[hand_inverted] 1 hand slot | [hand_x2_inverted] 2 hand slots</td>
    </tr>
    <tr>
      <td>[arcane_inverted] 1 arcane slot | [arcane_x2_inverted] 2 arcane slots</td>
    </tr>
  </table>

  <p>See also <a href="#Tarot_Slot">Tarot Slot</a>.</p>

  <p>
    If playing or gaining control of an asset would put an investigator above
    his or her slot limit for that type of asset, the investigator must choose
    and discard other assets under his or her control simultaneously with the
    new asset entering the slot.
  </p>

  <h3 id="Shifting_Slots" style="color: var(--blue)">
    Shifting Slots (added in FAQ, section 'Game Play', point 1.24)
  </h3>

  <p>
    Some card effects allow an investigator to put assets of one slot type into
    one of their other slots, allow one of an investigator’s slot types to carry
    assets of a different slot type, or cause assets to no longer take up slots.
    In such an event, the investigator must decide which slot is holding which
    asset at the moment it is played. This cannot be adjusted later unless the
    contents or quantity of the investigator’s slots changes, at which point the
    investigator may switch which slots are holding any of their assets.
  </p>

  <p>
    <i
      >For example: Kōhaku has Occult Reliquary in play when he plays Blessed
      Blade. He chooses to have Occult Reliquary grant him a hand slot to hold
      Blessed Blade. If he later plays another Blessed card, such as Hallowed
      Mirror, he can choose to have the new card take up the additional slot and
      define the slot type, while he moves Blessed Blade to his default hand
      slot.</i
    >
  </p>

  <h2 id="Spawn">Spawn</h2>

  <p>
    Some enemies, when drawn from the encounter deck, spawn in a particular
    location, indicated by a bold "<strong>Spawn</strong>" instruction in the
    text box.
  </p>

  <ul>
    <li>
      An enemy's spawn instruction resolves as the enemy enters play, regardless
      of how it entered play.
    </li>

    <li>
      If an enemy has no spawn instruction, it spawns engaged with the
      investigator who drew it.
    </li>

    <li>
      If an enemy has no legal location to spawn at (for example, if its spawn
      instruction directs it to a specific location that is not in play, or if
      no location in play satisfies its "spawn" instruction), it does not spawn,
      and is discarded instead.
    </li>

    <li>
      If an enemy's spawn instruction has multiple valid locations, the
      investigator spawning that enemy decides among those locations.
    </li>

    <li>
      If a card ability instructs the players to spawn an enemy in a particular
      location
      <em
        >(for example: "Search the encounter deck for an Acolyte and spawn it in
        Southside")</em
      >, treat the ability causing the card to enter play as the enemy's spawn
      instruction, overriding any other spawn instruction.
    </li>
  </ul>

  <h3 id="Spawning_an_Enemy" style="color: var(--blue)">
    Spawning an Enemy (added in FAQ, section 'Quick Reference')
  </h3>

  <p>
    1. If an enemy is being spawned without an investigator drawing it, the
    effect spawning the enemy will typically indicate where that enemy should
    spawn. After spawning the enemy at that location, it will automatically
    engage investigators at its location using the rules for "<a
      href="#Enemy_Engagement"
      >Enemy Engagement</a
    >", unless it is aloof.
  </p>

  <p>
    2. If an investigator draws an enemy, check to see if the enemy has a "Spawn
    –" instruction.
  </p>

  <ul>
    <li>
      If the enemy has a "Spawn –" instruction, the enemy spawns at the
      indicated location. After spawning the enemy at that location, it will
      automatically engage investigators at its location using the rules for "<a
        href="#Enemy_Engagement"
        >Enemy Engagement</a
      >", unless it is aloof.
    </li>

    <li>
      If the enemy does not have a "Spawn –" instruction, the investigator
      drawing the enemy spawns it engaged with him/her, unless it is aloof.
    </li>
  </ul>

  <p>
    <b
      >"Prey –" instructions have no direct impact on which location an enemy
      will spawn at.</b
    >
    The only time "Prey –" instructions will impact this process is when an
    enemy spawns unengaged at a location with multiple investigators, and you
    use the rules for "<a href="#Enemy_Engagement">Enemy Engagement</a>" to
    determine which investigator it should automatically engage.
  </p>

  <h2 id="Specialist_Cards" style="color: var(--red)">
    Specialist Cards (added in <em>The Drowned City</em>)
  </h2>

  <p>
    Some of the player cards in this product belong to a new group of Neutral
    cards known as Specialist cards. Specialist cards can be identified by their
    black color and by the absence of any class icon.
  </p>

  <p>
    Each Specialist card also contains text that specifies one or more
    <b>Traits</b>, e.g. “<b>Miskatonic</b>, <b>Scholar</b> deck only.” An
    investigator <b>must</b> have one or more of the indicated
    <b>Traits</b> printed on their investigator card in order to purchase that
    Specialist card.
  </p>

  <p>
    Additionally, an investigator must follow all of their deckbuilding options
    and restrictions when looking to purchase a Specialist card for their deck.
  </p>

  <p>
    <i>
      For example: Dakota Garofalo is a specialist <b></b>Ally asset with the
      text “<b>Detective</b>, <b>Hunter</b>, <b>Wayfarer</b> deck only” in its
      text box. Only investigators with the <b>Detective</b>, <b>Hunter</b>,
      and/or <b>Wayfarer</b> traits may purchase this card, regardless of other
      deckbuilding access. For example, Marion Tavares does not possess any of
      the specified <b>Traits</b>, and therefore cannot include this card in her
      deck. However, Michael McGlen with the <b>Hunter</b> trait may purchase
      Dakota Garofalo.
    </i>
  </p>

  <img
    src="/img/arkham/zh/cards/11110.avif"
    alt="Dakota Garofalo"
    class="card-scan"
    loading="lazy"
  />

  <h2 id="Standalone_Mode">Standalone Mode</h2>

  <p>
    When playing a standalone game (i.e., playing a single scenario as a one-off
    adventure, removed from its campaign), the following rules apply:
  </p>

  <ul>
    <li>
      When building a deck for a standalone game, an investigator may use higher
      level cards in his or her deck (so long as they observe the deckbuilding
      restrictions of the investigator) by counting the total experience of all
      the higher level cards used in the deck, and taking additional random
      basic weaknesses based on the following table:<br />
      <br />
      0-9 experience: 0 additional random basic weaknesses<br />
      10-19 experience: 1 additional random basic weakness<br />
      20-29 experience: 2 additional random basic weaknesses<br />
      30-39 experience: 3 additional random basic weaknesses<br />
      40-49 experience: 4 additional random basic weaknesses<br />
      <br />
      A player cannot include 50 or more experience worth of cards in a
      standalone deck.
    </li>

    <li>
      After choosing a scenario to play, refer to the Campaign Guide for the
      campaign that scenario is a part of, starting at the setup for that
      campaign, and continuing on to the first scenario for that campaign. Read
      through that scenario's introduction, then skip directly to that
      scenario's resolution and choose a resolution that is amenable to you. You
      may choose any resolution you wish. (For an added challenge, choose
      resolutions that put the investigators in an unfavorable state). If the
      players are unsure which resolution to choose, or are indifferent, choose
      <strong>Resolution 1</strong>. Record the results of the chosen resolution
      in a Campaign Log as if you were playing through in campaign mode,
      <strong>except do not count experience points</strong>.
    </li>

    <li>
      Repeat this process for each scenario up to the scenario you wish to play.
      Then, setup and play that scenario as normal.
    </li>

    <li>
      If a story decision would occur during gameplay, choose the outcome and
      record it in your campaign log.
    </li>

    <li>
      Do not apply trauma for having been defeated during gameplay, but if
      trauma is inflicted during a scenario resolution, apply it.
    </li>

    <li>
      If a scenario weakness or asset is earned that is in an expansion you do
      not own, simply continue without that card.
    </li>
  </ul>

  <h3 id="Standalone_Scenario_Setup" style="color: var(--blue)">
    Standalone Scenario Setup (added in FAQ, section 'Game Play', point 1.34)
  </h3>

  <p>
    Most campaign scenarios contain additional instructions for playing that
    scenario in Standalone Mode, which can be found at the end of that
    scenario’s normal setup instructions. These may be used in place of
    simulating campaign resolutions (as described in the Rules Reference) in
    order to determine setup for a standalone game.
  </p>

  <p>
    If a scenario lacks these additional instructions, players may instead
    choose (prior to game start if possible, or as relevant during gameplay
    otherwise) what details have been recorded in their temporary Campaign Log.
    When assembling the chaos bag, players do so using the Campaign Setup
    instructions. As an optional rule, players may then increase the quantities
    of [skull], [cultist], [tablet], [elder_thing], or any other
    campaign-specific symbol tokens contained in the chaos bag.
  </p>

  <h2 id="Story_Cards" style="color: var(--red)">
    Story Cards (added in <em>The Path to Carcosa</em>)
  </h2>

  <p>
    Story cards serve as an avenue for additional narrative and typically appear
    as the reverse side of another scenario card. When you are instructed to
    resolve a story card, simply read its story text and resolve its game text,
    if any.
  </p>

  <h2 id="Supplies" style="color: var(--red)">
    Supplies (added in <em>The Forgotten Age</em>)
  </h2>

  <p>
    At certain points throughout
    <em>The Forgotten Age</em> campaign, investigators are given the opportunity
    to choose supplies to bring on their expeditions into the wilds. These
    supplies are recorded in the Campaign Log, under each investigator's
    "Supplies" section.
  </p>

  <p>
    Supplies are purchased with supply points, which are granted to
    investigators whenever they are given the opportunity to purchase supplies.
    Leftover supply points are not recorded, and are lost.
  </p>

  <p>
    An investigator's supplies will determine the possible options available
    during gameplay and throughout the story of this campaign.
    <strong>Each supply has no effect on its own.</strong> Some card effects,
    story options, and resolutions may change or become available depending on
    the supplies carried by the investigator(s).
  </p>

  <h2 id="Surge">Surge</h2>

  <p>Surge is a keyword ability.</p>

  <p>
    After drawing and resolving an encounter with the surge keyword, an
    investigator must draw another card from the encounter deck.
  </p>

  <ul>
    <li>
      If a card with the surge keyword is drawn during setup, the surge keyword
      does resolve.
    </li>
  </ul>

  <h2 id="Swarming_X" style="color: var(--red)">
    Swarming X (added in <em>The Dream-Eaters</em>)
  </h2>

  <p>
    An enemy with the swarming X keyword is actually a pack of enemies operating
    in unison. After you put any enemy with the swarming X keyword into play,
    place the top X cards of your deck facedown underneath the enemy as swarm
    cards, without looking at them. The enemy they are underneath is called the
    "host enemy." Some scenario card effects may also instruct a player to add
    swarm cards to an enemy. This is done using the same process.
  </p>

  <ul>
    <li>
      If it is ever unclear which investigator should add swarm cards, the lead
      investigator does so.
    </li>

    <li>
      Each swarm card underneath the host enemy acts as a separate instance of
      that enemy for most purposes. Each swarm card has the same values and text
      as its host card.
      <i
        >(For example, if an investigator is engaged with a host enemy with 2
        swarm cards underneath it, that investigator is engaged with 3 enemies
        in total.)</i
      >
    </li>

    <li>
      Each swarm card attacks separately when enemies attack during the enemy
      phase. Once the host enemy and all of its swarm cards have attacked during
      this step, exhaust all of them.
    </li>

    <li>
      Each swarm card can be attacked or dealt damage separately, but the host
      enemy cannot be defeated while it still has swarm cards underneath it.
      When a swarm card is defeated, any excess damage may be dealt to another
      swarm card underneath the same host enemy or to the host enemy itself.
      <i
        >(For example, Tony Morgan uses a .41 Derringer to attack a Stealthy
        Zoog with 2 swarm cards. The attack deals 2 damage. The first point of
        damage defeats 1 of the 2 swarm cards, so the excess point of damage may
        be dealt to another swarm card, defeating it as well.)</i
      >
    </li>

    <li>
      Anytime a swarm card leaves play, place it on the bottom of its owner's
      deck. If you are unsure of the owner of the swarm card, you may look at it
      to determine its owner.
    </li>

    <li>
      The host enemy and all of its swarm cards move, engage, and exhaust as a
      single entity.
      <i
        >(For example, if a host enemy or any of its swarm cards are evaded, all
        of them exhaust and become disengaged.)</i
      >
    </li>
  </ul>

  <h2 id="Taking_Damage_Horror">Taking Damage/Horror</h2>

  <p>
    "Take X damage" is shorthand for "deal X damage to your investigator." "Take
    X horror" is shorthand for "deal X horror to your investigator."
  </p>

  <p>
    See "<a href="#Dealing_Damage_Horror">Dealing Damage/Horror</a>" on page 7.
  </p>

  <h2 id="Target">Target</h2>

  <p>
    The term "choose" indicates that one or more targets must be chosen in order
    for an ability to resolve. The player resolving the ability must choose a
    game element (usually a card) that meets the targeting requirements of the
    ability.
  </p>

  <ul>
    <li>
      If an ability requires the choosing of a target, and there is no valid
      target (or not enough valid targets), the ability cannot be initiated.
    </li>

    <li>
      If multiple targets are required to be chosen by the same player, they are
      chosen simultaneously.
    </li>

    <li>
      An effect that can choose "any number" of targets does not successfully
      resolve (and cannot change the game state) if zero of those targets are
      chosen.
    </li>

    <li>
      A card is not an eligible target for an ability if the resolution of that
      ability's effect could not change the target's state.
      <em
        >(For example, an exhausted enemy could not be chosen as the target of
        an effect that reads, "choose and exhaust an enemy.")</em
      >
    </li>
  </ul>

  <h2 id="Tarot_Slot" style="color: var(--red)">
    Tarot Slot (added in <em>The Circle Undone</em>)
  </h2>

  <p>
    Tarot slots are a new type of asset slot introduced in this expansion. The
    following symbol indicates that an asset fills a tarot slot:
  </p>

  <img
    alt="Tarot slot icon"
    src="/assets-v20260923/rules/overlay-tarot-slot.png"
    width="72"
    class="center"
    loading="lazy"
  />

  <p>
    As with other slots, tarot slots limit the number of asset cards of that
    slot type an investigator is permitted to have in play simultaneously.
  </p>

  <p>
    <b>By default, an investigator has only one tarot slot available.</b>
  </p>

  <p>All other rules governing slots apply to tarot slots, as usual.</p>

  <h2 id="Tekelili" style="color: var(--red)">
    Tekeli-li! (added in <em>Edge of the Earth</em>)
  </h2>

  <p>
    This campaign includes an encounter set of 16 weaknesses, each with the
    title "Tekeli-li!" These cards are shuffled together to form a special
    Tekeli-li deck during the setup of each scenario of this campaign.
  </p>

  <p>
    Like normal weaknesses, if one of these cards is added to an investigator’s
    deck, it becomes part of that deck and stays with that investigator from
    scenario to scenario. However, the resolution of each Tekeli-li! weakness
    instructs the investigator to return it to the Tekeli-li deck (removing it
    from their own deck). As a result, the number of cards in the Tekeli-li deck
    varies based on how many of these weaknesses are in each investigator’s
    deck.
  </p>

  <p>
    <i
      >Note: While all Tekeli-li! cards share the same title, they may have
      differing effects.</i
    >
  </p>

  <h2 id="Then">Then</h2>

  <p>
    If the effect of an ability includes the word "then," the text preceding the
    word "then" must be successfully resolved in full before the remainder of
    the effect described after the word "then" can be resolved.
  </p>

  <ul>
    <li>
      If the pre-then aspect of an effect does successfully resolve in full, the
      post-then aspect of the effect must also resolve.
    </li>

    <li>
      The post-then aspect of an effect has timing priority over all other
      indirect consequences of the resolution of the pre-then aspect.
      <em
        >(For example, if an effect reads: "Draw an encounter card. Then, take 1
        horror," and a player controls an ability that reads "After you draw an
        encounter card," the post-then "take 1 horror" aspect occurs before the
        "After you draw an encounter card" ability may initiate.)</em
      >
    </li>

    <li>
      If the pre-then aspect of an effect does not successfully resolve in full,
      the post-then aspect does not resolve.
    </li>
  </ul>

  <h2 id="Threat_Area">Threat Area</h2>

  <p>
    An investigator's threat area is a play area in which encounter cards
    currently engaged with and/or affecting an investigator are placed.
  </p>

  <ul>
    <li>
      The cards in an investigator's threat area are at the same location as the
      investigator.
    </li>
  </ul>

  <h2 id="Tokens">Tokens, Running out of</h2>

  <p>
    There is no limit to the number of tokens (of any type) which can be in the
    game area at a given time. If players run out of the provided tokens, other
    tokens, counters, or coins may be used to track the current game state.
  </p>

  <h2 id="Traits">Traits</h2>

  <p>
    Most cards have one or more traits listed at the top of the text box and
    printed in bold italics.
  </p>

  <ul>
    <li>
      Traits have no inherent effect on the game. Instead, some card abilities
      reference cards that possess specific traits.
    </li>
  </ul>

  <h2>Trauma</h2>

  <p>See "<a href="#Trauma">Campaign Play</a>" on page 5.</p>

  <h2 id="Treachery_Cards">Treachery Cards</h2>

  <p>
    Treachery cards represent curses, afflictions, madnesses, obstacles,
    disasters, or other unexpected occurrences an investigator may encounter
    throughout the course of a scenario.
  </p>

  <p>
    When a treachery card is drawn by an investigator, that investigator must
    resolve its effects. Then, place the card in its discard pile unless
    otherwise instructed by the ability.
  </p>

  <p>
    See "<a href="#Mythos_Phase">1.4 Each investigator draws 1 encounter card</a
    >" on page 24.
  </p>

  <h3 id="Treachery_and_Event_Subtitles" style="color: var(--blue)">
    Treachery and Event Subtitles (added in FAQ, section 'Card Ability
    Interpretation', point 2.21, updated FAQ v2.5)
  </h3>

  <p>
    Treachery and event cards do not have a header for their subtitle. If the
    title of a treachery or event card contains 1 or more words in parentheses,
    that is considered to be its subtitle. Other cards with the same title and a
    different subtitle are still considered to be copies of one another.
    <i
      >e.g. Restless Journey (Fallacy) and Restless Journey (Hardship) are both
      copies of Restless Journey.</i
    >
  </p>

  <p>
    Treachery cards do not have a header for their subtitle. If the title of a
    treachery card contains 1 or more words in parentheses, that is considered
    to be its subtitle. Other cards with the same title and a different subtitle
    are still considered to be copies of one another.
    <i
      >e.g. Restless Journey (Fallacy) and Restless Journey (Hardship) are both
      copies of Restless Journey.</i
    >
  </p>

  <h2 id="Triggered_Abilities">Triggered Abilities</h2>

  <p>
    A triggered ability is an ability that is optionally triggered by a player.
    A triggered ability can be identified by one of the following icons.
  </p>

  <ul>
    <li>The [action] icon indicates an action-costed triggered ability.</li>

    <li>
      The [free] icon indicates a free triggered ability that does not cost an
      action and may be used during any player window.
    </li>

    <li>
      The [reaction] indicates a reaction triggered ability that does not cost
      an action and may be used any time its triggering condition is met.
    </li>
  </ul>
  <p>
    See also: "<a href="#Abilities_Triggered">Ability</a>" on page 2, "<a
      href="#Appendix_I_Initiation_Sequence"
      >Appendix I: Initiation Sequence</a
    >" on page 22."
  </p>

  <p>
    An investigator is permitted to use triggered abilities ([free], [reaction],
    and [action] abilities) from the following sources:
  </p>

  <ul>
    <li>
      A card in play and under his or her control. This includes his or her
      investigator card.
    </li>

    <li>
      A scenario card that is in play and at the same location as the
      investigator. This includes the location itself, encounter cards placed at
      that location, and all encounter cards in the threat area of any
      investigator at that location.
    </li>

    <li>The current act or current agenda card.</li>

    <li>
      Any card that explicitly allows the investigator to activate its ability.
    </li>
  </ul>

  <h2 id="Triggering_Condition">Triggering Condition</h2>

  <p>
    A triggering condition indicates the timing point at which an ability may be
    triggered. Most triggering conditions use the word "when" or "after" to
    establish their relation to the specified timing point.
  </p>

  <ul>
    <li>
      Each eligible ability that triggers in reference to a specified timing
      point may be used once each time that timing point occurs.
    </li>

    <li>
      If multiple instances of the same ability are eligible to initiate, each
      instance may be used once.
    </li>
  </ul>

  <p>
    See also: "<a href="#Ability">Ability</a>" on page 2, "<a href="#After"
      >After</a
    >" on page 4, "<a href="#When">When</a>" on page 21.
  </p>

  <h2 id="Unique">Unique ([unique])</h2>

  <p>
    A card with the [unique] symbol before its card title is a unique card.
    There can be no more than one instance of each unique card, by title, in
    play at any given time.
  </p>

  <ul>
    <li>
      A player cannot bring into play a unique card if a copy of that card (by
      title) is already in play.
    </li>

    <li>
      If a unique encounter card that shares a title with a unique player card
      would enter play, discard the player card simultaneously as the encounter
      card enters play.
    </li>
  </ul>

  <h2 id="unless_all_clues_have_been_discovered" style="color: var(--blue)">
    "...Unless all of (location's) clues have been discovered." (added in FAQ,
    section 'Card Ability Interpretation', point 2.11)
  </h2>

  <p>
    Some locations have abilities that prevent you from entering or using a
    particular ability unless all of the clues have been discovered from a
    particular location; for example, the Engine Car. When interpreting such an
    ability, if the location is unrevealed (and therefore has no clues on it),
    this does not satisfy the ability; it must have been revealed at some point.
  </p>

  <h2>Upkeep Phase</h2>

  <p>See "<a href="#Upkeep_Phase">IV. Upkeep phase</a>" on page 25.</p>

  <h2 id="Uses">Uses (X "type")</h2>

  <p>Uses is a keyword ability.</p>

  <p>
    When a card bearing this keyword enters play, place a number of resource
    tokens equal to the value (X), from the token pool, on the card. The word
    following the value establishes and identifies the type of uses this card
    bears. The resource tokens placed on the card are considered uses of the
    established type, and are not considered resource tokens.
  </p>

  <ul>
    <li>
      Each card bearing this keyword also has an ability which references the
      type of use established by the keyword as a part of its cost. When such an
      ability spends a use, a token of that type must be removed from the card
      bearing the ability.
    </li>

    <li>
      Other cards may reference and interact with uses of a specified type,
      usually by adding uses of that type to a card, or using uses of that type
      for other purposes.
    </li>

    <li>
      A card cannot bear uses of a type other than that established by its own
      "Uses (X type)" keyword.
      <em>(For example, a card with "Uses (4 ammo)" cannot gain charges.)</em>
    </li>

    <li>
      Some cards with this keyword bear text that causes the card to be
      discarded if it has no uses remaining. If the card contains no such text,
      it remains in play even if out of uses.
    </li>
  </ul>

  <h2 id="Vengeance_X" style="color: var(--red)">
    Vengeance X (added in <em>The Forgotten Age</em>)
  </h2>

  <p>
    Some encounter cards are worth vengeance points. The text
    <strong>Vengeance X</strong> indicates that a card is worth X vengeance
    points.
  </p>

  <p>
    Like <strong>Victory X</strong>, when an encounter card with
    <strong>Vengeance X</strong> is overcome by the investigators, it is stored
    in the victory display until the end of the scenario. However, unlike
    victory points, vengeance represents the awareness and animosity of the
    Father of Serpents, and it is generally a good idea to avoid accruing
    vengeance points whenever possible.
  </p>

  <p>
    Vengeance points in the victory display have no impact upon the game unless
    specifically referenced by another encounter card.
  </p>

  <ul>
    <li>
      As an enemy with <strong>Vengeance X</strong> is defeated, place the card
      in the victory display instead of in the discard pile.
    </li>

    <li>
      At the end of a scenario, take each location with
      <strong>Vengeance X</strong> that is in play, revealed, and has no clues
      on it, and place it in the victory display.
    </li>

    <li>
      As a treachery card with
      <strong>Vengeance X</strong> completes its resolution, place it in the
      victory display instead of in the discard pile.
    </li>

    <li>
      Cards worth vengeance points are not also worth victory points unless the
      card has both
      <strong>Victory X</strong> and <strong>Vengeance X</strong>.
    </li>
  </ul>

  <h2 id="Victory_Display_Victory_Points">Victory Display, Victory Points</h2>

  <p>
    Some encounter cards are worth victory points. The text
    <strong>Victory X</strong> indicates that a card is worth X victory points.
  </p>

  <p>
    An encounter card worth victory points that is overcome by the investigators
    is stored in the victory display until the end of the scenario. The victory
    display is an out-of-play game area shared by all players. Upon completion
    of the scenario, the cards in the victory display provide experience, which
    can be used to upgrade an investigator's deck (see "<a href="#Campaign_Play"
      >Campaign Play</a
    >" on page 5).
  </p>

  <ul>
    <li>
      As a victory point enemy is defeated, place the card in the victory
      display instead of in the discard pile.
    </li>

    <li>
      At the end of a scenario, place each victory point location that is in
      play, revealed, and with no clues on it in the victory display.
    </li>

    <li>
      As a victory point treachery card completes its resolution, place it in
      the victory display instead of in the discard pile.
    </li>
  </ul>

  <img
    alt="Location of the Victory keyword"
    src="/assets-v20260923/rules/keyword_victory.png"
    class="center frame"
    loading="lazy"
    width="290"
  />

  <h2 id="Weakness">Weakness</h2>

  <p>
    Weakness is a card sub-type. These cards represent character flaws, curses,
    madnesses, injuries, tasks, enemies, or story elements that are part of an
    investigator's backstory, or that are acquired over the course of a
    campaign. Weakness cards are resolved differently depending upon their
    cardtype.
  </p>

  <ul>
    <li>
      When an investigator draws a weakness with an encounter cardtype
      <em>(for example, an enemy or a treachery weakness)</em>, resolve that
      card as if it were just drawn from the encounter deck.
    </li>

    <li>
      <span style="color: var(--blue)"
        >(Added in FAQ, section 'Game Play', point 1.12)</span
      >
      Weaknesses with an encounter cardtype (such as enemies or treacheries) are
      considered to be player cards while they are in their bearer’s deck, and
      are considered to be encounter cards while they are being resolved, and
      once they have entered play. Before a weakness with an encounter cardtype
      is resolved, it is still considered to be a player card.
    </li>

    <li>
      When an investigator draws a weakness with a player cardtype
      <em>(for example, an asset, an event, or a skill weakness)</em>, resolve
      any Revelation effects on the card, and add it to that investigator's
      hand. The card may then be used as any other player card of its type.
    </li>

    <li>
      If a weakness enters an investigator's hand in a manner that did not
      involve drawing the card, that investigator must resolve the card
      (including any Revelation abilities) as if he or she had just drawn it.
    </li>

    <li>
      The bearer of a weakness is the investigator who started the game with the
      weakness in his or her deck or play area.
    </li>

    <li>
      If a weakness is added to a player’s deck, hand, or threat area during the
      play of a scenario, that weakness remains a part of that investigator's
      deck for the rest of the campaign. (Unless it is removed from the campaign
      by a card ability or scenario resolution.)
    </li>

    <li>
      A player may not optionally choose to discard a weakness card from hand,
      unless a card explicitly specifies otherwise.
    </li>

    <li>
      Weaknesses with an encounter cardtype are, like other encounter cards, not
      controlled by any player. Weaknesses with a player cardtype are controlled
      by their bearer.
    </li>

    <li>
      Some card and game text references a "basic weakness." A basic weakness
      can be identified by the presence of the words "Basic Weakness" and the
      symbol indicated below.
    </li>
  </ul>

  <img
    alt="Location of the Weakness icon on a card"
    src="/assets-v20260923/rules/keyword_weakness.png"
    class="center frame"
    loading="lazy"
    width="262"
  />

  <h3
    id="Weakness_Events_And_Changing_The_Game_State"
    style="color: var(--blue)"
  >
    Weakness Events and "changing the game state" (added in FAQ, section 'Game
    Play', point 1.27)
  </h3>

  <p>
    Some weakness events such as Quantum Paradox do not change the game state in
    the traditional sense when played, but nevertheless provide negative effects
    if they are in your hand. These weakness events may still be played to avoid
    their negative effects.
  </p>

  <h3 id="Weakness_with_Player_Cardtypes" style="color: var(--blue)">
    Weaknesses with Player Cardtypes (added in FAQ, section 'Game Play', point
    1.35)
  </h3>

  <p>
    Unlike other player cards that are not affiliated with any class, weakness
    cards with player cardtypes (asset, event, or skill) are not considered to
    be Neutral cards. All weaknesses, regardless of their primary cardtype, do
    not interact with the player card class system or an investigator’s
    Deckbuilding Options.
  </p>

  <h2 id="When">When</h2>

  <p>
    The word "when" refers to the moment immediately after the specified timing
    point or triggering condition initiates, but before its impact upon the game
    state resolves. The resolution of a "when" ability interrupts the resolution
    of its timing point or triggering condition.
    <em
      >(For example, an ability that reads "When you draw an enemy card"
      initiates immediately after you draw the enemy card, but before resolving
      its revelation ability, spawning it, etc.)</em
    >
  </p>

  <p>
    See also: "<a href="#Ability">Ability</a>" on page 2, "<a
      href="#Priority_of_Simultaneous_Resolution"
      >Priority of Simultaneous Resolution</a
    >" on page 17.
  </p>

  <h2 id="Wild_Skill_Icons" style="color: var(--blue)">
    Wild Skill Icons (added in FAQ, section 'Game Play', point 1.9)
  </h2>

  <p>
    A Wild ([wild]) skill icon on a player card may be used to match any other
    skill icon for the purposes of both card abilities and counting how many
    matching icons are committed to a skill test. When using Wild icons for the
    purpose of resolving a card ability, a player must state which icon the Wild
    is matching at the time the card is used.
  </p>

  <p>
    Wild icons committed to a skill test are considered "matching" icons for the
    purposes of card abilities.
  </p>

  <h2 id="Winning_and_Losing">Winning and Losing</h2>

  <p>Each scenario has a number of different possible endings.</p>

  <p>
    The act deck represents the progress of the investigators through a
    scenario. Some instructions in the act deck (as well as on other encounter
    cardtypes) contain resolution points, in the format of:
    "<strong>(→R#)</strong>." The players' primary objective is to advance
    through the act deck until a (hopefully favorable) resolution point is
    reached. Should the act deck invoke a resolution, the players have completed
    the scenario (they may even have "won!"). Instructions for resolving the
    designated resolution are found in the "do not read until end of game"
    section of the campaign manual.
  </p>

  <p>
    The agenda deck represents the objectives and progress of the malicious
    forces pitted against the investigators in the scenario. Some instructions
    in the agenda deck (as well as on other encounter cardtypes) also contain
    resolution points, in the format of: "<strong>(→R#)</strong>." Should the
    agenda deck invoke a (usually darker) resolution, the players have lost the
    scenario. Instructions for resolving the designated resolution are found in
    the "do not read until end of game" section of the campaign guide.
  </p>

  <p>
    Should the scenario end with no resolution being reached
    <em
      >(for example, if all investigators have been eliminated or have
      resigned)</em
    >, instructions for resolving the scenario can be found in the "do not read
    until end of game" section of the campaign guide.
  </p>

  <ul>
    <li>
      If playing in a campaign, players will proceed to the next scenario in the
      campaign regardless of the outcome of the scenario. Even if players "lose"
      a scenario, they still continue their campaign (although with some
      negative consequences from their failure).
    </li>

    <li>
      When playing a standalone scenario, players either win or lose the
      scenario. They win if they complete a resolution on an act card. Any other
      resolution is considered a loss (see "<a href="#Standalone_Mode"
        >Standalone Mode</a
      >" on page 19).
    </li>
  </ul>

  <p>
    See "<a href="#Act_Deck_and_Agenda_Deck">Act Deck and Agenda Deck</a>" on
    page 3.
  </p>

  <h2 id="The_letter_X">The letter "X"</h2>

  <p>
    The value of the letter X is defined by a card ability or a granted player
    choice. If X is not defined, its value is equal to 0.
  </p>

  <ul>
    <li>
      For costs involving the letter X, the value of X is defined by card
      ability or player choice, after which the amount paid may be modified by
      effects without altering the value of X.
    </li>
  </ul>

  <h2 id="You_Your">You/Your</h2>

  <p>
    <span style="color: var(--blue)"
      >(Expanded in FAQ, section 'Card Ability Interpretation', point 2.1)</span
    >
    The following guidelines are used to interpret which investigator is
    referenced by the words "you" and "your."
  </p>

  <ul>
    <li>
      A <b>Revelation</b> ability that references "you/your" refers to the
      investigator who drew the card and is resolving the ability.
    </li>

    <li>
      When resolving a triggered ability ([fast], [reaction], or [action]
      ability), "you/your" refers to the investigator triggering the ability.
    </li>

    <li>
      If an ability contains a clause identifying whom it is targeting,
      "you/your" in that ability refers to those investigators.
      <i
        >For example, Stubborn Detective reads: "While Stubborn Detective is at
        your location..." This clause identifies "you" as any investigator at
        his location. Young Deep One reads: "After Young Deep One engages
        you..." This clause identifies "you" as any investigator who engages
        Young Deep One.</i
      >
    </li>

    <li>
      Any other instance of "you/your" that does not fall into the above
      categories refers to the investigator who controls the card, the
      investigator who has the card in his/her threat area, or who is currently
      interacting with the card.
    </li>
  </ul>

  <p>
    A card may have multiple different abilities in which "you/your" may be
    interpreted differently. “You/your” may refer to a different investigator in
    each of these abilities.
  </p>

  <p><i>For example: Dreams of R’lyeh reads:</i></p>

  <p>
    <i
      >"<b>Revelation</b> - Put Dreams of R’lyeh into play in your threat area.
      <br />You get –1 [willpower] and –1 sanity. <br />[action]: Test
      [willpower] (3). If you succeed, Discard Dreams of R’lyeh."</i
    >
  </p>

  <p>
    These three abilities reference "you/your" in different ways. For the
    <b>Revelation</b> ability, "your" refers to the investigator who drew Dreams
    of R’lyeh and is resolving its <b>Revelation</b>. For its constant ability,
    "you" refers to the investigator who has Dreams of R’lyeh in his or her
    threat area. For its [action] ability, "you" refers to the investigator who
    is performing the [action] ability.
  </p>

  <h3
    id="Interpreting_You_When_Taking_or_Being_Dealt_Damage"
    style="color: var(--blue)"
  >
    Interpreting "You" When Taking or Being Dealt Damage (added in FAQ, section
    'Card Ability Interpretation', point 2.12)
  </h3>

  <p>
    When an ability refers to "you" in response to taking damage/horror or being
    dealt damage/horror, it also includes any assets you control.
  </p>

  <p>
    <i
      >For example: The [reaction] ability on Survival Knife triggers "after an
      enemy attack deals damage to you during the enemy phase." This ability
      triggers even if the damage from that attack is assigned to one or more of
      your assets, and not your investigator card. However, if all of the damage
      from that attack is assigned to another investigator or their assets
      (through the use of a card effect that allows them to do so), then no
      damage has been dealt to you.</i
    >
  </p>

  <h1 id="Appendix_I_Initiation_Sequence">Appendix I: Initiation Sequence</h1>

  <p>
    When a player wishes to initiate a triggered ability or play a card, that
    player first declares his or her intent. There are two preliminary
    confirmations that must be made before the process of initiating an ability
    or playing a card may begin. These are:
  </p>

  <ul>
    <li>
      Check play restrictions: determine if the card can be played, or if the
      ability can be initiated, at this time. (This includes verifying that the
      resolution of the effect has the potential to change the game state.) If
      the play restrictions are not met, abort this process.
    </li>

    <li>
      Determine the cost (or costs, if multiple costs are required) to play the
      card or initiate the ability. If it is established that the cost (taking
      modifiers into account) can be paid, proceed with the remaining steps of
      this sequence.
    </li>
  </ul>

  <p>
    Once each of the above confirmations has been made, follow these steps, in
    order:
  </p>

  <ol>
    <li>Apply any modifiers to the cost(s).</li>

    <li>
      Pay the cost(s). If this step is reached and the cost(s) cannot be paid,
      abort this process without paying any costs.
      <ul>
        <li>
          Upon completion of this step, attacks of opportunity, if applicable,
          resolve.
        </li>
      </ul>
    </li>

    <li>
      The card commences being played, or the effects of the ability attempt to
      initiate.
    </li>

    <li>
      The effects of the ability (if not canceled in step 3) complete their
      initiation, and resolve. The card is regarded as played (and placed in
      play, or in its owner's discard pile if it's an event), and the ability is
      considered resolved simultaneously with the completion of this step.
      <ul>
        <li>
          If the ability being initiated is on an in-play card, the sequence
          does not stop from completing if that card leaves play during the
          sequence.
        </li>
      </ul>
    </li>
  </ol>

  <p>
    <span style="color: var(--blue)"
      >(Added in FAQ, section 'Frequently Asked Questions')</span
    >
    <i
      >Q: If I initiate a skill test at a given location, then trigger an effect
      that causes me to move before that test finishes resolving, what happens
      to that skill test?</i
    >
    A: Once you initiate a skill test or ability, you'll resolve that test or
    ability as completely as possible, regardless of your location (unless
    another effect cancels or interrupts it). For example, if you attacked an
    elusive enemy with One-Two Punch, you could attack that same enemy with the
    card's second fight, even though it has moved to a connecting location.
  </p>

  <h1 id="Appendix_II_Timing_and_Gameplay">Appendix II: Timing and Gameplay</h1>

  <p>
    The "<a href="#Phase_Sequence_Timing">Phase Sequence timing chart</a>"
    depicts the phases and steps of a game round. Each time an investigator
    makes a skill test, use the skill test timing detailed in the "<a
      href="#Skill_Test_Timing"
      >Skill Test timing chart</a
    >."
  </p>

  <p>
    Numbered items presented in the grey boxes are known as framework events.
    Framework events are mandatory occurrences dictated by the structure of the
    game.
  </p>

  <p>
    The red boxes are player windows. Players may use [free] triggered abilities
    in these windows.
  </p>

  <p>
    The specific details for each of these steps are explained starting on page
    24.
  </p>

  <h2 id="Phase_Sequence_Timing">Phase Sequence timing chart</h2>

  <table class="chart">
    <tr>
      <th>I. Mythos phase (skip during first round of game)</th>
    </tr>
    <tr>
      <td class="green">1.1 Round begins. Mythos phase begins.</td>
    </tr>
    <tr>
      <td class="green">1.2 Place 1 doom on the current agenda.</td>
    </tr>
    <tr>
      <td class="green">1.3 Check doom threshold.</td>
    </tr>
    <tr>
      <td class="green">1.4 Each investigator draws 1 encounter card.</td>
    </tr>
    <tr>
      <td class="red">[free] PLAYER WINDOW</td>
    </tr>
    <tr>
      <td class="green">1.5 Mythos phase ends.</td>
    </tr>
    <tr>
      <td class="grey">Proceed to Investigation Phase.</td>
    </tr>
    <tr>
      <td></td>
    </tr>
    <tr>
      <th>II. Investigation phase</th>
    </tr>
    <tr>
      <td class="green">2.1 Investigation phase begins.</td>
    </tr>
    <tr>
      <td class="red">[free] PLAYER WINDOW</td>
    </tr>
    <tr>
      <td class="green">2.2 Next investigator's turn begins.</td>
    </tr>
    <tr>
      <td class="red">[free] PLAYER WINDOW</td>
    </tr>
    <tr>
      <td class="green">
        2.2.1 Active investigator may take an action, if able. If an action was
        taken, return to previous player window. If no action was taken, proceed
        to 2.2.2.
      </td>
    </tr>
    <tr>
      <td class="green">
        2.2.2 Investigator's turn ends. If an investigator has not yet taken a
        turn this phase, return to 2.2. If each investigator has taken a turn
        this phase, proceed to 2.3.
      </td>
    </tr>
    <tr>
      <td class="green">2.3 Investigation phase ends.</td>
    </tr>
    <tr>
      <td class="grey">Proceed to Enemy Phase.</td>
    </tr>
    <tr>
      <td></td>
    </tr>
    <tr>
      <th>III. Enemy phase</th>
    </tr>
    <tr>
      <td class="green">3.1 Enemy phase begins.</td>
    </tr>
    <tr>
      <td class="green">3.2 Hunter enemies move.</td>
    </tr>
    <tr>
      <td class="red">[free] PLAYER WINDOW</td>
    </tr>
    <tr>
      <td class="green">
        3.3 Next investigator resolves engaged enemy attacks. If an investigator
        has not yet resolved enemy attacks this phase, return to previous player
        window. After final investigator resolves engaged enemy attacks, proceed
        to next player window.
      </td>
    </tr>
    <tr>
      <td class="red">[free] PLAYER WINDOW</td>
    </tr>
    <tr>
      <td class="green">3.4 Enemy phase ends.</td>
    </tr>
    <tr>
      <td class="grey">Proceed to Upkeep Phase.</td>
    </tr>
    <tr>
      <td></td>
    </tr>
    <tr>
      <th>IV. Upkeep phase</th>
    </tr>
    <tr>
      <td class="green">4.1 Upkeep phase begins.</td>
    </tr>
    <tr>
      <td class="red">[free] PLAYER WINDOW</td>
    </tr>
    <tr>
      <td class="green">4.2 Reset actions.</td>
    </tr>
    <tr>
      <td class="green">4.3 Ready each exhausted card.</td>
    </tr>
    <tr>
      <td class="green">
        4.4 Each investigator draws 1 card and gains 1 resource.
      </td>
    </tr>
    <tr>
      <td class="green">4.5 Each investigator checks hand size.</td>
    </tr>
    <tr>
      <td class="green">4.6 Upkeep phase ends. Round ends.</td>
    </tr>
    <tr>
      <td class="grey">Proceed to Mythos Phase of next game round.</td>
    </tr>
  </table>

  <h2 id="Framework_Event_Details">Framework Event Details</h2>

  <p>
    This section provides a detailed explanation of how to handle each framework
    event step presented on the game's flow chart, in the order that the
    framework events occur throughout the round.
  </p>

  <h3 id="Mythos_Phase">I. Mythos phase</h3>

  <p>
    <strong>During the first round of the game, skip the mythos phase.</strong>
  </p>

  <h3>1.1 Mythos phase begins.</h3>

  <p>
    This step formalizes the beginning of the mythos phase. As this is the first
    framework event of the round, it also formalizes the beginning of a new game
    round.
  </p>

  <p>
    The beginning of a phase is an important game milestone that may be
    referenced in card text, either as a point at which an ability may or must
    resolve, or as a point at which a delayed effect resolves or a lasting
    effect expires.
  </p>

  <h3>1.2 Place 1 doom on the current agenda.</h3>

  <p>
    Take 1 doom from the token pool, and place it on the current agenda card.
  </p>

  <h3>1.3 Check doom threshold.</h3>

  <p>
    Compare the total number of doom in play (on the current agenda and on each
    other card in play) with the doom threshold of the current agenda. If the
    value of doom in play equals or exceeds the doom threshold of the current
    agenda, the agenda deck advances.
  </p>

  <p>
    When the agenda deck advances, remove all doom from play, returning them to
    the token pool. Turn the current agenda over, read the story text, and
    follow any advancement instructions. Unless otherwise directed by the
    advancement instructions, the front side of the next sequential agenda card
    becomes the new current agenda, and the advancing agenda is simultaneously
    removed from the game.
  </p>

  <p>
    <em
      >Note: Unless a card otherwise specifies that it can advance the agenda,
      this is the only time at which the agenda can advance.</em
    >
  </p>

  <h3>1.4 Each investigator draws 1 encounter card.</h3>

  <p>
    In player order, each investigator draws the top card of the encounter deck,
    resolves any revelation abilities on the card, and follows the instructions
    below based on the card's type.
  </p>

  <p>
    Each time an investigator draws an encounter card, perform the following
    steps, in order:
  </p>

  <ol>
    <li>Draw the card from the encounter deck.</li>

    <li>
      Check for the peril keyword on the drawn card. (If the card has the peril
      keyword, the investigator who drew the card cannot confer with the other
      players. Those other players cannot play cards, trigger abilities, or
      commit cards to that investigator's skill test(s) while the peril
      encounter is resolving.)
    </li>

    <li>Resolve the revelation ability on the drawn card.</li>

    <li>
      If the card is an <strong>enemy</strong>, spawn it following any spawn
      instruction the card bears. (A spawn instruction is any text bearing a
      "spawn" precursor.) If the encountered enemy has no spawn instruction, the
      enemy spawns engaged with the investigator encountering the card and is
      placed in that investigator's threat area.<br />
      <br />
      If the card is a <strong>treachery</strong>, place the card in the
      encounter discard pile unless otherwise instructed by the ability.
    </li>

    <li>
      If the drawn card has the surge keyword, the investigator must draw
      another card. Restart this process at step 1.
    </li>
  </ol>

  <h3>1.5 Mythos phase ends.</h3>

  <p>This step formalizes the end of the mythos phase.</p>

  <p>
    The end of a phase is an important game milestone that may be referenced in
    card text, either as a point at which an ability may or must resolve, or as
    a point at which a delayed effect resolves or a lasting effect expires.
  </p>

  <h3 id="Investigation_Phase">II. Investigation phase</h3>

  <h3>2.1 Investigation phase begins.</h3>

  <p>This step formalizes the beginning of the investigation phase.</p>

  <h3>2.2 Next investigator's turn begins.</h3>

  <p>
    The investigators may take their turns in any order. The investigators
    choose among themselves who (among the investigators) will take this turn,
    and making this choice begins that investigator's turn. The investigator
    taking his or her turn is known as the "active investigator."
  </p>

  <p>
    Once an investigator begins a turn, that investigator must complete the turn
    before another investigator may take his or her turn. Each investigator
    takes one turn each round.
  </p>

  <h3>2.2.1 Investigator takes an action, if able.</h3>

  <p>
    During his or her turn, an investigator is permitted to take three actions.
    An action can be used to do one of the following:
  </p>

  <ul>
    <li><strong>Investigate</strong> your location.</li>

    <li><strong>Move</strong> to a connecting location.</li>

    <li><strong>Draw</strong> (draw 1 card).</li>

    <li><strong>Resource</strong> (gain 1 resource).</li>

    <li><strong>Play</strong> an asset or event card from your hand.</li>

    <li>
      <strong>Activate</strong> an [action]-costed ability on an in-play card
      you control, an in-play encounter card at your location, a card in your
      threat area, the current act card, or the current agenda card.
    </li>

    <li><strong>Fight</strong> an enemy at your location.</li>

    <li><strong>Engage</strong> an enemy at your location.</li>

    <li>Attempt to <strong>evade</strong> an enemy engaged with you.</li>
  </ul>

  <p>
    The three actions an investigator performs during his or her turn may be any
    of the above, in any order, and may even be the same action three times in a
    row.
  </p>

  <p>
    <strong>Important:</strong> When an investigator is engaged with one or more
    enemies and takes an action other than to <strong>fight</strong>, to
    <strong>evade</strong>, or to activate a <strong>parley</strong> or
    <strong>resign</strong> ability, each of those enemies makes an attack of
    opportunity against the investigator, in the order of the investigator's
    choosing.
  </p>

  <p>
    After an investigator takes an action, return to the previous player window.
    An investigator may end his or her turn early if there are no other actions
    he or she wishes to perform. If the investigator does not or cannot take an
    action, proceed to 2.2.2.
  </p>

  <h3>2.2.2 Investigator's turn ends.</h3>

  <p>
    Flip the active investigator's mini card to its colorless side to show that
    the investigator's turn has ended. If there is an investigator who has not
    yet taken a turn this round, return to 2.2. If each investigator has taken a
    turn this round, proceed to 2.3.
  </p>

  <h3>2.3 Investigation phase ends.</h3>

  <p>This step formalizes the end of the investigation phase.</p>

  <h3 id="Enemy_Phase">III. Enemy phase</h3>

  <h3>3.1 Enemy phase begins.</h3>

  <p>This step formalizes the beginning of the enemy phase.</p>

  <h3>3.2 Hunter enemies move.</h3>

  <p>
    Resolve the hunter keyword for each ready, unengaged enemy that has the
    hunter keyword (see "<a href="#Hunter">Hunter</a>" on page 12).
  </p>

  <h3>3.3 Next investigator resolves engaged enemy attacks.</h3>

  <p>
    Resolve engaged enemy attacks in player order, with each player resolving
    all of his or her engaged enemies before advancing to the next player.
  </p>

  <p>
    Each ready, engaged enemy makes an attack against the investigator to which
    it is engaged. When an enemy attacks, deal its attack (both its damage and
    its horror, simultaneously) to the engaged investigator. Upon completion of
    dealing the attack (and all abilities triggered by the attack), exhaust the
    enemy. If an investigator is engaged with multiple enemies, resolve their
    attacks in the order of the attacked investigator's choosing.
  </p>

  <p>
    After an investigator has resolved the attacks of the enemies he or she is
    engaged with, return to the previous player window. After the final
    investigator resolves enemy attacks, proceed to the next player window.
  </p>

  <h3>3.4 Enemy phase ends.</h3>

  <p>This step formalizes the end of the enemy phase.</p>

  <h3 id="Upkeep_Phase">IV. Upkeep phase</h3>

  <h3>4.1 Upkeep phase begins.</h3>

  <p>This step formalizes the beginning of the upkeep phase.</p>

  <h3>4.2 Reset actions.</h3>

  <p>
    Flip each investigator's mini card back to its colored side. This indicates
    that the investigator's actions have been reset for his or her next turn.
  </p>

  <h3>4.3 Ready exhausted cards.</h3>

  <p>Simultaneously ready each exhausted card.</p>

  <h3>4.4 Each investigator draws 1 card and gains 1 resource.</h3>

  <p>
    In player order, each investigator draws 1 card. Once those cards have been
    drawn, each investigator gains 1 resource.
  </p>

  <h3>4.5 Each investigator checks hand size.</h3>

  <p>
    In player order, each investigator with more than 8 cards in hand chooses
    and discards cards from his or her hand until he or she has 8 cards
    remaining in hand.
  </p>

  <h3>4.6 Upkeep phase ends.</h3>

  <p>This step formalizes the end of the upkeep phase.</p>

  <p>
    As the upkeep phase is the final phase in the round, this step also
    formalizes the end of the round. Any active "until the end of the round"
    lasting effects expire at this time.
  </p>

  <p>
    After this step is complete, play proceeds to the beginning of the mythos
    phase of the next game round.
  </p>

  <h2 id="Skill_Test_Timing">Skill Test Timing</h2>

  <table class="chart">
    <tr>
      <th>Skill Test Timing</th>
    </tr>
    <tr>
      <td class="green">
        ST.1 Determine skill of test. Skill test of that type begins.
      </td>
    </tr>
    <tr>
      <td class="red">[free] PLAYER WINDOW</td>
    </tr>
    <tr>
      <td class="green">ST.2 Commit cards from hand to skill test.</td>
    </tr>
    <tr>
      <td class="red">[free] PLAYER WINDOW</td>
    </tr>
    <tr>
      <td class="green">ST.3 Reveal chaos token.</td>
    </tr>
    <tr>
      <td class="green">ST.4 Resolve chaos symbol effect(s).</td>
    </tr>
    <tr>
      <td class="green">ST.5 Determine investigator's modified skill value.</td>
    </tr>
    <tr>
      <td class="green">ST.6 Determine success/failure of skill test.</td>
    </tr>
    <tr>
      <td class="green">ST.7 Apply skill test results.</td>
    </tr>
    <tr>
      <td class="green">ST.8 Skill test ends.</td>
    </tr>
  </table>

  <h3>ST.1 Determine skill type of test. Skill test of that type begins.</h3>

  <p>
    This step formalizes the beginning of a skill test. There are four types of
    skill tests: willpower tests, intellect tests, combat tests, and agility
    tests. The card ability or game rule determines which type of test is
    necessary, and thereby a test of that type begins.
  </p>

  <h3>ST.2 Commit cards from hand to skill test.</h3>

  <p>
    The investigator performing the skill test may commit any number of cards
    with an appropriate skill icon from his or her hand to this test.
  </p>

  <p>
    Each other investigator at the same location as the investigator performing
    the skill test may commit one card with an appropriate skill icon to this
    test.
  </p>

  <p>
    An appropriate skill icon is either one that matches the skill being tested,
    or a wild icon. The investigator performing this test gets +1 to his or her
    skill value during this test for each appropriate skill icon that is
    committed to this test.
  </p>

  <p>
    Cards that lack an appropriate skill icon may not be committed to a skill
    test. Do not pay a card's resource cost when committing it.
  </p>

  <h3>ST.3 Reveal chaos token.</h3>

  <p>
    The investigator performing the skill test reveals one chaos token at random
    from the chaos bag.
  </p>

  <p>
    See also "<a href="#Resolving_Multiple_Revealed_Chaos_Tokens"
      >Resolving Multiple Revealed Chaos Tokens</a
    >" above.
  </p>

  <h3>ST.4 Apply chaos symbol effect(s).</h3>

  <p>
    Apply any effects initiated by the symbol on the revealed chaos token. Each
    of the following symbols indicates that an ability on the scenario reference
    card must initiate: [skull], [cultist], [tablet], or [elder_thing].
  </p>

  <p>
    The [elder_sign] symbol indicates that the [elder_sign] ability on the
    investigator card belonging to the player performing the test must initiate.
  </p>

  <p>
    If none of the above symbols are revealed, or if the icon has no
    corresponding ability, this step completes with no effect.
  </p>

  <h3>ST.5 Determine investigator's modified skill value.</h3>

  <p>
    Start with the base skill (of the skill that matches the type of test that
    is resolving) of the investigator performing this test, and apply all active
    modifiers, including the appropriate icons that have been committed to this
    test, effects of the chaos token(s) revealed, and all active card abilities
    that are modifying the investigator's skill value.
  </p>

  <h3>ST.6 Determine success/failure of skill test.</h3>

  <p>
    Compare the investigator's modified skill value to the difficulty of the
    skill test.
  </p>

  <p>
    If the investigator's skill value equals or exceeds the difficulty for this
    test (as indicated by the card or game mechanic invoking the test), the
    investigator succeeds at the test.
  </p>

  <ul>
    <li>
      If an investigator automatically succeeds at a test via a card ability,
      the total difficulty of that test is considered 0.
    </li>
  </ul>

  <p>
    If the investigator's skill value is less than the difficulty for this test,
    the investigator fails at the test.
  </p>

  <ul>
    <li>
      If an investigator automatically fails at a test via a card ability or
      revealing the [auto_fail] symbol, his or her total skill value for that
      test is considered 0.
    </li>
  </ul>

  <p>
    See also "<a href="#Automatic_Failure_Success"
      >Automatic Failure/Success - expanded</a
    >" above.
  </p>

  <h3>ST.7 Apply skill test results.</h3>

  <p>
    The card ability or game rule that initiated a skill test usually indicates
    the consequences of success and/or failure for that test. (Additionally,
    some other card abilities may contribute additional consequences, or modify
    existing consequences, at this time.) Resolve the appropriate consequences
    (based on the success or failure established during step ST.6) at this time.
  </p>

  <p>
    If there are multiple results to be applied during this step, the
    investigator performing the test applies those results in the order of his
    or her choice.
  </p>

  <h3>ST.8 Skill test ends.</h3>

  <p>
    This step formalizes the end of this skill test. Discard all cards that were
    committed to this skill test, and return all revealed chaos tokens to the
    chaos bag.
  </p>

  <h1 id="Appendix_III_Setting_Up_The_Game">
    Appendix III: Setting Up The Game
  </h1>

  <p>To setup a game, perform the following steps in order:</p>

  <ol>
    <li>
      <strong> Choose investigators.</strong> Each player chooses a different
      investigator, and places that investigator's card in his or her play area.
    </li>

    <li>
      <strong> Take trauma damage/horror.</strong> In campaign play, each player
      places damage equal to his or her physical trauma, and horror equal to his
      or her mental trauma, on his or her investigator card.
    </li>

    <li>
      <strong>
        Choose one of those investigators to be the lead investigator for this
        game.</strong
      >
    </li>

    <li>
      <strong> Assemble and shuffle the investigator decks.</strong>
    </li>

    <li>
      <strong> Assemble token pool.</strong> Place the damage, horror,
      clue/doom, and resource tokens within easy reach of all players.
    </li>

    <li>
      <strong> Assemble the chaos bag.</strong> Place the chaos tokens indicated
      by the campaign setup instructions into the bag, and return the other
      chaos tokens to the game box.
      <ul>
        <li>
          In campaign mode, use the chaos bag as it was composed upon completion
          of the previous scenario.
        </li>
      </ul>
    </li>

    <li>
      <strong> Collect starting resources.</strong> Each investigator gains 5
      resources from the token pool.
    </li>

    <li>
      <strong> Draw opening hands.</strong> Each player draws 5 cards. Each
      player, in player order, may mulligan once at this time.
      <ul>
        <li>
          Each weakness card drawn during this step is ignored, set aside
          (without resolving it), and replaced by drawing another card from the
          deck. Upon completion of this step, shuffle each of these weakness
          cards back into its owner's deck.
        </li>
      </ul>
    </li>

    <li>
      <strong> Read the scenario introduction in the campaign guide.</strong>
    </li>

    <li>
      <strong>
        Perform the scenario setup instructions indicated by the campaign
        guide.</strong
      >
      This includes gathering the encounter sets listed in the setup
      instructions in the campaign guide, placing locations, placing
      investigator mini cards at the location each investigator begins play at,
      setting aside any listed cards, and shuffling remaining encounter cards
      together to form the encounter deck.
    </li>

    <li>
      <strong> Set agenda deck.</strong> Assemble the agenda deck in sequential
      order, with the art side faceup, so that "agenda 1a" is on top. Read the
      story text on agenda 1a.
    </li>

    <li>
      <strong> Set act deck.</strong> Assemble the act deck in sequential order,
      with the art side faceup, so that "act 1a" is on top. Read the story text
      on act 1a.
    </li>

    <li>
      <strong>
        Place the scenario reference card next to the agenda deck.</strong
      >
    </li>
  </ol>

  <p>
    There are no action windows during setup. Players may only trigger player
    card abilities or play cards from hand during setup if the card or ability's
    specific triggering condition is met.
  </p>

  <h1 id="Appendix_IV_Card_Anatomy">Appendix IV: Card Anatomy</h1>

  <p>
    This section presents a detailed anatomy of each cardtype. Pages 28-29
    detail scenario cards, and pages 30-31 detail investigator/player cards.
  </p>

  <p>
    Scenario cards include act cards, agenda cards, location cards, treachery
    cards, enemy cards, and scenario reference cards.
  </p>

  <p>
    Player cards include investigator cards, investigator mini cards, asset
    cards, event cards, and skill cards.
  </p>

  <h2 id="Scenario_Card_Anatomy_Key">Scenario Card Anatomy Key</h2>

  <ol>
    <li>
      <strong>Encounter Set Symbol:</strong> Indicates which encounter set the
      card belongs to.
    </li>

    <li>
      <strong>Cardtype:</strong> Indicates how a card behaves or may be used in
      the game.
    </li>

    <li><strong>Title:</strong> The name of this card.</li>

    <li>
      <strong>Traits:</strong> Flavorful attributes that may be referenced by
      card abilities.
    </li>

    <li>
      <strong>Ability:</strong> This card's specialized means of interacting
      with the game.
    </li>

    <li>
      <strong>Enemy Fight Value:</strong> Determines the difficulty of a skill
      test to attack this enemy.
    </li>

    <li>
      <strong>Enemy Health Value:</strong> This enemy's health value, which
      measures its physical durability.
    </li>

    <li>
      <strong>Enemy Evade Value:</strong> Determines the difficulty of a skill
      test to evade this enemy.
    </li>

    <li>
      <strong>Damage:</strong> The amount of damage this enemy deals with its
      attack.
    </li>

    <li>
      <strong>Horror:</strong> The amount of horror this enemy deals with its
      attack.
    </li>

    <li>
      <strong>Shroud:</strong> Determines the difficulty of a skill test to
      investigate this location.
    </li>

    <li>
      <strong>Clue Value:</strong> The number of clues placed on this location
      when it is first revealed.
    </li>

    <li>
      <strong>Connection Symbols:</strong> Indicate the movement connections
      between locations.
    </li>

    <li>
      <strong>Act/Agenda Sequence:</strong> Used to order the act/agenda deck.
    </li>

    <li>
      <strong>Clue Threshold:</strong> The number of clues that must be spent to
      advance this act.
    </li>

    <li>
      <strong>Doom Threshold:</strong> The amount of doom in play required to
      advance this agenda.
    </li>

    <li>
      <strong>Product Set Information:</strong> Indicates this card's product of
      origin.
    </li>

    <li>
      <strong>Encounter Set Number:</strong> Indicates the number of cards
      within an encounter set, and this card's place within that set.
    </li>
  </ol>

  <img
    class="frame"
    src="/assets-v20260923/rules/anatomy_encounter.jpg"
    loading="lazy"
    alt="Scenario Card Anatomy Examples"
  />

  <h2 id="Player_Card_Anatomy_Key">Player Card Anatomy Key</h2>

  <ol>
    <li><strong>Cost:</strong> The resource cost to play a card.</li>

    <li>
      <strong>Level:</strong> The amount of experience required to purchase this
      card for a deck.
    </li>

    <li>
      <strong>Cardtype:</strong> Indicates how a card behaves or may be used in
      the game.
    </li>

    <li>
      <strong>Class Symbol:</strong> The class to which a card belongs. Neutral
      cards have no class symbol.
    </li>

    <li><strong>Title:</strong> The name of this card.</li>

    <li><strong>Subtitle:</strong> A secondary identifier for a card.</li>

    <li>
      <strong>Skills:</strong> This investigator's value for his or her skills,
      in order: Willpower ([willpower]), Intellect ([intellect]), Combat
      ([combat]), Agility ([agility]).
    </li>

    <li>
      <strong>Traits:</strong> Flavorful attributes that may be referenced by
      card abilities.
    </li>

    <li>
      <strong>Ability:</strong> This card's specialized means of interacting
      with the game.
    </li>

    <li>
      <strong>Elder Sign Ability:</strong> This investigator's ability for the
      Elder Sign token.
    </li>

    <li>
      <strong>Health:</strong> This card's health value, which measures its
      physical durability.
    </li>

    <li>
      <strong>Sanity:</strong> This card's sanity value, which measures its
      mental durability.
    </li>

    <li>
      <strong>Skill Test Icons:</strong> Modify skill value while committed to a
      skill test.
    </li>

    <li>
      <strong>Product Set Information:</strong> Indicates this card's product of
      origin.
    </li>
  </ol>

  <img
    class="frame"
    src="/assets-v20260923/rules/anatomy_player.jpg"
    loading="lazy"
    alt="Player Card Anatomy Examples"
  />
</div>
`,D=e();function O({renderContent:e,renderToc:t,searchEnabled:n=!0}){let{t:i}=r(),o=C(),[c,l]=(0,E.useState)(``),[u,p]=(0,E.useState)(!1),h=(0,E.useDeferredValue)(c),g=(0,E.useRef)(null),_=(0,E.useRef)(null),y=(0,E.useRef)(null),b=(0,E.useCallback)(()=>{p(e=>!e)},[]),x=(0,E.useCallback)(()=>{p(!1)},[]);return(0,E.useEffect)(()=>{let e=()=>{p(!1),setTimeout(()=>{let e=window.location.hash.slice(1),t=document.getElementById(e);t&&t.scrollIntoView({behavior:`auto`})})};return window.addEventListener(`hashchange`,e),()=>{window.removeEventListener(`hashchange`,e)}},[]),f(`/`,()=>{n&&_.current?.focus()}),j(y,g,x,u),(0,D.jsxs)(`div`,{className:`container`,children:[(0,D.jsxs)(d,{className:`toc-toggle`,onClick:b,ref:g,size:`xl`,variant:`primary`,children:[u?(0,D.jsx)(te,{}):(0,D.jsx)(ie,{}),` `,i(`rules.toc`)]}),(0,D.jsxs)(`div`,{className:s(`toc-container`,u&&`open`),ref:y,children:[(0,D.jsx)(`h1`,{className:`toc-title`,children:i(`rules.toc`)}),n&&(0,D.jsx)(`div`,{className:`toc-search`,children:(0,D.jsx)(v,{className:`rules-search`,id:`rules-search`,onValueChange:l,placeholder:i(`rules.search_placeholder`),ref:_,value:c})}),(0,D.jsxs)(`nav`,{className:`toc-nav`,children:[(0,D.jsxs)(d,{size:`sm`,onClick:o,children:[(0,D.jsx)(m,{}),i(`common.back`)]}),(0,D.jsxs)(d,{size:`sm`,as:`a`,href:`#`,children:[(0,D.jsx)(ee,{}),i(`rules.back_to_top`)]})]}),(0,D.jsx)(a,{className:`toc-inner`,padded:!0,children:(0,D.jsx)(k,{renderToc:t,search:h})})]}),(0,D.jsx)(`div`,{className:`rules-container`,children:(0,D.jsx)(A,{renderContent:e,search:h})})]})}var k=(0,E.memo)(function({renderToc:e,search:t}){return e(t)}),A=(0,E.memo)(function({renderContent:e,search:t}){return e(t)});function j(e,t,n,r){(0,E.useEffect)(()=>{function i(i){r&&e.current&&!e.current.contains(i.target)&&i.target!==t.current&&!t.current?.contains(i.target)&&(i.preventDefault(),n())}return document.addEventListener(`pointerdown`,i),()=>{document.removeEventListener(`pointerdown`,i)}},[r,n,e,t])}function M(){let[e,t]=ae.split(`<!-- BEGIN RULES -->`);return(0,D.jsx)(O,{renderContent:()=>(0,D.jsx)(N,{rules:t}),renderToc:()=>(0,D.jsx)(`div`,{dangerouslySetInnerHTML:{__html:i(e,{newLines:`skip`})}}),searchEnabled:!1})}function N(e){let{rules:t}=e;return(0,D.jsx)(`div`,{dangerouslySetInnerHTML:{__html:i(t,{newLines:`skip`})}})}var P=`/assets-v20260923/grimoire`;function F(e){return I(i(S(e),{newLines:`skip`}))}function I(e){let t=new DOMParser().parseFromString(e,`text/html`);for(let e of t.querySelectorAll(`img`)){let t=e.getAttribute(`src`);!t||!R(t)||(e.setAttribute(`src`,L(t)),e.setAttribute(`decoding`,`async`),e.setAttribute(`loading`,`lazy`))}return t.body.innerHTML}function L(e){return`${P}/${z(e)}`}function R(e){return!/^(?:[a-z]+:|\/\/|\/|#)/i.test(e.trim())}function z(e){return e.trim().replaceAll(`\\`,`/`).split(`/`).filter(e=>e&&e!==`.`&&e!==`..`).map(e=>encodeURIComponent(e)).join(`/`)}function B(e,t){return{entriesBySectionId:H(e),entrySearchTextById:W(e),sectionSearchTextById:G(t)}}function V(e,t,n,r){let i=u(r);if(!i||r.length<=2)return{entryIds:new Set(e.map(e=>e.id)),sectionIds:new Set(t.map(e=>e.id))};let a={entryIds:new Set,sectionIds:new Set};for(let t of e)i.test(n.entrySearchTextById.get(t.id)??``)&&(a.entryIds.add(t.id),a.sectionIds.add(t.section));for(let e of t)if(i.test(n.sectionSearchTextById.get(e.id)??``)){a.sectionIds.add(e.id);for(let t of n.entriesBySectionId.get(e.id)??[])a.entryIds.add(t.id)}return a}function H(e){let t=new Map;for(let n of e.toSorted((e,t)=>U(e.id,t.id))){let e=t.get(n.section)??[];e.push(n),t.set(n.section,e)}return t}function U(e,t){let n=e.split(`.`).map(e=>Number.parseInt(e,10)),r=t.split(`.`).map(e=>Number.parseInt(e,10)),i=Math.max(n.length,r.length);for(let a=0;a<i;a+=1){let i=n[a],o=r[a];if(Number.isNaN(i)||Number.isNaN(o))return e.localeCompare(t,void 0,{sensitivity:`base`});if(i!==o)return i-o}return e.localeCompare(t,void 0,{sensitivity:`base`})}function W(e){return new Map(e.map(e=>[e.id,K(e.title,e.text)]))}function G(e){return new Map(e.map(e=>[e.id,K(e.title,e.text)]))}function K(e,t){return c([e,t].filter(Boolean).join(` `))}function q(){let{t:e}=r(),t=p(),{cardLinkTooltip:n,referenceProps:i}=x();(0,E.useEffect)(()=>{if(t.isPending||t.error||!window.location.hash)return;let e=window.location.hash.slice(1);e.startsWith(`grimoire-`)&&requestAnimationFrame(()=>{let t=document.getElementById(e);t&&t.scrollIntoView({behavior:`auto`})})},[t.error,t.isPending]);let a=(0,E.useMemo)(()=>t.data?.entries??[],[t.data]),o=(0,E.useMemo)(()=>t.data?.sections??[],[t.data]),s=(0,E.useMemo)(()=>B(a,o),[a,o]),c=(0,E.useMemo)(()=>X(a,o),[a,o]),u=e=>V(a,o,s,e);return(0,D.jsx)(O,{renderContent:r=>{let a=u(r),f=!!a.sectionIds.size;return(0,D.jsxs)(`div`,{className:`grimoire longform`,...i,children:[(0,D.jsxs)(`div`,{className:`grimoire-header`,children:[(0,D.jsx)(`h1`,{children:e(`rules.grimoire.intro_title`)}),(0,D.jsx)(`p`,{children:e(`rules.grimoire.intro_description`)}),(0,D.jsxs)(d,{as:`a`,href:`https://ffgapp.com/qr/ahc100`,rel:`noreferrer`,size:`full`,target:`_blank`,variant:`primary`,children:[(0,D.jsx)(h,{}),e(`rules.grimoire.open_link`)]})]}),t.isPending&&(0,D.jsxs)(J,{children:[(0,D.jsx)(l,{className:`spin`}),e(`rules.grimoire.loading`)]}),t.error&&(0,D.jsx)(J,{children:e(`rules.grimoire.error`)}),f&&(0,D.jsx)(`div`,{className:`grimoire-list`,children:o.filter(e=>a.sectionIds.has(e.id)).map(e=>(0,D.jsx)(se,{filteredGrimoire:a,grimoireHtmlMaps:c,grimoireMaps:s,section:e},e.id))}),!f&&!t.isPending&&!t.error&&(0,D.jsx)(J,{children:e(`rules.grimoire.empty`)}),n]})},renderToc:e=>{let t=u(e);return t.sectionIds.size?(0,D.jsx)(`nav`,{className:`toc`,children:(0,D.jsx)(`ol`,{children:o.filter(e=>t.sectionIds.has(e.id)).map(e=>(0,D.jsx)(oe,{filteredGrimoire:t,grimoireHtmlMaps:c,grimoireMaps:s,section:e},e.id))})}):null}})}function J(e){let{children:t}=e;return(0,D.jsx)(`output`,{className:`grimoire-status`,children:t})}function oe(e){let{filteredGrimoire:t,grimoireHtmlMaps:n,grimoireMaps:r,section:i}=e,a=(r.entriesBySectionId.get(i.id)??[]).filter(e=>t.entryIds.has(e.id));return(0,D.jsxs)(`li`,{children:[(0,D.jsx)(Y,{href:`#${$(i.id)}`,html:n.sectionTitleById.get(i.id)??``}),!!a.length&&(0,D.jsx)(`ul`,{children:a.map(e=>(0,D.jsx)(`li`,{children:(0,D.jsx)(Y,{href:`#${Q(e.id)}`,html:n.entryTitleById.get(e.id)??``})},e.id))})]})}function se(e){let{filteredGrimoire:t,grimoireHtmlMaps:n,grimoireMaps:r,section:i}=e,a=(r.entriesBySectionId.get(i.id)??[]).filter(e=>t.entryIds.has(e.id)),o=n.sectionTextById.get(i.id)??``;return(0,D.jsxs)(`section`,{className:`grimoire-entry`,id:$(i.id),children:[(0,D.jsx)(ce,{html:n.sectionTitleById.get(i.id)??``,section:i}),(0,D.jsxs)(`div`,{className:`grimoire-entry-copy`,children:[o&&(0,D.jsx)(`div`,{className:`grimoire-text longform`,dangerouslySetInnerHTML:{__html:o}}),i.citation&&(0,D.jsx)(`p`,{children:(0,D.jsx)(g,{size:`sm`,children:i.citation})}),a.map(e=>(0,D.jsx)(le,{entry:e,grimoireHtmlMaps:n},e.id))]})]})}function ce(e){let{html:t,section:n}=e;return(0,D.jsx)(`h2`,{className:`grimoire-entry-title`,children:(0,D.jsx)(Y,{href:`#${$(n.id)}`,html:t})})}function le(e){let{t}=r(),{entry:n,grimoireHtmlMaps:i}=e,a=i.entryTextById.get(n.id)??``;return(0,D.jsxs)(b,{as:`article`,className:`grimoire-entry`,id:Q(n.id),children:[(0,D.jsx)(`h3`,{className:`grimoire-entry-title`,children:(0,D.jsx)(Y,{href:`#${Q(n.id)}`,html:i.entryTitleById.get(n.id)??``})}),(0,D.jsxs)(`div`,{className:`grimoire-entry-copy`,children:[a&&(0,D.jsx)(`div`,{className:`grimoire-text longform`,dangerouslySetInnerHTML:{__html:a}}),!!n.references?.length&&(0,D.jsxs)(`p`,{className:`grimoire-references`,children:[(0,D.jsxs)(`strong`,{children:[t(`rules.grimoire.references`),`:`]}),` `,(0,D.jsx)(`span`,{children:n.references.map((e,t)=>(0,D.jsxs)(E.Fragment,{children:[t>0?`, `:null,(0,D.jsx)(Y,{href:`#${Q(e)}`,html:i.entryTitleById.get(e)??Z(e)})]},e))})]}),(0,D.jsx)(`p`,{children:(0,D.jsx)(g,{size:`xs`,children:n.citation})})]})]})}function Y(e){let{href:t,html:n}=e;return(0,D.jsx)(`a`,{dangerouslySetInnerHTML:{__html:n},href:t})}function X(e,t){return{entryTextById:new Map(e.map(e=>[e.id,e.text?F(e.text):``])),entryTitleById:new Map(e.map(e=>[e.id,Z(e.title)])),sectionTextById:new Map(t.map(e=>[e.id,e.text?F(e.text):``])),sectionTitleById:new Map(t.map(e=>[e.id,Z(e.title)]))}}function Z(e){return i(e,{newLines:`skip`})}function Q(e){return`grimoire-entry-${encodeURIComponent(e)}`}function $(e){return`grimoire-section-${encodeURIComponent(e)}`}function ue(){let{t:e}=r(),[t,n]=_(`chapter_2`),i=(0,E.useCallback)(e=>{n(e)},[n]);return(0,E.useEffect)(()=>{window.location.hash.startsWith(`#grimoire-`)&&n(`chapter_2`)},[n]),(0,D.jsx)(y,{title:e(`rules.title`),children:(0,D.jsxs)(re,{value:t,onValueChange:i,children:[(0,D.jsxs)(ne,{children:[(0,D.jsx)(w,{value:`chapter_1`,onTabChange:i,children:e(`settings.collection.chapter`,{number:1})}),(0,D.jsx)(w,{value:`chapter_2`,onTabChange:i,children:e(`settings.collection.chapter`,{number:2})})]}),(0,D.jsx)(T,{value:`chapter_1`,children:(0,D.jsx)(M,{})}),(0,D.jsx)(T,{value:`chapter_2`,children:(0,D.jsx)(q,{})})]})})}export{ue as default};